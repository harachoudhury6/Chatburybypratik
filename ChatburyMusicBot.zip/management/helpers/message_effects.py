"""Shared Telegram message effects used on welcome and music-card posts."""

from __future__ import annotations

import random
from collections.abc import Awaitable, Callable
from typing import Any

START_EFFECT_IDS = (
    5107584321108051014,
    5104858069142078462,
    5159385139981059251,
    5104841245755180586,
    5046509860389126442,
    5046589136895476101,
)


def random_message_effect() -> int:
    return random.choice(START_EFFECT_IDS)


async def send_with_message_effect(
    sender: Callable[..., Awaitable[Any]],
    *,
    effect_id: int,
    **kwargs: Any,
) -> Any:
    """Try either client spelling, then send normally if effects are unsupported."""
    for key in ("message_effect_id", "effect_id"):
        try:
            return await sender(**kwargs, **{key: effect_id})
        except TypeError:
            continue
        except Exception:
            break
    return await sender(**kwargs)
