import re
from management.helpers.data.fonts import Fonts

def apply_custom_font(text: str) -> str:
    if not text:
        return ""

    # regex to find segments outside of HTML tags
    # this will help avoid styling HTML tags like <b>, <i>, <code>, etc.
    segments = re.split(r'(<[^>]+>)', text)

    styled_segments = []
    for segment in segments:
        if segment.startswith('<') and segment.endswith('>'):
            # This is an HTML tag, don't style it
            styled_segments.append(segment)
        else:
            # Style the content segment
            styled_text = ""
            for char in segment:
                if char.isascii() and char.isalpha():
                    # The requested menu style uses one consistent small-caps
                    # alphabet for both uppercase and lowercase source text.
                    styled_text += Fonts.smallcap(char.lower())
                else:
                    styled_text += char
            styled_segments.append(styled_text)

    return "".join(styled_segments)
