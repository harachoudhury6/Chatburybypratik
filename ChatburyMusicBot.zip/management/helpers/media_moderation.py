"""Bounded local OCR and explicit-media analysis for group messages."""

from __future__ import annotations

import asyncio
import io
import logging
import os
import re
import shutil
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image, ImageSequence

logger = logging.getLogger("eiko.management.media_moderation")

MAX_MEDIA_BYTES = 20 * 1024 * 1024
MAX_FRAMES = 3
OCR_LANGUAGE_PREFERENCE = (
    "eng", "hin", "ori", "ben", "rus",
)


@dataclass(frozen=True)
class MediaScan:
    has_media: bool = False
    analyzed: bool = False
    ocr_text: str = ""
    frames: tuple[bytes, ...] = ()
    reason: str | None = None
    ocr_analyzed: bool = False


class NudeNetEngine:
    """Lazy, local NudeNet ONNX detector; no image is sent to a third party."""

    def __init__(self) -> None:
        self._model: Any = None
        self._lock = threading.Lock()
        self._state = "not_loaded"

    @property
    def state(self) -> str:
        return self._state

    def _get_model(self):
        if self._model is not None:
            return self._model
        with self._lock:
            if self._model is not None:
                return self._model
            self._state = "loading"
            try:
                from nudenet import NudeDetector

                self._model = NudeDetector()
                self._state = "ready"
            except Exception as exc:
                self._state = "unavailable"
                logger.warning("Local explicit-media model unavailable (%s).", type(exc).__name__)
                raise RuntimeError("Local explicit-media model is unavailable.") from exc
        return self._model

    def classify_sync(
        self, frames: tuple[bytes, ...], threshold: float, sexual_context: bool
    ) -> dict[str, Any]:
        import numpy as np

        model = self._get_model()
        hard_classes = {
            "FEMALE_GENITALIA_EXPOSED",
            "MALE_GENITALIA_EXPOSED",
            "ANUS_EXPOSED",
        }
        contextual_classes = {
            "FEMALE_BREAST_EXPOSED",
            "BUTTOCKS_EXPOSED",
            "MALE_BREAST_EXPOSED",
        }
        best_score = 0.0
        best_class = ""
        for frame in frames:
            with Image.open(io.BytesIO(frame)) as source:
                # NudeNet's image reader expects four-channel RGBA arrays.
                image = source.convert("RGBA")
                image.thumbnail((1280, 1280), Image.Resampling.LANCZOS)
                rgba = np.asarray(image)
            detections = model.detect(rgba)
            for detection in detections:
                label = str(detection.get("class", "")).upper()
                score = float(detection.get("score", 0.0))
                if label in hard_classes and score >= threshold:
                    if score > best_score:
                        best_score, best_class = score, label
                elif (
                    sexual_context
                    and label in contextual_classes
                    and score >= min(0.99, threshold + 0.04)
                    and score > best_score
                ):
                    best_score, best_class = score, label
        return {
            "explicit": bool(best_class),
            "confidence": best_score,
            "category": best_class,
        }

    async def classify(
        self, frames: tuple[bytes, ...], threshold: float, sexual_context: bool
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            self.classify_sync, frames, threshold, sexual_context
        )


nsfw_engine = NudeNetEngine()
_ocr_languages: str | None = None


def _choose_ocr_languages() -> str:
    global _ocr_languages
    if _ocr_languages is not None:
        return _ocr_languages
    import pytesseract

    available = set(pytesseract.get_languages(config=""))
    configured = os.getenv("MODERATION_OCR_LANGUAGES", "").strip()
    requested = (
        [item.strip() for item in re.split(r"[+,;\s]+", configured) if item.strip()]
        if configured
        else list(OCR_LANGUAGE_PREFERENCE)
    )
    selected = list(dict.fromkeys(language for language in requested if language in available))
    missing = [language for language in requested if language not in available]
    if missing:
        logger.warning(
            "Configured Tesseract language data unavailable: %s.",
            ", ".join(missing),
        )
    if not selected:
        raise RuntimeError("No usable local OCR language data is installed.")
    _ocr_languages = "+".join(selected)
    return _ocr_languages


def _image_to_png(image: Image.Image) -> bytes:
    image = image.convert("RGB")
    image.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG", optimize=True)
    return buffer.getvalue()


async def _render_svg(svg: str) -> bytes:
    magick = shutil.which("magick") or shutil.which("convert")
    if not magick:
        raise RuntimeError("ImageMagick is not installed for animated-sticker rendering.")
    process = await asyncio.create_subprocess_exec(
        magick,
        "svg:-",
        "png:-",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        output, error = await asyncio.wait_for(
            process.communicate(svg.encode("utf-8")), timeout=8
        )
    except asyncio.TimeoutError:
        process.kill()
        await process.wait()
        raise RuntimeError("Animated sticker rendering timed out.")
    if process.returncode or not output:
        raise RuntimeError("Animated sticker renderer could not rasterize the frame.")
    return output


async def _tgs_frames(path: Path) -> tuple[bytes, ...]:
    from lottie.exporters.cairo import export_svg
    from lottie.parsers.tgs import parse_tgs

    animation = await asyncio.to_thread(parse_tgs, str(path))
    start = int(getattr(animation, "in_point", 0))
    end = int(getattr(animation, "out_point", start + 1))
    points = sorted({start, max(start, (start + end) // 2), max(start, end - 1)})
    frames: list[bytes] = []
    for frame_number in points[:MAX_FRAMES]:
        target = io.StringIO()
        await asyncio.to_thread(
            export_svg, animation, target, frame=frame_number, pretty=False
        )
        frames.append(await _render_svg(target.getvalue()))
    return tuple(frames)


async def _video_frames(path: Path, duration: int | float | None) -> tuple[bytes, ...]:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg is not installed for video moderation.")
    length = max(0.0, float(duration or 0))
    points = sorted({0.0, min(2.0, length / 2) if length else 0.0, max(0.0, length - 1)})
    frames: list[bytes] = []
    for seconds in points[:MAX_FRAMES]:
        process = await asyncio.create_subprocess_exec(
            ffmpeg,
            "-v", "error",
            "-nostdin",
            "-ss", f"{seconds:.2f}",
            "-i", str(path),
            "-frames:v", "1",
            "-vf", "scale='min(1280,iw)':-2",
            "-f", "image2pipe",
            "-vcodec", "png",
            "pipe:1",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            output, _ = await asyncio.wait_for(process.communicate(), timeout=10)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            continue
        if process.returncode == 0 and output:
            frames.append(output)
    if not frames:
        raise RuntimeError("FFmpeg could not extract a frame from this video.")
    return tuple(frames)


async def _extract_frames(path: Path, suffix: str, mime_type: str, duration: int | float | None):
    suffix = suffix.lower()
    mime_type = mime_type.lower()
    if suffix == ".tgs" or "tgsticker" in mime_type:
        return await _tgs_frames(path)
    if suffix in {".mp4", ".webm", ".mov", ".mkv", ".avi"} or mime_type.startswith("video/"):
        return await _video_frames(path, duration)

    def extract_image_frames() -> tuple[bytes, ...]:
        with Image.open(path) as image:
            frame_count = int(getattr(image, "n_frames", 1))
            indices = sorted({0, frame_count // 2, frame_count - 1})
            frames: list[bytes] = []
            for index in indices[:MAX_FRAMES]:
                image.seek(index)
                frames.append(_image_to_png(image.copy()))
            return tuple(frames)

    return await asyncio.to_thread(extract_image_frames)


async def _ocr_frames(frames: tuple[bytes, ...]) -> str:
    import pytesseract

    languages = await asyncio.to_thread(_choose_ocr_languages)

    def recognize(frame: bytes) -> str:
        with Image.open(io.BytesIO(frame)) as image:
            return pytesseract.image_to_string(
                image.convert("RGB"),
                lang=languages,
                config="--psm 6",
                timeout=8,
            )

    texts = await asyncio.gather(*(asyncio.to_thread(recognize, frame) for frame in frames))
    return "\n".join(text.strip() for text in texts if text and text.strip())


def _message_media(message: Any) -> tuple[Any | None, str, int | float | None]:
    candidates = (
        ("photo", getattr(message, "photo", None)),
        ("sticker", getattr(message, "sticker", None)),
        ("animation", getattr(message, "animation", None)),
        ("video", getattr(message, "video", None)),
        ("video_note", getattr(message, "video_note", None)),
        ("document", getattr(message, "document", None)),
    )
    for kind, media in candidates:
        if not media:
            continue
        mime = str(getattr(media, "mime_type", "") or "").lower()
        file_name = str(getattr(media, "file_name", "") or "")
        if kind == "document" and not (
            mime.startswith("image/")
            or mime.startswith("video/")
            or mime == "image/gif"
            or "tgsticker" in mime
        ):
            continue
        duration = getattr(media, "duration", None)
        if kind == "sticker":
            if getattr(media, "is_video", False):
                mime = mime or "video/webm"
            elif getattr(media, "is_animated", False):
                mime = mime or "application/x-tgsticker"
                file_name = file_name or "sticker.tgs"
            else:
                mime = mime or "image/webp"
                file_name = file_name or "sticker.webp"
        if kind == "animation":
            mime = mime or "image/gif"
            file_name = file_name or "animation.gif"
        if kind == "video_note":
            mime = mime or "video/mp4"
        return media, mime, duration
    return None, "", None


async def scan_message_media(client: Any, message: Any) -> MediaScan:
    media, mime, duration = _message_media(message)
    if media is None:
        return MediaScan()
    size = getattr(media, "file_size", None)
    if size and size > MAX_MEDIA_BYTES:
        return MediaScan(has_media=True, reason="Media is above the 20 MiB analysis limit.")

    try:
        downloaded = await asyncio.wait_for(
            client.download_media(message, in_memory=True), timeout=25
        )
        if downloaded is None:
            return MediaScan(has_media=True, reason="Telegram did not provide a downloadable media file.")
        data = downloaded.getvalue() if hasattr(downloaded, "getvalue") else bytes(downloaded)
        if not data:
            return MediaScan(has_media=True, reason="The downloaded media was empty.")
        if len(data) > MAX_MEDIA_BYTES:
            return MediaScan(has_media=True, reason="Media is above the 20 MiB analysis limit.")
        file_name = str(getattr(media, "file_name", "") or "")
        suffix = Path(file_name).suffix.lower()
        if not suffix:
            if "tgsticker" in mime:
                suffix = ".tgs"
            elif mime.startswith("video/"):
                suffix = ".webm" if "webm" in mime else ".mp4"
            elif mime == "image/gif":
                suffix = ".gif"
            else:
                suffix = ".webp" if "webp" in mime else ".img"
        with tempfile.TemporaryDirectory(prefix="eiko-moderation-") as directory:
            path = Path(directory) / f"upload{suffix}"
            path.write_bytes(data)
            frames = await _extract_frames(path, suffix, mime, duration)
        if not frames:
            return MediaScan(
                has_media=True,
                reason="No image frames could be extracted for OCR or visual classification.",
            )
        try:
            text = await _ocr_frames(frames)
        except Exception as exc:
            logger.warning("Media OCR could not complete (%s).", type(exc).__name__)
            return MediaScan(
                has_media=True,
                analyzed=True,
                frames=frames,
                reason=f"OCR unavailable ({type(exc).__name__}); visual classification may still run.",
                ocr_analyzed=False,
            )
        return MediaScan(
            has_media=True,
            analyzed=True,
            ocr_text=text,
            frames=frames,
            ocr_analyzed=True,
        )
    except Exception as exc:
        logger.warning("Media analysis could not complete (%s).", type(exc).__name__)
        return MediaScan(
            has_media=True,
            analyzed=False,
            reason=f"Media could not be analyzed ({type(exc).__name__}).",
        )
