"""Deterministic multilingual moderation rules used by the GC guard.

This is a curated lexical detector, not a universal language-understanding
model. It normalizes common evasion, transliterates installed Indic scripts,
and deliberately requires word/phrase evidence to limit false positives.
"""

from __future__ import annotations

import json
import logging
import re
import unicodedata
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlparse

try:
    from indic_transliteration import sanscript
except Exception:  # optional at import time; the text filter still works in Latin
    sanscript = None


_SCRIPT_RANGES = (
    ("DEVANAGARI", 0x0900, 0x097F),
    ("BENGALI", 0x0980, 0x09FF),
    ("GURMUKHI", 0x0A00, 0x0A7F),
    ("GUJARATI", 0x0A80, 0x0AFF),
    ("ORIYA", 0x0B00, 0x0B7F),
    ("TAMIL", 0x0B80, 0x0BFF),
    ("TELUGU", 0x0C00, 0x0C7F),
    ("KANNADA", 0x0C80, 0x0CFF),
    ("MALAYALAM", 0x0D00, 0x0D7F),
)

_CONFUSABLES = str.maketrans(
    {
        "а": "a", "с": "c", "е": "e", "і": "i", "о": "o",
        "р": "p", "ѕ": "s", "х": "x", "у": "y",
        "Α": "a", "Β": "b", "Ε": "e", "Ι": "i", "Κ": "k",
        "Μ": "m", "Ν": "n", "Ο": "o", "Ρ": "p", "Τ": "t",
        "Χ": "x", "Ζ": "z",
    }
)
_CYRILLIC_TO_LATIN = str.maketrans(
    {
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d",
        "е": "e", "ё": "yo", "ж": "zh", "з": "z", "и": "i",
        "й": "y", "к": "k", "л": "l", "м": "m", "н": "n",
        "о": "o", "п": "p", "р": "r", "с": "s", "т": "t",
        "у": "u", "ф": "f", "х": "kh", "ц": "ts", "ч": "ch",
        "ш": "sh", "щ": "shch", "ъ": "", "ы": "y", "ь": "",
        "э": "e", "ю": "yu", "я": "ya",
    }
)
_LEET = str.maketrans(
    {
        "0": "o", "1": "i", "3": "e", "4": "a", "5": "s",
        "7": "t", "@": "a", "$": "s",
    }
)
_WORD_RE = re.compile(r"[^\W_]+", re.UNICODE)
_ZERO_WIDTH_RE = re.compile(r"[\u200b-\u200f\u202a-\u202e\u2060\ufeff]")
_REPEATED_RE = re.compile(r"(.)\1{2,}", re.IGNORECASE)
_COLLAPSED_REPEATS = re.compile(r"(.)\1+", re.IGNORECASE)

# Keep this fallback in code so English/Hindi/Odia checks continue if the
# editable language pack is missing or malformed.
BUILTIN_ABUSE_TERMS = (
    "fuck", "fucker", "fucking", "motherfucker", "shit", "shitty",
    "bitch", "bastard", "asshole", "dickhead",
    "madarchod", "maderchod", "madarch*d", "madharchod",
    "madarachoda", "maadarachoda", "behenchod", "bhenchod",
    "bahenchod", "bhenachoda", "bhench*d", "bsdk", "bhosdike",
    "bhosdi ke", "bhosdiwale", "bhosdiwala", "bhosadike", "chutiya",
    "chutiye", "chutiyapa", "gaand mara", "gand mara", "gandmara",
    "randi", "lund mar", "lund", "laude", "lode", "maa ke lode",
    "ma ke lode", "maa ke laude", "ma ke laude", "behen ke lode",
    "bhen ke lode", "behen ke laude", "bhen ke laude", "maa ki chut",
    "ma ki chut", "behen ki chut", "bhen ki chut", "maichoda",
    "maichuda", "bokachoda", "bhokachoda",
    "mkc", "mc", "bc", "bkc", "bkl",
)

_LEXICON_PATH = Path(__file__).with_name("profanity_lexicons.json")
_logger = logging.getLogger("eiko.management.moderation.rules")


@lru_cache(maxsize=1)
def _language_lexicon_terms() -> tuple[str, ...]:
    """Load local, expandable language term lists without network dependencies."""
    try:
        data = json.loads(_LEXICON_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _logger.warning("Multilingual abuse lexicon unavailable (%s).", type(exc).__name__)
        return ()
    if not isinstance(data, dict):
        _logger.warning("Multilingual abuse lexicon has an invalid top-level format.")
        return ()
    terms: list[str] = []
    for language, entries in data.items():
        if not isinstance(language, str) or not isinstance(entries, list):
            continue
        terms.extend(
            item.strip()
            for item in entries
            if isinstance(item, str) and 2 <= len(item.strip()) <= 80
        )
    return tuple(dict.fromkeys(terms))

_SALE_STRONG = re.compile(
    r"\b(?:for\s+sale|selling\s+(?:now|this|my|our|available)|"
    r"available\s+(?:to\s+buy|for\s+purchase)|buy\s+now|order\s+now|"
    r"dm\s+(?:me\s+)?to\s+buy|pm\s+(?:me\s+)?to\s+buy|"
    r"bech\s+raha(?:\s+hu)?|bech\s+rahi(?:\s+hu)?|"
    r"buy\s+from\s+me|shop\s+now|limited\s+time\s+offer)\b",
    re.IGNORECASE,
)
_SALE_INTENT = re.compile(
    r"\b(?:sell(?:ing)?|sale|buy|order|deal|offer|discount|wholesale|"
    r"resell|promo|promotion|available|bech(?:na|unga|ungi|raha|rahi)?|"
    r"kharid(?:o|na)|order\s+lo|rate|daam|bikri|bechiba)\b",
    re.IGNORECASE,
)
_SALE_CTA = re.compile(
    r"\b(?:dm|pm|message|inbox|contact|call|whatsapp|order|book|buy|"
    r"link\s+in|join\s+now|limited\s+stock|delivery|deliver|ship)\b",
    re.IGNORECASE,
)
_SALE_PRICE = re.compile(
    r"(?:₹|rs\.?|inr|usd|\$|€|£)\s*\d{1,7}"
    r"|\b\d{2,7}\s*(?:rs\.?|inr|rupees?|₹)\b"
    r"|\bprice\s*[:=-]?\s*\d{2,7}\b",
    re.IGNORECASE,
)
_SALE_PROMO = re.compile(
    r"\b(?:special\s+offer|flat\s+\d{1,2}%|discount|coupon|"
    r"cashback|limited\s+stock|flash\s+sale|affiliate|referral\s+bonus)\b",
    re.IGNORECASE,
)
_URL_RE = re.compile(r"https?://\S+|t\.me/\S+", re.IGNORECASE)
_MENTION_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{3,}")
_MEDICAL_CONTEXT = re.compile(
    r"\b(?:medical|medicine|doctor|clinic|hospital|health|education|"
    r"educational|anatomy|biology|breastfeeding|nursing|research)\b",
    re.IGNORECASE,
)
_SEXUAL_CONTEXT = re.compile(
    r"\b(?:porn|xxx|explicit|sexual|sex\s+tape|nude\s+video)\b",
    re.IGNORECASE,
)


def _strip_marks(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value)
    return "".join(char for char in decomposed if not unicodedata.combining(char))


def _basic_normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "")
    value = _ZERO_WIDTH_RE.sub("", value).translate(_CONFUSABLES)
    value = _strip_marks(value).casefold().translate(_CONFUSABLES)
    # Treat ! as an i only when used inside a word (e.g. sh!t), not as
    # punctuation after a word (e.g. MKC!!!).
    value = re.sub(r"(?<=\w)!(?=\w)", "i", value).translate(_LEET)
    value = _REPEATED_RE.sub(r"\1\1", value)
    value = value.replace("’", "'").replace("`", "'")
    return re.sub(r"\s+", " ", value).strip()


def normalized_forms(value: str) -> tuple[str, ...]:
    """Return normalized original and Indic-transliterated forms."""
    original = _basic_normalize(value)
    forms = {original} if original else set()
    collapsed = _COLLAPSED_REPEATS.sub(r"\1", original)
    if collapsed and collapsed != original:
        forms.add(collapsed)
    if sanscript is None:
        return tuple(forms)

    for script_name, start, end in _SCRIPT_RANGES:
        if not any(start <= ord(char) <= end for char in value):
            continue
        script = getattr(sanscript, script_name, None)
        if script is None:
            continue
        try:
            roman = sanscript.transliterate(value, script, sanscript.ITRANS)
        except Exception:
            continue
        roman = _basic_normalize(roman)
        if roman:
            forms.add(roman)
    if any(0x0400 <= ord(char) <= 0x052F for char in value):
        roman = _basic_normalize(value.translate(_CYRILLIC_TO_LATIN))
        if roman:
            forms.add(roman)
    return tuple(forms)


def _term_matches(text: str, term: str) -> bool:
    if not text or not term:
        return False
    tokens = _WORD_RE.findall(text)
    term_tokens = _WORD_RE.findall(term)
    if not term_tokens:
        return False

    compact_target = "".join(term_tokens)
    if len(term_tokens) > 1:
        phrase = " ".join(term_tokens)
        if re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", text):
            return True
        if re.search(rf"(?<!\w){re.escape(compact_target)}(?!\w)", text):
            return True
        for start in range(len(tokens)):
            compact = ""
            parts: list[str] = []
            for end in range(start, min(len(tokens), start + len(compact_target) + 1)):
                compact += tokens[end]
                parts.append(tokens[end])
                if compact == compact_target:
                    if all(len(part) <= 2 for part in parts) or (
                        len(parts) == 2
                        and len(compact_target) >= 8
                        and all(len(part) <= 5 for part in parts)
                    ):
                        return True
                if len(compact) > len(compact_target) + 1:
                    break
        return False

    target = term_tokens[0]
    if re.search(rf"(?<!\w){re.escape(target)}(?!\w)", text):
        return True
    if target in {"fuck", "shit"} and re.search(
        rf"(?<!\w){re.escape(target)}(?:er|ing|ed|s|ty)?(?!\w)",
        text,
    ):
        return True

    # Join only short chunks, or two chunks of a long term, so spaced-letter
    # evasion works without concatenating arbitrary ordinary words.
    for start in range(len(tokens)):
        compact = ""
        parts: list[str] = []
        for end in range(start, min(len(tokens), start + len(target) + 1)):
            compact += tokens[end]
            parts.append(tokens[end])
            if compact == target:
                if all(len(part) <= 2 for part in parts) or (
                    len(parts) == 2
                    and len(target) >= 8
                    and all(len(part) <= 5 for part in parts)
                ):
                    return True
            if len(compact) > len(target) + 1:
                break
    return False


def find_abusive_term(text: str, custom_terms: list[str] | tuple[str, ...] = ()) -> str | None:
    """Return a matching curated/admin term, or None."""
    terms = (*BUILTIN_ABUSE_TERMS, *_language_lexicon_terms(), *custom_terms)
    text_forms = normalized_forms(text)
    if not text_forms:
        return None

    for raw_term in terms:
        term_forms = normalized_forms(raw_term)
        if not term_forms:
            continue
        for text_form in text_forms:
            if any(_term_matches(text_form, term_form) for term_form in term_forms):
                return raw_term
    return None


def classify_selling(text: str, minimum_score: int = 4) -> tuple[bool, int]:
    """Conservative sales classifier; casual product mentions score too low."""
    normalized = _basic_normalize(text)
    if not normalized:
        return False, 0

    strong = bool(_SALE_STRONG.search(normalized))
    intent = bool(_SALE_INTENT.search(normalized))
    cta = bool(_SALE_CTA.search(normalized))
    price = bool(_SALE_PRICE.search(text or "") or _SALE_PRICE.search(normalized))
    promo = bool(_SALE_PROMO.search(normalized))
    url = bool(_URL_RE.search(normalized))

    score = (4 if strong else 0) + (2 if intent else 0)
    score += (2 if cta else 0) + (2 if price else 0)
    score += (2 if promo else 0) + (1 if url else 0)
    confirmed = strong or (price and cta and intent) or (promo and cta and intent)
    return confirmed and score >= minimum_score, score


def spam_signals(text: str, mention_limit: int = 8) -> list[str]:
    """Return high-confidence spam signals; ordinary message volume is excluded."""
    normalized = _basic_normalize(text)
    signals: list[str] = []
    if len(_MENTION_RE.findall(text or "")) >= mention_limit:
        signals.append("excessive_mentions")
    if len(_URL_RE.findall(text or "")) >= 4:
        signals.append("link_flood")
    if re.search(
        r"\b(?:free\s+money|guaranteed\s+profit|double\s+your\s+money|"
        r"claim\s+your\s+prize|airdrop\s+claim|investment\s+guaranteed)\b",
        normalized,
    ) and _URL_RE.search(normalized):
        signals.append("suspicious_link_promotion")
    return signals


def has_medical_context(text: str) -> bool:
    return bool(_MEDICAL_CONTEXT.search(_basic_normalize(text)))


def has_explicit_caption_context(text: str) -> bool:
    return bool(_SEXUAL_CONTEXT.search(_basic_normalize(text)))


def valid_telegram_url(value: str) -> bool:
    try:
        parsed = urlparse((value or "").strip())
        if parsed.scheme != "https" or parsed.hostname not in {"t.me", "telegram.me"}:
            return False
        return bool(parsed.path.strip("/")) and not parsed.username and not parsed.password
    except Exception:
        return False
