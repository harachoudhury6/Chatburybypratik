"""Apply the bot's emoji-free font style to outgoing text and keyboards."""

from __future__ import annotations

import copy
import inspect
import re
from functools import lru_cache, wraps
from typing import Any


_CUSTOM_EMOJI_TAG = re.compile(
    r"<(?:emoji|tg-emoji)\b[^>]*>.*?</(?:emoji|tg-emoji)\s*>",
    re.IGNORECASE | re.DOTALL,
)
_PRESERVED_TEXT = re.compile(
    r"</?[A-Za-z][A-Za-z0-9:_-]*(?:\s+[^<>]*?)?\s*/?>"
    r"|&(?:#[0-9]+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]+);"
    r"|```[\s\S]*?```|`[^`\n]*`"
    r"|(?:https?://|tg://|mailto:)[^\s<>]+"
    r"|(?<![\w])/[A-Za-z][A-Za-z0-9_]*(?:@[A-Za-z0-9_]+)?"
    r"|@[A-Za-z0-9_]{3,}"
)
_EMOJI_RANGES = (
    (0x1F000, 0x1FAFF),  # emoji and pictographs, including flags and skin tones
    (0x2300, 0x23FF),  # clocks, media controls, and related symbols
    (0x2600, 0x27BF),  # miscellaneous symbols and dingbats
    (0x2B00, 0x2BFF),  # arrows, geometric symbols, and emoji
)
_EMOJI_CODEPOINTS = {
    0x00A9, 0x00AE, 0x203C, 0x2049, 0x2122, 0x2139,
    0x2194, 0x2195, 0x2196, 0x2197, 0x2198, 0x2199,
    0x21A9, 0x21AA, 0x24C2, 0x25AA, 0x25AB, 0x25B6,
    0x25C0, 0x25FB, 0x25FC, 0x25FD, 0x25FE, 0x2934,
    0x2935, 0x3030, 0x303D, 0x3297, 0x3299,
}
_EMOJI_CODEPOINTS.update(range(0x2B05, 0x2B08))
_EMOJI_CODEPOINTS.update((0x2B1B, 0x2B1C, 0x2B50, 0x2B55))
_EMOJI_SEQUENCE_CODEPOINTS = {
    0x200D,  # zero-width joiner
    0x20E3,  # keycap enclosing mark
    0xFE0F,  # emoji presentation selector
}
_TAG_SEQUENCE_RANGE = (0xE0020, 0xE007F)


def _is_emoji_codepoint(codepoint: int) -> bool:
    return (
        codepoint in _EMOJI_CODEPOINTS
        or codepoint in _EMOJI_SEQUENCE_CODEPOINTS
        or any(start <= codepoint <= end for start, end in _EMOJI_RANGES)
        or _TAG_SEQUENCE_RANGE[0] <= codepoint <= _TAG_SEQUENCE_RANGE[1]
    )


def _normalize_spacing(text: str) -> tuple[str, dict[int, int]]:
    """Collapse whitespace made awkward by removed emoji and map UTF-16 offsets."""
    output: list[str] = []
    offsets: dict[int, int] = {0: 0}
    source_units = 0
    result_units = 0
    index = 0

    while index < len(text):
        char = text[index]
        if char in " \t":
            end = index + 1
            while end < len(text) and text[end] in " \t":
                end += 1
            previous = output[-1] if output else ""
            following = text[end] if end < len(text) else ""
            keep_one = (
                bool(previous)
                and previous != "\n"
                and previous not in "([{"
                and following not in "\n)]},.;:!?"
            )
            if keep_one:
                output.append(" ")
                result_units += 1
            for step in range(1, end - index + 1):
                offsets[source_units + step] = result_units
            source_units += end - index
            index = end
            continue

        codepoint = ord(char)
        units = 2 if codepoint > 0xFFFF else 1
        offsets[source_units] = result_units
        for step in range(1, units + 1):
            offsets[source_units + step] = result_units + step
        output.append(char)
        source_units += units
        result_units += units
        index += 1

    return "".join(output), offsets


def strip_emoji_text(text: str) -> tuple[str, dict[int, int]]:
    """Return emoji-free text and a Telegram UTF-16 offset remapping table."""
    if not text:
        return text, {0: 0}

    removed_spans = [
        (match.start(), match.end())
        for match in _CUSTOM_EMOJI_TAG.finditer(text)
    ]
    removed_spans.sort()

    output: list[str] = []
    offsets: dict[int, int] = {0: 0}
    source_units = 0
    result_units = 0
    span_index = 0
    removed_any = False

    for index, char in enumerate(text):
        while span_index < len(removed_spans) and removed_spans[span_index][1] <= index:
            span_index += 1
        in_removed_span = (
            span_index < len(removed_spans)
            and removed_spans[span_index][0] <= index < removed_spans[span_index][1]
        )
        codepoint = ord(char)
        remove_char = in_removed_span or _is_emoji_codepoint(codepoint)
        removed_any = removed_any or remove_char
        units = 2 if codepoint > 0xFFFF else 1

        for step in range(1, units + 1):
            offsets[source_units + step] = result_units if remove_char else result_units + step
        if not remove_char:
            output.append(char)
            result_units += units
        source_units += units

    result = "".join(output)
    if not removed_any:
        return result, offsets
    normalized, spacing_offsets = _normalize_spacing(result)
    return normalized, {
        source: spacing_offsets.get(target, target)
        for source, target in offsets.items()
    }


@lru_cache(maxsize=256)
def _styled_character(char: str) -> str:
    from management.helpers.font_helper import apply_custom_font

    return apply_custom_font(char) if char.isascii() and char.isalpha() else char


def _style_text_with_offsets(text: str) -> tuple[str, dict[int, int]]:
    """Apply the menu's uniform small-caps font while preserving tokens."""
    output: list[str] = []
    offsets: dict[int, int] = {0: 0}
    source_units = 0
    result_units = 0

    def append_segment(segment: str, transform: bool) -> None:
        nonlocal source_units, result_units
        for char in segment:
            styled = _styled_character(char) if transform else char
            original_width = 2 if ord(char) > 0xFFFF else 1
            styled_width = sum(2 if ord(item) > 0xFFFF else 1 for item in styled)
            offsets[source_units] = result_units
            for step in range(1, original_width):
                offsets[source_units + step] = result_units + min(step, styled_width)
            source_units += original_width
            result_units += styled_width
            offsets[source_units] = result_units
            output.append(styled)

    cursor = 0
    for match in _PRESERVED_TEXT.finditer(text):
        append_segment(text[cursor : match.start()], True)
        append_segment(match.group(), False)
        cursor = match.end()
    append_segment(text[cursor:], True)
    return "".join(output), offsets


def format_bot_text(text: str) -> tuple[str, dict[int, int]]:
    """Remove emoji, style ordinary text, and map Telegram entity offsets."""
    clean_text, emoji_offsets = strip_emoji_text(text)
    styled_text, style_offsets = _style_text_with_offsets(clean_text)
    return styled_text, {
        source: style_offsets.get(clean, clean)
        for source, clean in emoji_offsets.items()
    }


def format_button_label(text: str) -> str:
    """Remove emoji and apply the same display font, except the Rec status dot."""
    text = str(text or "")
    recording_dot = text.strip().casefold() == "🔴 rec"
    if recording_dot:
        text = "Rec"
    clean_text, _ = strip_emoji_text(text)
    styled_text, _ = _style_text_with_offsets(clean_text)
    prefix = "🔴 " if recording_dot else ""
    return prefix + styled_text if styled_text else (prefix or "\u200b")


def _remap_entities(entities: Any, offsets: dict[int, int]) -> Any:
    if not entities:
        return entities

    remapped = []
    for entity in entities:
        start = getattr(entity, "offset", None)
        length = getattr(entity, "length", None)
        if not isinstance(start, int) or not isinstance(length, int):
            remapped.append(entity)
            continue

        end = start + length
        new_start = offsets.get(start)
        new_end = offsets.get(end)
        if new_start is None or new_end is None:
            remapped.append(entity)
            continue
        new_length = new_end - new_start
        if new_length <= 0:
            continue

        clone = copy.copy(entity)
        try:
            setattr(clone, "offset", new_start)
            setattr(clone, "length", new_length)
        except (AttributeError, TypeError):
            try:
                object.__setattr__(clone, "offset", new_start)
                object.__setattr__(clone, "length", new_length)
            except (AttributeError, TypeError):
                remapped.append(entity)
                continue
        remapped.append(clone)

    return remapped


def _sanitize_media_group(media: Any) -> Any:
    if not isinstance(media, (list, tuple)):
        return media

    sanitized = []
    for item in media:
        caption = getattr(item, "caption", None)
        if isinstance(item, dict):
            caption = item.get("caption")
        if not isinstance(caption, str) or not caption:
            sanitized.append(item)
            continue

        cleaned, offset_map = format_bot_text(caption)
        if cleaned == caption:
            sanitized.append(item)
            continue
        clone = copy.copy(item)
        new_caption = cleaned or "\u200b"
        entities = (
            item.get("caption_entities")
            if isinstance(item, dict)
            else getattr(item, "caption_entities", None)
        )
        new_entities = _remap_entities(entities, offset_map)
        if isinstance(clone, dict):
            clone["caption"] = new_caption
            if "caption_entities" in clone:
                clone["caption_entities"] = new_entities
        else:
            try:
                setattr(clone, "caption", new_caption)
                if hasattr(clone, "caption_entities"):
                    setattr(clone, "caption_entities", new_entities)
            except (AttributeError, TypeError):
                try:
                    object.__setattr__(clone, "caption", new_caption)
                    if hasattr(clone, "caption_entities"):
                        object.__setattr__(clone, "caption_entities", new_entities)
                except (AttributeError, TypeError):
                    sanitized.append(item)
                    continue
        sanitized.append(clone)
    return tuple(sanitized) if isinstance(media, tuple) else sanitized


def _copy_with_fields(value: Any, updates: dict[str, Any]) -> Any:
    clone = copy.copy(value)
    updated = True
    for name, field_value in updates.items():
        try:
            setattr(clone, name, field_value)
        except (AttributeError, TypeError):
            try:
                object.__setattr__(clone, name, field_value)
            except (AttributeError, TypeError):
                updated = False
                break
    if updated:
        return clone

    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        try:
            data = to_dict()
            data.update(updates)
            api_kwargs = getattr(value, "api_kwargs", None)
            if api_kwargs and "api_kwargs" not in data:
                data["api_kwargs"] = api_kwargs
            return type(value)(**data)
        except (TypeError, ValueError):
            pass
    return None


def _sanitize_button(button: Any) -> Any:
    if isinstance(button, dict):
        label = button.get("text")
        if not isinstance(label, str):
            return button
        styled = format_button_label(label)
        if styled == label and not button.get("icon_custom_emoji_id"):
            return button
        clone = dict(button)
        clone["text"] = styled
        clone.pop("icon_custom_emoji_id", None)
        return clone

    label = getattr(button, "text", None)
    if not isinstance(label, str):
        return button
    styled = format_button_label(label)
    icon_id = getattr(button, "icon_custom_emoji_id", None)
    if styled == label and not icon_id:
        return button

    updates = {"text": styled}
    if hasattr(button, "icon_custom_emoji_id"):
        updates["icon_custom_emoji_id"] = None
    sanitized = _copy_with_fields(button, updates)
    if sanitized is None:
        raise TypeError(f"Cannot safely restyle Telegram button type {type(button).__name__}")
    return sanitized


def _sanitize_keyboard_rows(rows: Any) -> tuple[Any, bool]:
    if not isinstance(rows, (list, tuple)):
        return rows, False
    if rows and all(
        (isinstance(item, dict) and "text" in item) or hasattr(item, "text")
        for item in rows
    ):
        sanitized = [_sanitize_button(button) for button in rows]
        changed = any(new is not old for new, old in zip(sanitized, rows))
        return (tuple(sanitized) if isinstance(rows, tuple) else sanitized), changed
    changed = False
    sanitized_rows = []
    for row in rows:
        if not isinstance(row, (list, tuple)):
            sanitized_rows.append(row)
            continue
        sanitized_row = [_sanitize_button(button) for button in row]
        changed = changed or any(
            new is not old for new, old in zip(sanitized_row, row)
        )
        sanitized_rows.append(
            tuple(sanitized_row) if isinstance(row, tuple) else sanitized_row
        )
    return (
        tuple(sanitized_rows) if isinstance(rows, tuple) else sanitized_rows,
        changed,
    )


def _sanitize_reply_markup(markup: Any) -> Any:
    """Restyle keyboard labels without changing their actions or layout."""
    if isinstance(markup, dict):
        for field in ("inline_keyboard", "keyboard"):
            if field not in markup:
                continue
            rows, changed = _sanitize_keyboard_rows(markup[field])
            if not changed:
                return markup
            clone = dict(markup)
            clone[field] = rows
            return clone
        return markup

    for field in ("inline_keyboard", "keyboard"):
        rows = getattr(markup, field, None)
        if rows is None:
            continue
        sanitized_rows, changed = _sanitize_keyboard_rows(rows)
        if not changed:
            return markup
        sanitized = _copy_with_fields(markup, {field: sanitized_rows})
        if sanitized is None:
            raise TypeError(
                f"Cannot safely restyle Telegram keyboard type {type(markup).__name__}"
            )
        return sanitized
    return markup


def _sanitize_bot_commands(commands: Any) -> Any:
    if not isinstance(commands, (list, tuple)):
        return commands
    sanitized = []
    for command in commands:
        description = getattr(command, "description", None)
        if isinstance(command, dict):
            description = command.get("description")
        if not isinstance(description, str):
            sanitized.append(command)
            continue
        styled, _ = format_bot_text(description)
        if styled == description:
            sanitized.append(command)
            continue
        if isinstance(command, dict):
            clone = dict(command)
            clone["description"] = styled
        else:
            clone = _copy_with_fields(command, {"description": styled})
            if clone is None:
                raise TypeError(
                    f"Cannot safely restyle Telegram command type {type(command).__name__}"
                )
        sanitized.append(clone)
    return tuple(sanitized) if isinstance(commands, tuple) else sanitized


def _patch_sender_method(
    sender_class: type,
    method_name: str,
    text_fields: tuple[tuple[str, str | None], ...],
) -> None:
    original = getattr(sender_class, method_name, None)
    if not callable(original) or getattr(original, "_plain_text_emoji_filter", False):
        return
    try:
        signature = inspect.signature(original)
    except (TypeError, ValueError):
        return

    @wraps(original)
    async def filtered(
        self: Any,
        *args: Any,
        __original=original,
        __signature=signature,
        __text_fields=text_fields,
        __method_name=method_name,
        **kwargs: Any,
    ) -> Any:
        try:
            bound = __signature.bind_partial(self, *args, **kwargs)
        except TypeError:
            result = __original(self, *args, **kwargs)
            return await result if inspect.isawaitable(result) else result

        if __method_name == "send_media_group" and "media" in bound.arguments:
            bound.arguments["media"] = _sanitize_media_group(
                bound.arguments["media"]
            )
        elif __method_name == "edit_message_media" and "media" in bound.arguments:
            media = _sanitize_media_group([bound.arguments["media"]])
            bound.arguments["media"] = media[0]

        if "reply_markup" in bound.arguments:
            bound.arguments["reply_markup"] = _sanitize_reply_markup(
                bound.arguments["reply_markup"]
            )
        if "buttons" in bound.arguments:
            bound.arguments["buttons"], _ = _sanitize_keyboard_rows(
                bound.arguments["buttons"]
            )
        if __method_name in {"set_bot_commands", "set_my_commands"}:
            if "commands" in bound.arguments:
                bound.arguments["commands"] = _sanitize_bot_commands(
                    bound.arguments["commands"]
                )

        for text_field, entity_field in __text_fields:
            value = bound.arguments.get(text_field)
            if not isinstance(value, str) or not value:
                continue
            cleaned, offset_map = format_bot_text(value)
            if cleaned == value:
                continue
            bound.arguments[text_field] = cleaned or "\u200b"
            if entity_field and entity_field in bound.arguments:
                bound.arguments[entity_field] = _remap_entities(
                    bound.arguments[entity_field], offset_map
                )

        result = __original(*bound.args, **bound.kwargs)
        return await result if inspect.isawaitable(result) else result

    filtered._plain_text_emoji_filter = True
    setattr(sender_class, method_name, filtered)


_PYROGRAM_METHODS = {
    "send_message": (("text", "entities"),),
    "edit_message_text": (("text", "entities"),),
    "send_photo": (("caption", "caption_entities"),),
    "send_video": (("caption", "caption_entities"),),
    "send_audio": (("caption", "caption_entities"),),
    "send_document": (("caption", "caption_entities"),),
    "send_animation": (("caption", "caption_entities"),),
    "send_voice": (("caption", "caption_entities"),),
    "edit_message_caption": (("caption", "caption_entities"),),
    "copy_message": (("caption", "caption_entities"),),
    "answer_callback_query": (("text", None),),
    "send_media_group": (),
    "edit_message_media": (),
    "edit_message_reply_markup": (),
    "set_bot_commands": (),
}
_PTB_METHODS = {
    **_PYROGRAM_METHODS,
    "copy_message": (("caption", "caption_entities"),),
    "set_my_commands": (),
}


def activate_plain_text_output() -> None:
    """Style outgoing bot text and keyboard labels, removing every emoji."""
    from pyrogram import Client
    from telegram import Bot
    from telegram.ext import ExtBot
    from telethon import TelegramClient

    for sender_class in (Client, Bot, ExtBot):
        methods = _PTB_METHODS if sender_class in (Bot, ExtBot) else _PYROGRAM_METHODS
        for method_name, text_fields in methods.items():
            _patch_sender_method(sender_class, method_name, text_fields)

    # A small number of management utilities still send through this MTProto client.
    _patch_sender_method(
        TelegramClient,
        "send_message",
        (("message", "formatting_entities"),),
    )
    _patch_sender_method(
        TelegramClient,
        "edit_message",
        (("message", "formatting_entities"),),
    )
    _patch_sender_method(TelegramClient, "send_file", (("caption", None),))
