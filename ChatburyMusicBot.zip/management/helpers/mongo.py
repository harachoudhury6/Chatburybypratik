from config import settings
from database import get_client, get_database

MONGO_URL = settings.MONGO_DB_URI

client = get_client()
db = get_database(settings.MONGO_DB_NAME)

antiedit_db = db["antiedit"]
