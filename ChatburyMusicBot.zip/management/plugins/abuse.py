from pyrogram import filters, enums
from pyrogram.types import InlineKeyboardButton as IKB, InlineKeyboardMarkup as IKM, Message, CallbackQuery
from pyrogram.enums import ButtonStyle, ChatMemberStatus
from management import pbot, prefix_cmds, font
from management.db.abuse_db import set_abuse_state, is_abuse_enabled
from management.helpers.decorator import protected_ids

__module__ = "𝐀ɴᴛɪ-𝐀ʙᴜsᴇ🚫"
__help__ = """
*Abuse Filter🚫* — Multilingual text/OCR checks with persistent three-strike warnings

• `/abuse` — Toggle abuse filter or check status.

Messages and readable media text are checked by the shared moderation handler.
Three violations in the same group cause a ban when the bot has the required permission.
"""

async def is_user_admin(chat_id: int, user_id: int):
    from management.helpers.decorator import user_admin_cache
    if user_id in protected_ids:
        return True
    k = (chat_id, user_id, 'a')
    res = user_admin_cache.get(k)
    if res is not None:
        return res
    try:
        member = await pbot.get_chat_member(chat_id, user_id)
        res = member.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)
        user_admin_cache[k] = res
        return res
    except:
        return False

async def get_abuse_keyboard(chat_id: int):
    enabled = await is_abuse_enabled(chat_id)
    if enabled:
        text = "🟢 Abuse Filter: ON"
    else:
        text = "🔴 Abuse Filter: OFF"

    return IKM([[IKB(font(text), callback_data="abuse_toggle", style=ButtonStyle.SUCCESS if enabled else ButtonStyle.DANGER)]])

@pbot.on_message(filters.command("abuse", prefixes=prefix_cmds) & filters.group)
async def abuse_cmd(_, message: Message):
    if not await is_user_admin(message.chat.id, message.from_user.id):
        return await message.reply_text(font("❌ You must be an admin to use this command."))

    if len(message.command) > 1:
        arg = message.command[1].lower()
        if arg == "on":
            await set_abuse_state(message.chat.id, True)
            return await message.reply_text(font("✅ Abuse Filter <b>Enabled</b>."), reply_markup=await get_abuse_keyboard(message.chat.id), parse_mode=enums.ParseMode.HTML)
        elif arg == "off":
            await set_abuse_state(message.chat.id, False)
            return await message.reply_text(font("❌ Abuse Filter <b>Disabled</b>."), reply_markup=await get_abuse_keyboard(message.chat.id), parse_mode=enums.ParseMode.HTML)

    enabled = await is_abuse_enabled(message.chat.id)
    status = "Enabled" if enabled else "Disabled"
    await message.reply_text(
        font(f"🚫 <b>Abuse Filter Status:</b> {status}\n\nClick the button below to toggle."),
        reply_markup=await get_abuse_keyboard(message.chat.id),
        parse_mode=enums.ParseMode.HTML
    )

@pbot.on_callback_query(filters.regex(r"^abuse_toggle$"))
async def abuse_toggle_cb(_, query: CallbackQuery):
    user_id = query.from_user.id
    chat_id = query.message.chat.id

    if not await is_user_admin(chat_id, user_id):
        return await query.answer(font("❌ This button is for admins only!"), show_alert=True)

    enabled = await is_abuse_enabled(chat_id)
    new_state = not enabled
    await set_abuse_state(chat_id, new_state)

    status = "Enabled" if new_state else "Disabled"
    await query.message.edit_text(
        font(f"🚫 <b>Abuse Filter Status:</b> {status}\n\nClick the button below to toggle."),
        reply_markup=await get_abuse_keyboard(chat_id),
        parse_mode=enums.ParseMode.HTML
    )
    await query.answer(font(f"Abuse Filter {'Enabled' if new_state else 'Disabled'}"))
