"""Shared text/media moderation pipeline for the existing management bot."""

from __future__ import annotations

import asyncio
import html
import logging
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import Any

from pyrogram import StopPropagation, enums, filters
from pyrogram.enums import ChatMemberStatus
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import settings
from management import LOGGER, pbot, prefix_cmds
from management.db.abuse_db import is_abuse_enabled
from management.db.antinsfw_db import get_antinsfw, get_antinsfw_admin
from management.db.approval_db import is_user_approved
from management.db.moderation import (
    add_audit_record,
    add_strike,
    claim_message,
    clear_chat_setting,
    get_chat_settings,
    get_recent_audit,
    get_strike_record,
    reset_strikes,
    set_chat_setting,
    set_strike_count,
)
from management.helpers.media_moderation import (
    MAX_MEDIA_BYTES,
    nsfw_engine,
    scan_message_media,
)
from management.helpers.decorator import protected_ids
from management.helpers.moderation_rules import (
    classify_selling,
    find_abusive_term,
    has_explicit_caption_context,
    has_medical_context,
    normalized_forms,
    spam_signals,
    valid_telegram_url,
)

logger = logging.getLogger("eiko.management.moderation")
__module__ = "𝐆𝐂 𝐌𝐨𝐝𝐞𝐫𝐚𝐭𝐢𝐨𝐧🛡️"
__help__ = """
*Group moderation*

• `/moderationstatus` — Show active filters and bot permissions.
• `/sellingmod on|off` — Enable/disable selling-post moderation.
• `/setsellinggc <Telegram invite URL|off>` — Configure its button destination.
• `/modthresholds [repeat|mentions|selling|explicit] <value>` — Tune thresholds.
• `/abuseword add|remove <word or phrase>` and `/abuseword list`.
• `/modwarns <reply|user ID|@username>` — Check the three-strike counter.
• `/modsetwarns <user> <0-3>` / `/modresetwarns <user>` — Admin strike controls.
• `/moderationlogs [1-20]` — Recent moderation actions.

Text OCR uses the installed languages selected by MODERATION_OCR_LANGUAGES.
Image/video classification uses the local NudeNet ONNX model; media that cannot be
downloaded or decoded is reported as uninspected and is not auto-banned.
"""

_recent_messages: dict[tuple[int, int], deque[tuple[float, str, int]]] = defaultdict(deque)
_processed_keys: set[str] = set()
_processed_order: deque[str] = deque(maxlen=5000)


async def _is_group_admin(client: Any, chat_id: int, user_id: int) -> bool | None:
    if user_id in protected_ids:
        return True
    try:
        member = await client.get_chat_member(chat_id, user_id)
        return member.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)
    except Exception as exc:
        logger.warning("Could not verify group role (%s).", type(exc).__name__)
        return None


def _mention(user: Any) -> str:
    first_name = html.escape(getattr(user, "first_name", None) or "User")
    return _mention_id(int(user.id), first_name, already_escaped=True)


def _mention_id(user_id: int, name: str, already_escaped: bool = False) -> str:
    first_name = name if already_escaped else html.escape(name or "User")
    return f'<a href="tg://user?id={int(user_id)}">{first_name}</a>'


def _is_bot_sender(client: Any, user: Any) -> bool:
    if not user:
        return False
    if getattr(user, "is_bot", False):
        return True
    own_user = getattr(client, "me", None)
    return getattr(own_user, "id", None) == getattr(user, "id", None)


async def _claim_action(chat_id: int, message_id: int) -> bool:
    key = f"{chat_id}:{message_id}"
    if key in _processed_keys:
        return False
    # Add synchronously before awaiting Mongo so simultaneous delivery in this
    # process cannot perform the same action twice.
    if len(_processed_order) == _processed_order.maxlen:
        expired = _processed_order.popleft()
        _processed_keys.discard(expired)
    _processed_keys.add(key)
    _processed_order.append(key)
    try:
        return await claim_message(chat_id, message_id)
    except Exception as exc:
        logger.warning("Moderation dedupe storage failed (%s); using process-local guard.", type(exc).__name__)
        return True


async def _audit(
    client: Any,
    message: Message,
    action: str,
    reason: str,
) -> None:
    user_id = message.from_user.id if message.from_user else 0
    try:
        await add_audit_record(
            chat_id=message.chat.id,
            user_id=user_id,
            message_id=message.id,
            action=action,
            reason=reason,
        )
    except Exception as exc:
        logger.warning("Moderation audit database write failed (%s).", type(exc).__name__)
    if settings.LOG_GROUP_ID:
        try:
            await client.send_message(
                settings.LOG_GROUP_ID,
                "<b>Moderation action</b>\n"
                f"Group: <code>{message.chat.id}</code>\n"
                f"User: <code>{user_id}</code>\n"
                f"Reason: {html.escape(reason[:250])}\n"
                f"Action: <code>{html.escape(action)}</code>\n"
                f"Message: <code>{message.id}</code>\n"
                f"Time: <code>{datetime.now(timezone.utc).isoformat()}</code>",
                parse_mode=enums.ParseMode.HTML,
            )
        except Exception as exc:
            logger.warning("Moderation log delivery failed (%s).", type(exc).__name__)


async def _delete_message(message: Message) -> bool:
    try:
        await message.delete()
        return True
    except Exception as exc:
        logger.info(
            "Could not delete moderation target chat=%s message=%s (%s).",
            message.chat.id,
            message.id,
            type(exc).__name__,
        )
        return False


async def _delete_after(message: Any, seconds: int = 60) -> None:
    await asyncio.sleep(seconds)
    try:
        await message.delete()
    except Exception as exc:
        logger.info("Temporary moderation notice cleanup failed (%s).", type(exc).__name__)


async def _send_notice(client: Any, chat_id: int, text: str, markup=None, ttl: int = 60):
    sent = await client.send_message(
        chat_id,
        text,
        reply_markup=markup,
        parse_mode=enums.ParseMode.HTML,
        disable_web_page_preview=True,
    )
    asyncio.create_task(_delete_after(sent, ttl))
    return sent


async def _handle_abuse(client: Any, message: Message, term: str) -> None:
    if _is_bot_sender(client, getattr(message, "from_user", None)):
        logger.info("Ignoring bot-authored abuse candidate chat=%s message=%s.", message.chat.id, message.id)
        return
    chat_id, user_id = message.chat.id, message.from_user.id
    if not await _claim_action(chat_id, message.id):
        return

    deleted = await _delete_message(message)
    try:
        count = await add_strike(
            chat_id,
            user_id,
            "Abusive text detected",
            message.id,
        )
        if count > 3:
            await set_strike_count(chat_id, user_id, 3)
    except Exception as exc:
        logger.error("Could not persist abuse warning (%s).", type(exc).__name__)
        await _send_notice(
            client,
            chat_id,
            f"⚠️ {_mention(message.from_user)}, abusive language is not allowed. "
            "The warning counter could not be saved; an admin has been notified."
            + (
                ""
                if deleted
                else " I could not delete the message; an admin should check my delete permission."
            ),
            ttl=30,
        )
        await _audit(client, message, "delete_warning_storage_failed", "abusive text")
        return

    count = min(max(1, count), 3)
    if count >= 3:
        banned = False
        try:
            await client.ban_chat_member(chat_id, user_id)
            banned = True
        except Exception as exc:
            logger.warning("Third-strike ban failed (%s).", type(exc).__name__)
        if banned:
            result_notice = (
                f"🚫 {_mention(message.from_user)} was banned after repeated abuse (Warning 3/3)."
                + (
                    ""
                    if deleted
                    else " The original message could not be deleted; check my delete-message permission."
                )
            )
        else:
            result_notice = (
                f"⚠️ {_mention(message.from_user)}, repeated abuse reached Warning 3/3. "
                + (
                    "You were not banned; check my ban-member permission."
                    if deleted
                    else "The message could not be deleted or you could not be banned; check my delete/ban permissions."
                )
            )
        try:
            unban_markup = InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "Unban member (admins)",
                        callback_data=f"abuse_unban:{chat_id}:{user_id}",
                    )
                ]]
            )
            await _send_notice(
                client,
                chat_id,
                result_notice,
                markup=unban_markup if banned else None,
                ttl=60,
            )
        except Exception as exc:
            logger.info("Third-strike notice delivery failed (%s).", type(exc).__name__)
        await _audit(
            client,
            message,
            "ban" if banned else "ban_failed",
            "third abusive-language warning",
        )
        return

    try:
        await _send_notice(
            client,
            chat_id,
            f"⚠️ {_mention(message.from_user)}, abusing is not allowed! "
            f"Warning {count}/3. Please stop."
            + (
                ""
                if deleted
                else "\n⚠️ I could not delete the message; an admin should check my delete-message permission."
            ),
            ttl=30,
        )
    except Exception as exc:
        logger.info("Abuse warning delivery failed (%s).", type(exc).__name__)
    await _audit(client, message, "warning", "abusive text")


@pbot.on_callback_query(filters.regex(r"^abuse_unban:(-?\d+):(\d+)$"))
async def abuse_unban_button(_, query) -> None:
    """Let only a current administrator undo this group's automatic abuse ban."""
    match = query.matches[0] if query.matches else None
    if not match or not query.message or not query.from_user:
        return await query.answer("This unban action is unavailable.", show_alert=True)
    chat_id, target_id = int(match.group(1)), int(match.group(2))
    if query.message.chat.id != chat_id or query.message.chat.type not in (
        enums.ChatType.GROUP,
        enums.ChatType.SUPERGROUP,
    ):
        return await query.answer("This button belongs to another group.", show_alert=True)
    try:
        actor = await pbot.get_chat_member(chat_id, query.from_user.id)
        if actor.status not in (
            ChatMemberStatus.ADMINISTRATOR,
            ChatMemberStatus.OWNER,
        ):
            return await query.answer("Only this group's admins can unban.", show_alert=True)
        bot_user = getattr(pbot, "me", None)
        bot_id = getattr(bot_user, "id", None) or getattr(pbot, "id", None)
        if bot_id and target_id == bot_id:
            return await query.answer("The bot cannot unban itself.", show_alert=True)
        target = await pbot.get_chat_member(chat_id, target_id)
        if target.status != ChatMemberStatus.BANNED:
            return await query.answer("This member is not banned now.", show_alert=True)
        await pbot.unban_chat_member(chat_id, target_id)
        try:
            await query.message.edit_text(
                f"{_mention(target.user)} was unbanned by a group admin.",
                reply_markup=None,
            )
        except Exception:
            pass
        try:
            await add_audit_record(
                chat_id=chat_id,
                user_id=target_id,
                message_id=query.message.id,
                action="admin_unban",
                reason=f"Unbanned by group admin {query.from_user.id}",
            )
        except Exception as exc:
            logger.info("Could not store abuse-unban audit (%s).", type(exc).__name__)
        await query.answer("Member unbanned.")
    except Exception as exc:
        logger.warning("Abuse unban button failed (%s).", type(exc).__name__)
        await query.answer("Could not unban. Check the bot's ban permission.", show_alert=True)


async def _handle_explicit_media(
    client: Any, message: Message, category: str, confidence: float
) -> None:
    user = getattr(message, "from_user", None)
    if _is_bot_sender(client, user):
        logger.info("Ignoring bot-authored explicit-media candidate chat=%s message=%s.", message.chat.id, message.id)
        return
    if not await _claim_action(message.chat.id, message.id):
        return
    deleted = await _delete_message(message)
    if not user:
        await _audit(client, message, "media_removed", "high-confidence explicit media; sender unavailable")
        return
    banned = False
    try:
        await client.ban_chat_member(message.chat.id, user.id)
        banned = True
    except Exception as exc:
        logger.warning("Explicit-media ban failed (%s).", type(exc).__name__)
    try:
        await _send_notice(
            client,
            message.chat.id,
            f"🔞 {_mention(user)}, clearly explicit media is not allowed here. "
            + (
                (
                    "The content was removed and you were banned."
                    if deleted
                    else "You were banned, but I could not delete the content; check my delete-message permission."
                )
                if banned
                else (
                    "The content was removed, but I could not ban the sender; check my ban-member permission."
                    if deleted
                    else "I could not delete or ban; check my delete and ban-member permissions."
                )
            ),
            ttl=60,
        )
    except Exception as exc:
        logger.info("Explicit-media notice delivery failed (%s).", type(exc).__name__)
    await _audit(
        client,
        message,
        "ban" if banned else "media_removed_ban_failed",
        f"high-confidence explicit media ({category}, {confidence:.2f})",
    )


async def _handle_selling(
    client: Any, message: Message, destination: str | None
) -> None:
    if not await _claim_action(message.chat.id, message.id):
        return
    await _delete_message(message)
    sender = _mention(message.from_user)
    if not destination or not valid_telegram_url(destination):
        try:
            await _send_notice(
                client,
                message.chat.id,
                "⚙️ A likely selling post was removed, but the Selling GC link is missing or invalid. "
                "Admins: configure the official invite with <code>/setsellinggc &lt;Telegram URL&gt;</code>.",
            )
        except Exception as exc:
            logger.info("Selling configuration notice delivery failed (%s).", type(exc).__name__)
        await _audit(client, message, "selling_deleted_unconfigured", "selling/advertisement; no valid destination")
        return

    markup = InlineKeyboardMarkup(
        [[InlineKeyboardButton("🛍️ Join Selling GC", url=destination)]]
    )
    try:
        await _send_notice(
            client,
            message.chat.id,
            f"🚫 {sender}, selling is not allowed in this group. Please use the official Selling GC below.",
            markup,
            ttl=60,
        )
    except Exception as exc:
        logger.info("Selling notice delivery failed (%s).", type(exc).__name__)
    await _audit(client, message, "selling_deleted", "selling/advertisement post")


async def _handle_spam(
    client: Any,
    message: Message,
    signals: list[str],
    recent_ids: list[int] | None = None,
) -> None:
    if not await _claim_action(message.chat.id, message.id):
        return
    for message_id in dict.fromkeys([*(recent_ids or []), message.id]):
        try:
            await client.delete_messages(message.chat.id, message_id)
        except Exception as exc:
            logger.info("Spam message deletion failed (%s).", type(exc).__name__)
    user = message.from_user
    if user:
        mention = _mention(user)
        if "repeated_message_limit" in signals:
            try:
                await client.ban_chat_member(message.chat.id, user.id)
                action = "ban"
                suffix = " The sender was banned after repeating the same message."
            except Exception as exc:
                logger.warning("Repeated-message ban failed (%s).", type(exc).__name__)
                action = "ban_failed"
                suffix = " I could not ban the sender; check my ban-member permission."
        else:
            action = "delete_spam"
            suffix = ""
        try:
            await _send_notice(
                client,
                message.chat.id,
                f"🚫 {mention}, this message was removed by the group spam filter.{suffix}",
                ttl=30,
            )
        except Exception as exc:
            logger.info("Spam notice delivery failed (%s).", type(exc).__name__)
    else:
        action = "delete_spam"
    await _audit(client, message, action, ", ".join(signals))


def _count_mentions(message: Message, text: str) -> int:
    entities = getattr(message, "entities", None) or getattr(message, "caption_entities", None) or []
    entity_mentions = 0
    for entity in entities:
        kind = str(getattr(entity, "type", "")).lower()
        if "mention" in kind:
            entity_mentions += 1
    return max(entity_mentions, len(re.findall(r"(?<!\w)@[A-Za-z0-9_]{3,}", text or "")))


def _record_repeat(chat_id: int, user_id: int, text: str, message_id: int) -> tuple[int, list[int]]:
    forms = normalized_forms(text)
    normalized = (
        sorted(forms, key=lambda form: (not form.isascii(), len(form)))[0]
        if forms
        else ""
    )
    if not normalized:
        return 0, []
    now = time.monotonic()
    history = _recent_messages[(chat_id, user_id)]
    while history and now - history[0][0] > 30:
        history.popleft()
    history.append((now, normalized, message_id))
    while len(history) > 50:
        history.popleft()
    if len(_recent_messages) > 5000:
        for old_key, old_history in list(_recent_messages.items()):
            while old_history and now - old_history[0][0] > 30:
                old_history.popleft()
            if not old_history:
                _recent_messages.pop(old_key, None)
    matches = [item[2] for item in history if item[1] == normalized]
    return len(matches), matches


async def _moderate_message(client: Any, message: Message) -> None:
    if not message.chat or not message.from_user or _is_bot_sender(client, message.from_user):
        return
    user = message.from_user
    text = message.text or message.caption or ""
    # Slash commands are handled by the bot's existing command modules.
    if message.text and message.text.lstrip().startswith(tuple(prefix_cmds)):
        return
    chat_id = message.chat.id
    try:
        is_admin = await _is_group_admin(client, chat_id, user.id)
        if is_admin is None:
            # Do not act when Telegram cannot verify whether this sender is an admin.
            return
    except Exception as exc:
        logger.warning("Could not verify moderation role (%s).", type(exc).__name__)
        return
    try:
        if await is_user_approved(chat_id, user.id):
            return
    except Exception as exc:
        logger.warning("Could not verify approved-user exemption (%s).", type(exc).__name__)
        return

    abuse_enabled = False
    user_nsfw_enabled = False
    admin_nsfw_enabled = False
    try:
        abuse_enabled, user_nsfw_enabled, admin_nsfw_enabled = await asyncio.gather(
            is_abuse_enabled(chat_id),
            get_antinsfw(chat_id),
            get_antinsfw_admin(chat_id),
        )
    except Exception as exc:
        logger.warning("Could not read moderation settings (%s).", type(exc).__name__)
    chat_settings: dict[str, Any] = {}
    try:
        chat_settings = await get_chat_settings(chat_id)
    except Exception as exc:
        logger.warning("Could not read selling/spam settings (%s).", type(exc).__name__)
        chat_settings = {
            "selling_enabled": False,
            "selling_gc_url": settings.SELLING_GC_URL,
            "selling_min_score": 4,
            "spam_repeat_limit": 5,
            "spam_mention_limit": 8,
            "explicit_threshold": 0.95,
        }
    if is_admin:
        abuse_enabled = False
        user_nsfw_enabled = False
        chat_settings["selling_enabled"] = False

    custom_terms: list[str] = []
    if abuse_enabled and text:
        try:
            custom_terms = chat_settings.get("abuse_terms", [])
        except Exception:
            custom_terms = []
        term = find_abusive_term(text, custom_terms)
        # If explicit-media checking is enabled, preserve its higher ban priority.
        # Otherwise remove abusive captions/text before spending time on OCR.
        if term and not (user_nsfw_enabled or admin_nsfw_enabled):
            await _handle_abuse(client, message, term)
            raise StopPropagation

    media_scan = None
    should_scan_media = user_nsfw_enabled or admin_nsfw_enabled or abuse_enabled
    if should_scan_media:
        media_scan = await scan_message_media(client, message)

    # High-confidence explicit content has priority over ordinary strikes.
    if media_scan and media_scan.has_media and media_scan.analyzed and (
        user_nsfw_enabled or admin_nsfw_enabled
    ):
        try:
            result = await nsfw_engine.classify(
                media_scan.frames,
                float(chat_settings.get("explicit_threshold", 0.95)),
                has_explicit_caption_context(f"{text}\n{media_scan.ocr_text}"),
            )
        except Exception as exc:
            logger.warning("Local explicit-media analysis failed (%s).", type(exc).__name__)
            result = {"explicit": False, "category": "", "confidence": 0.0}
        if result["explicit"] and not has_medical_context(
            f"{text}\n{media_scan.ocr_text}"
        ):
            await _handle_explicit_media(
                client,
                message,
                str(result["category"]),
                float(result["confidence"]),
            )
            raise StopPropagation

    if abuse_enabled and text:
        term = find_abusive_term(text, custom_terms)
        if term:
            await _handle_abuse(client, message, term)
            raise StopPropagation

    if abuse_enabled and media_scan and media_scan.ocr_analyzed and media_scan.ocr_text:
        term = find_abusive_term(media_scan.ocr_text, custom_terms)
        if term:
            await _handle_abuse(client, message, term)
            raise StopPropagation

    if not is_admin and chat_settings.get("selling_enabled") and text:
        detected, _score = classify_selling(
            text,
            int(chat_settings.get("selling_min_score", 4)),
        )
        if detected:
            await _handle_selling(
                client,
                message,
                chat_settings.get("selling_gc_url"),
            )
            raise StopPropagation

    if text and not is_admin:
        signals = spam_signals(
            text,
            int(chat_settings.get("spam_mention_limit", 8)),
        )
        mention_limit = int(chat_settings.get("spam_mention_limit", 8))
        if _count_mentions(message, text) >= mention_limit and "excessive_mentions" not in signals:
            signals.append("excessive_mentions")

        repeated_count, repeated_ids = _record_repeat(
            chat_id, user.id, text, message.id
        )
        if repeated_count >= int(chat_settings.get("spam_repeat_limit", 5)):
            signals.append("repeated_message_limit")
        if signals:
            await _handle_spam(
                client,
                message,
                signals,
                repeated_ids if "repeated_message_limit" in signals else None,
            )
            raise StopPropagation

    if media_scan and media_scan.has_media and (not media_scan.analyzed or media_scan.reason):
        logger.info(
            "Media analysis incomplete chat=%s message=%s reason=%s",
            chat_id,
            message.id,
            media_scan.reason or "unknown",
        )


@pbot.on_message(filters.group & ~filters.bot, group=-3)
async def moderation_message_handler(client, message: Message):
    try:
        await _moderate_message(client, message)
    except StopPropagation:
        raise
    except Exception as exc:
        logger.error(
            "Moderation handler failed chat=%s message=%s (%s).",
            getattr(getattr(message, "chat", None), "id", 0),
            getattr(message, "id", 0),
            type(exc).__name__,
        )


@pbot.on_edited_message(filters.group & ~filters.bot, group=-3)
async def moderation_edited_message_handler(client, message: Message):
    await moderation_message_handler(client, message)


async def _require_admin(message: Message) -> bool:
    if not message.from_user or not await _is_group_admin(
        pbot, message.chat.id, message.from_user.id
    ):
        await message.reply_text("⛔ This command is for group admins only.")
        return False
    return True


async def _database_error(message: Message, operation: str, exc: Exception):
    logger.warning(
        "Moderation database operation %s failed (%s).",
        operation,
        type(exc).__name__,
    )
    return await message.reply_text(
        "⚠️ Moderation storage is unavailable right now. Please try again later."
    )


async def _resolve_target(message: Message, args: list[str]) -> tuple[int, str] | None:
    reply = getattr(message, "reply_to_message", None)
    if reply and reply.from_user:
        return reply.from_user.id, reply.from_user.first_name or str(reply.from_user.id)
    if not args:
        return None
    value = args[0].strip()
    if value.isdigit():
        return int(value), value
    try:
        user = await pbot.get_users(value if value.startswith("@") else f"@{value}")
        return user.id, user.first_name or str(user.id)
    except Exception:
        return None


@pbot.on_message(filters.command("setsellinggc", prefixes=prefix_cmds) & filters.group)
async def set_selling_gc_command(_, message: Message):
    if not await _require_admin(message):
        return
    args = message.command[1:]
    if not args:
        return await message.reply_text(
            "Usage: <code>/setsellinggc https://t.me/your_official_invite</code>\n"
            "Use <code>/setsellinggc off</code> to clear the per-group override.",
            parse_mode=enums.ParseMode.HTML,
        )
    value = args[0].strip()
    if value.lower() == "off":
        try:
            await clear_chat_setting(message.chat.id, "selling_gc_url")
        except Exception as exc:
            return await _database_error(message, "clear selling URL", exc)
        return await message.reply_text(
            "✅ Per-group override cleared. The configured global default will be used if set."
        )
    if not valid_telegram_url(value):
        return await message.reply_text(
            "⚠️ Invalid link. Use an official HTTPS invite URL on t.me or telegram.me."
        )
    try:
        await set_chat_setting(message.chat.id, "selling_gc_url", value)
    except Exception as exc:
        return await _database_error(message, "save selling URL", exc)
    await message.reply_text(
        "✅ Selling GC destination saved. Run <code>/sellingmod on</code> to enable moderation.",
        parse_mode=enums.ParseMode.HTML,
    )


@pbot.on_message(filters.command("sellingmod", prefixes=prefix_cmds) & filters.group)
async def selling_moderation_command(_, message: Message):
    if not await _require_admin(message):
        return
    args = message.command[1:]
    if not args or args[0].lower() not in {"on", "off"}:
        try:
            config = await get_chat_settings(message.chat.id)
        except Exception as exc:
            return await _database_error(message, "read selling setting", exc)
        return await message.reply_text(
            f"Selling moderation: <b>{'ON' if config['selling_enabled'] else 'OFF'}</b>\n"
            "Usage: <code>/sellingmod on</code> or <code>/sellingmod off</code>",
            parse_mode=enums.ParseMode.HTML,
        )
    enabled = args[0].lower() == "on"
    try:
        config = await get_chat_settings(message.chat.id)
    except Exception as exc:
        return await _database_error(message, "read selling setting", exc)
    if enabled and not valid_telegram_url(config.get("selling_gc_url", "")):
        return await message.reply_text(
            "⚠️ Selling moderation was not enabled: the Selling GC URL is missing or invalid. "
            "Admins must first use <code>/setsellinggc &lt;official Telegram URL&gt;</code>.",
            parse_mode=enums.ParseMode.HTML,
        )
    try:
        await set_chat_setting(message.chat.id, "selling_enabled", enabled)
    except Exception as exc:
        return await _database_error(message, "save selling setting", exc)
    await message.reply_text(f"✅ Selling moderation {'enabled' if enabled else 'disabled'}.")


@pbot.on_message(filters.command("modthresholds", prefixes=prefix_cmds) & filters.group)
async def moderation_thresholds_command(_, message: Message):
    if not await _require_admin(message):
        return
    try:
        config = await get_chat_settings(message.chat.id)
    except Exception as exc:
        return await _database_error(message, "read moderation thresholds", exc)
    args = message.command[1:]
    options = {
        "repeat": ("spam_repeat_limit", 4, 12, int),
        "mentions": ("spam_mention_limit", 3, 30, int),
        "selling": ("selling_min_score", 3, 8, int),
        "explicit": ("explicit_threshold", 0.80, 0.99, float),
    }
    if not args:
        return await message.reply_text(
            "<b>Current thresholds</b>\n"
            f"Repeated identical messages before ban: <code>{config['spam_repeat_limit']}</code>\n"
            f"Mentions before delete: <code>{config['spam_mention_limit']}</code>\n"
            f"Selling confidence score: <code>{config['selling_min_score']}</code>\n"
            f"Explicit-media confidence: <code>{config['explicit_threshold']:.2f}</code>\n\n"
            "Use <code>/modthresholds repeat|mentions|selling|explicit value</code>.",
            parse_mode=enums.ParseMode.HTML,
        )
    if len(args) != 2 or args[0].lower() not in options:
        return await message.reply_text(
            "Usage: <code>/modthresholds repeat|mentions|selling|explicit value</code>",
            parse_mode=enums.ParseMode.HTML,
        )
    key, minimum, maximum, parser = options[args[0].lower()]
    try:
        value = parser(args[1])
    except ValueError:
        return await message.reply_text("⚠️ Threshold must be a number.")
    if not minimum <= value <= maximum:
        return await message.reply_text(
            f"⚠️ Value must be between {minimum} and {maximum}."
        )
    try:
        await set_chat_setting(message.chat.id, key, value)
    except Exception as exc:
        return await _database_error(message, "save moderation threshold", exc)
    await message.reply_text(f"✅ Threshold updated to <code>{value}</code>.", parse_mode=enums.ParseMode.HTML)


@pbot.on_message(filters.command("abuseword", prefixes=prefix_cmds) & filters.group)
async def abuse_word_command(_, message: Message):
    if not await _require_admin(message):
        return
    args = message.command[1:]
    if not args:
        return await message.reply_text(
            "Usage: <code>/abuseword add|remove|list [word or phrase]</code>",
            parse_mode=enums.ParseMode.HTML,
        )
    try:
        config = await get_chat_settings(message.chat.id)
    except Exception as exc:
        return await _database_error(message, "read abuse terms", exc)
    terms = list(config.get("abuse_terms", []))
    action = args[0].lower()
    if action == "list":
        listing = "\n".join(f"• {html.escape(term)}" for term in terms) or "No group-specific terms."
        return await message.reply_text(listing, parse_mode=enums.ParseMode.HTML)
    term = " ".join(args[1:]).strip()
    if action not in {"add", "remove"} or not 2 <= len(term) <= 80:
        return await message.reply_text(
            "Usage: <code>/abuseword add|remove &lt;word or phrase&gt;</code>",
            parse_mode=enums.ParseMode.HTML,
        )
    if action == "add":
        if term.casefold() not in {item.casefold() for item in terms}:
            terms.append(term)
    else:
        terms = [item for item in terms if item.casefold() != term.casefold()]
    try:
        await set_chat_setting(message.chat.id, "abuse_terms", terms)
    except Exception as exc:
        return await _database_error(message, "save abuse terms", exc)
    verb = "added" if action == "add" else "removed"
    await message.reply_text(f"✅ Group-specific abuse term {verb}.")


@pbot.on_message(filters.command("moderationstatus", prefixes=prefix_cmds) & filters.group)
async def moderation_status_command(_, message: Message):
    if not await _require_admin(message):
        return
    chat_id = message.chat.id
    try:
        abuse_enabled, nsfw_users, nsfw_admins = await asyncio.gather(
            is_abuse_enabled(chat_id),
            get_antinsfw(chat_id),
            get_antinsfw_admin(chat_id),
        )
        config = await get_chat_settings(chat_id)
        bot_member = await pbot.get_chat_member(chat_id, pbot.me.id)
        privileges = getattr(bot_member, "privileges", None)
        delete_permission = bool(getattr(privileges, "can_delete_messages", False))
        ban_permission = bool(getattr(privileges, "can_restrict_members", False))
        details = (
            f"Abuse + OCR: {'ON' if abuse_enabled else 'OFF'}\n"
            f"Explicit media, members: {'ON' if nsfw_users else 'OFF'}\n"
            f"Explicit media, admins: {'ON' if nsfw_admins else 'OFF'}\n"
            f"Selling moderation: {'ON' if config['selling_enabled'] else 'OFF'}\n"
            f"Selling GC URL: {'configured' if valid_telegram_url(config['selling_gc_url']) else 'missing/invalid'}\n"
            f"Local explicit model: {nsfw_engine.state}\n"
            f"Media analysis size limit: {MAX_MEDIA_BYTES // (1024 * 1024)} MiB\n"
            f"Bot permissions: delete={delete_permission}, ban/restrict={ban_permission}"
        )
        await message.reply_text(f"<b>Moderation status</b>\n{html.escape(details)}", parse_mode=enums.ParseMode.HTML)
    except Exception as exc:
        logger.warning("Moderation status check failed (%s).", type(exc).__name__)
        await message.reply_text("⚠️ Could not read all moderation settings or bot permissions.")


@pbot.on_message(filters.command("modwarns", prefixes=prefix_cmds) & filters.group)
async def moderation_warns_command(_, message: Message):
    if not await _require_admin(message):
        return
    target = await _resolve_target(message, message.command[1:])
    if not target:
        return await message.reply_text("Reply to a user or use <code>/modwarns user_id</code>.", parse_mode=enums.ParseMode.HTML)
    try:
        record = await get_strike_record(message.chat.id, target[0])
    except Exception as exc:
        return await _database_error(message, "read warning count", exc)
    count = min(3, int(record.get("count", 0)))
    history = record.get("reasons", [])[-5:]
    recent = "\n".join(
        f"• {html.escape(str(item.get('reason', 'violation') if isinstance(item, dict) else item))}"
        for item in history
    )
    suffix = f"\nRecent reasons:\n{recent}" if recent else ""
    await message.reply_text(
        f"⚠️ {_mention_id(target[0], target[1])} "
        f"has <b>{count}/3</b> automatic moderation warnings.{suffix}",
        parse_mode=enums.ParseMode.HTML,
    )


@pbot.on_message(filters.command("modresetwarns", prefixes=prefix_cmds) & filters.group)
async def moderation_reset_warns_command(_, message: Message):
    if not await _require_admin(message):
        return
    target = await _resolve_target(message, message.command[1:])
    if not target:
        return await message.reply_text("Reply to a user or use <code>/modresetwarns user_id</code>.", parse_mode=enums.ParseMode.HTML)
    try:
        await reset_strikes(message.chat.id, target[0])
    except Exception as exc:
        return await _database_error(message, "reset warning count", exc)
    await message.reply_text("✅ Automatic moderation warnings reset to 0/3.")


@pbot.on_message(filters.command("modsetwarns", prefixes=prefix_cmds) & filters.group)
async def moderation_set_warns_command(_, message: Message):
    if not await _require_admin(message):
        return
    args = message.command[1:]
    if message.reply_to_message and message.reply_to_message.from_user:
        target = (
            message.reply_to_message.from_user.id,
            message.reply_to_message.from_user.first_name or "User",
        )
        count_arg = args[0] if args else ""
    else:
        target = await _resolve_target(message, args[:1])
        count_arg = args[1] if len(args) > 1 else ""
    if not target or count_arg not in {"0", "1", "2", "3"}:
        return await message.reply_text(
            "Usage: <code>/modsetwarns user_id 0-3</code>, or reply to a user with <code>/modsetwarns 0-3</code>.",
            parse_mode=enums.ParseMode.HTML,
        )
    try:
        await set_strike_count(message.chat.id, target[0], int(count_arg))
    except Exception as exc:
        return await _database_error(message, "set warning count", exc)
    await message.reply_text(f"✅ Automatic moderation warnings set to <b>{count_arg}/3</b>.", parse_mode=enums.ParseMode.HTML)


@pbot.on_message(filters.command("moderationlogs", prefixes=prefix_cmds) & filters.group)
async def moderation_logs_command(_, message: Message):
    if not await _require_admin(message):
        return
    try:
        limit = int(message.command[1]) if len(message.command) > 1 else 10
        if not 1 <= limit <= 20:
            raise ValueError
    except ValueError:
        return await message.reply_text("Usage: <code>/moderationlogs [1-20]</code>", parse_mode=enums.ParseMode.HTML)
    try:
        entries = await get_recent_audit(message.chat.id, limit)
    except Exception as exc:
        logger.warning("Moderation log lookup failed (%s).", type(exc).__name__)
        return await message.reply_text("⚠️ Moderation log storage is unavailable.")
    if not entries:
        return await message.reply_text("No moderation actions are recorded for this group.")
    lines = ["<b>Recent moderation actions</b>"]
    for entry in entries:
        created = entry.get("created_at")
        stamp = created.strftime("%Y-%m-%d %H:%M UTC") if hasattr(created, "strftime") else "time unavailable"
        lines.append(
            f"• <code>{entry.get('action', 'action')}</code> "
            f"user <code>{entry.get('user_id', 0)}</code> — "
            f"{html.escape(str(entry.get('reason', '')))} "
            f"<i>({stamp})</i>"
        )
    await message.reply_text("\n".join(lines), parse_mode=enums.ParseMode.HTML)
