"""Permission-checked navigation dashboards built on existing bot commands."""

from __future__ import annotations

import html
import logging

from pyrogram import enums, filters, types
from pyrogram.enums import ButtonStyle

from management import BOT_NAME, font, pbot
from management.command_menu import build_group_admin_keyboard
from management.plugins.base import _add_to_group_url
from config import settings

logger = logging.getLogger("eiko.management.dashboard")

_HOME_RE = r"^illusion:(home|groups|settings|stats|profile):(\d+)$"
_GROUP_RE = r"^groupdash:(home|section|set):(-?\d+)(?::([a-z_]+))?(?::(on|off))?$"

_SECTIONS = {
    "protection": (
        "Anti-spam and protection",
        ["/flood", "/antiraid", "/antilink", "/antitag", "/antiporn"],
    ),
    "welcome": (
        "Welcome and goodbye",
        ["/welcome", "/goodbye", "/setwelcome", "/setgoodbye", "/rules"],
    ),
    "verification": (
        "Join approval and verification",
        ["/approval", "/approve", "/unapprove", "/joinmute", "/antiraid"],
    ),
    "moderation": (
        "Warnings and permissions",
        ["/warn", "/warns", "/resetwarn", "/ban", "/unban", "/mute", "/kick", "/locks"],
    ),
    "content": ("Notes and filters", ["/save <name>", "/get <name>", "/notes", "/filter", "/filters"]),
    "reports": ("Reports and audit logs", ["/report", "/logchannel", "/moderationlogs", "/stats"]),
    "group_stats": ("Group statistics", ["/stats", "/adminlist", "/reload"]),
    "backup": ("Group configuration and owner backup", ["/admin", "/musicsettings", "/language", "/backup (owner only)", "/restore (owner only)"]),
}


def _home_keyboard(user_id: int):
    from management.db.owner_profile import get_public_profile, username_url

    profile = get_public_profile()
    support_username = profile.get("support_username") or "tgnxt"
    support_url = username_url(support_username) or "https://t.me/tgnxt"
    owner_username = profile.get("owner_username")
    owner_url = username_url(owner_username)
    rows = [
        [
            types.InlineKeyboardButton(font("Music Player"), callback_data=f"music_help_home_{user_id}", style=ButtonStyle.SUCCESS),
            types.InlineKeyboardButton(font("Group Management"), callback_data=f"illusion:groups:{user_id}", style=ButtonStyle.PRIMARY),
        ],
        [
            types.InlineKeyboardButton(font("Settings"), callback_data=f"illusion:settings:{user_id}", style=ButtonStyle.PRIMARY),
            types.InlineKeyboardButton(font("Statistics"), callback_data=f"illusion:stats:{user_id}", style=ButtonStyle.PRIMARY),
        ],
        [
            types.InlineKeyboardButton(font("My Profile"), callback_data=f"illusion:profile:{user_id}", style=ButtonStyle.PRIMARY),
            types.InlineKeyboardButton(font("Help & Commands"), callback_data=f"help_{user_id}", style=ButtonStyle.PRIMARY),
        ],
        [types.InlineKeyboardButton(font(f"Support @{support_username}"), url=support_url, style=ButtonStyle.SUCCESS)],
    ]
    if owner_url:
        rows.append([types.InlineKeyboardButton(font(f"Owner @{owner_username}"), url=owner_url, style=ButtonStyle.PRIMARY)])
    return types.InlineKeyboardMarkup(
        rows
    )


def _page_markup(page: str, user_id: int, add_group_url: str | None = None):
    rows = []
    if page == "groups" and add_group_url:
        rows.append([types.InlineKeyboardButton(font("Add to a Group"), url=add_group_url, style=ButtonStyle.SUCCESS)])
    rows.append([types.InlineKeyboardButton(font("Back to Home"), callback_data=f"illusion:home:{user_id}", style=ButtonStyle.PRIMARY)])
    return types.InlineKeyboardMarkup(rows)


def _group_keyboard(chat_id: int):
    rows = [
        [
            types.InlineKeyboardButton(font("Protection"), callback_data=f"groupdash:section:{chat_id}:protection", style=ButtonStyle.PRIMARY),
            types.InlineKeyboardButton(font("Welcome"), callback_data=f"groupdash:section:{chat_id}:welcome", style=ButtonStyle.PRIMARY),
        ],
        [
            types.InlineKeyboardButton(font("Moderation"), callback_data=f"groupdash:section:{chat_id}:moderation", style=ButtonStyle.DANGER),
            types.InlineKeyboardButton(font("Notes & Filters"), callback_data=f"groupdash:section:{chat_id}:content", style=ButtonStyle.PRIMARY),
        ],
        [
            types.InlineKeyboardButton(font("Join Approval"), callback_data=f"groupdash:section:{chat_id}:verification", style=ButtonStyle.PRIMARY),
            types.InlineKeyboardButton(font("Reports & Logs"), callback_data=f"groupdash:section:{chat_id}:reports", style=ButtonStyle.PRIMARY),
        ],
        [
            types.InlineKeyboardButton(font("Group Statistics"), callback_data=f"groupdash:section:{chat_id}:group_stats", style=ButtonStyle.SUCCESS),
            types.InlineKeyboardButton(font("Configuration"), callback_data=f"groupdash:section:{chat_id}:backup", style=ButtonStyle.PRIMARY),
        ],
        [
            types.InlineKeyboardButton(font("Music Settings"), callback_data=f"adminpanel:music:{chat_id}", style=ButtonStyle.SUCCESS),
        ],
        [types.InlineKeyboardButton(font("Refresh Dashboard"), callback_data=f"groupdash:home:{chat_id}", style=ButtonStyle.PRIMARY)],
    ]
    return types.InlineKeyboardMarkup(rows)


async def _is_group_admin(chat_id: int, user_id: int) -> bool:
    try:
        member = await pbot.get_chat_member(chat_id, user_id)
        return member.status in (enums.ChatMemberStatus.OWNER, enums.ChatMemberStatus.ADMINISTRATOR)
    except Exception as exc:
        logger.warning("Dashboard admin verification failed (%s).", type(exc).__name__)
        return False


@pbot.on_callback_query(filters.regex(_HOME_RE))
async def user_dashboard_callback(_, query: types.CallbackQuery):
    page, owner_id = query.matches[0].groups()
    if not query.from_user or query.from_user.id != int(owner_id):
        return await query.answer("This menu belongs to another user.", show_alert=True)
    title = f"<b>{BOT_NAME}</b>\n\n"
    if page == "home":
        await query.answer()
        return await query.edit_message_text(
            title + "Choose a feature to continue.",
            reply_markup=_home_keyboard(int(owner_id)),
        )
    if page == "groups":
        bot_username = (settings.BOT_USERNAME or "").lstrip("@")
        add_url = _add_to_group_url(bot_username) if bot_username else None
        body = (
            "Manage an existing group with <code>/admin</code> in that group. "
            "Only current group administrators can open its dashboard. "
            "The dashboard links to the moderation and management commands already enabled."
        )
    elif page == "settings":
        body = (
            "Group music settings: use <code>/musicsettings</code> in the group. "
            "Bot language: use <code>/language</code> where available. "
            "Group-wide management settings are in <code>/admin</code>."
        )
        add_url = None
    elif page == "stats":
        body = (
            "Available reports use the existing <code>/stats</code> and <code>/musicstats</code> commands. "
            "Metrics Telegram does not expose are not estimated."
        )
        add_url = None
    else:
        user = query.from_user
        body = (
            f"Telegram profile: <b>{html.escape(user.first_name or 'User')}</b>\n"
            f"User ID: <code>{user.id}</code>\n"
            f"Username: @{html.escape(user.username)}" if user.username else
            f"Telegram profile: <b>{html.escape(user.first_name or 'User')}</b>\nUser ID: <code>{user.id}</code>\nUsername: not set"
        )
        add_url = None
    await query.answer()
    await query.edit_message_text(title + body, reply_markup=_page_markup(page, int(owner_id), add_url))


@pbot.on_callback_query(filters.regex(_GROUP_RE))
async def group_dashboard_callback(_, query: types.CallbackQuery):
    match = query.matches[0]
    action, chat_id = match.group(1), int(match.group(2))
    if not query.from_user or not await _is_group_admin(chat_id, query.from_user.id):
        return await query.answer("Only a current administrator of this group can use this dashboard.", show_alert=True)
    if query.message.chat.type != enums.ChatType.PRIVATE and query.message.chat.id != chat_id:
        return await query.answer("This dashboard belongs to another group.", show_alert=True)
    section = match.group(3)
    desired = match.group(4)
    notice = None
    if action == "set":
        if desired not in {"on", "off"}:
            return await query.answer("Invalid setting value.", show_alert=True)
        if section == "antilink":
            from management.db import antiremovelink_db

            await antiremovelink_db.set_antilink_status(chat_id, desired == "on")
        elif section in {"welcome", "goodbye"}:
            from management.db import greetings

            if desired == "on":
                configured = (
                    await greetings.check_welcome(chat_id)
                    if section == "welcome"
                    else await greetings.check_goodbye(chat_id)
                )
                if not configured:
                    return await query.answer(
                        f"Set the {section} content first using /set{section}.",
                        show_alert=True,
                    )
            setter = greetings.set_welcome_status if section == "welcome" else greetings.set_goodbye_status
            await setter(chat_id, desired == "on")
        else:
            return await query.answer("This setting is managed by its group command.", show_alert=True)
        action = "section"
        section = "protection" if section == "antilink" else "welcome"
        notice = "Setting updated."
    if action == "home":
        chat = await pbot.get_chat(chat_id)
        text = (
            f"<b>Group dashboard · {html.escape(chat.title or 'Group')}</b>\n\n"
            "Choose a section. Controls use this group's existing settings and commands."
        )
        await query.answer()
        return await query.edit_message_text(text, reply_markup=_group_keyboard(chat_id))
    details = _SECTIONS.get(section)
    if not details:
        return await query.answer("That dashboard section is unavailable.", show_alert=True)
    title, commands = details
    status_lines: list[str] = []
    toggle_rows = []
    try:
        if section == "protection":
            from management.db import antiremovelink_db, antiflood, antiraid

            link_on = await antiremovelink_db.is_antilink_enabled(chat_id)
            flood = await antiflood.get_flood_config(chat_id)
            raid = await antiraid.get_antiraid_config(chat_id)
            flood_on = bool(flood.get("limit", 0) or flood.get("timer", {}).get("count", 0))
            raid_on = bool(raid.get("enabled_until"))
            status_lines.extend([
                f"Anti-link: {'ON' if link_on else 'OFF'}",
                f"Flood protection: {'ON' if flood_on else 'OFF'}",
                f"Anti-raid: {'ON' if raid_on else 'OFF'}",
            ])
            toggle_rows.append([
                types.InlineKeyboardButton(
                    font("Turn anti-link OFF" if link_on else "Turn anti-link ON"),
                    callback_data=f"groupdash:set:{chat_id}:antilink:{'off' if link_on else 'on'}",
                    style=ButtonStyle.DANGER if link_on else ButtonStyle.SUCCESS,
                )
            ])
        elif section == "welcome":
            from management.db import greetings

            welcome_on = await greetings.get_welcome_status(chat_id)
            goodbye_on = await greetings.get_goodbye_status(chat_id)
            status_lines.extend([
                f"Welcome: {'ON' if welcome_on else 'OFF'}",
                f"Goodbye: {'ON' if goodbye_on else 'OFF'}",
            ])
            toggle_rows.extend([
                [types.InlineKeyboardButton(
                    font("Turn welcome OFF" if welcome_on else "Turn welcome ON"),
                    callback_data=f"groupdash:set:{chat_id}:welcome:{'off' if welcome_on else 'on'}",
                    style=ButtonStyle.DANGER if welcome_on else ButtonStyle.SUCCESS,
                )],
                [types.InlineKeyboardButton(
                    font("Turn goodbye OFF" if goodbye_on else "Turn goodbye ON"),
                    callback_data=f"groupdash:set:{chat_id}:goodbye:{'off' if goodbye_on else 'on'}",
                    style=ButtonStyle.DANGER if goodbye_on else ButtonStyle.SUCCESS,
                )],
            ])
        elif section == "content":
            from management.db import filter as filter_db, notes

            status_lines.extend([
                f"Saved filters: {await filter_db.get_filter_count(chat_id)}",
                f"Saved notes: {len(await notes.get_notes_name_by_chat(chat_id))}",
            ])
        elif section == "verification":
            from management.db import approval_db

            approved = await approval_db.get_all_approved_users(chat_id)
            status_lines.append(f"Approved members: {len(approved)}")
        elif section == "reports":
            from management.db import logchannel_db, moderation

            status_lines.append(
                f"Private log channel: {'configured' if await logchannel_db.get_log_channel(chat_id) else 'not configured'}"
            )
            status_lines.append(f"Recent moderation records: {len(await moderation.get_recent_audit(chat_id, 10))}")
    except Exception as exc:
        logger.warning("Could not read dashboard status for group %s (%s).", chat_id, type(exc).__name__)
        status_lines.append("Some live status could not be loaded; use the listed commands to check it.")
    status_text = "\n".join(html.escape(line) for line in status_lines)
    command_text = "\n".join(f"• <code>{html.escape(command)}</code>" for command in commands)
    text = (
        f"<b>{html.escape(title)}</b>\n\n"
        + (status_text + "\n\n" if status_text else "")
        + "Available controls in this group:\n"
        + command_text
        + "\n\nThese are existing commands; use them in the group to view or change settings."
    )
    await query.answer(notice or "")
    await query.edit_message_text(
        text,
        reply_markup=types.InlineKeyboardMarkup(
            toggle_rows + [[types.InlineKeyboardButton(font("Back to Dashboard"), callback_data=f"groupdash:home:{chat_id}", style=ButtonStyle.PRIMARY)]]
        ),
    )
