import asyncio
import io
import logging
from pyrogram import filters, enums
from pyrogram.types import InlineKeyboardButton as IKB, InlineKeyboardMarkup as IKM, Message, CallbackQuery
from pyrogram.enums import ButtonStyle, ChatMemberStatus
from management import pbot, prefix_cmds, font
from management.db.antinsfw_db import get_antinsfw, set_antinsfw, get_antinsfw_admin, set_antinsfw_admin
from management.helpers.media_moderation import nsfw_engine

__module__ = "𝐀ɴᴛɪ-𝐍sғᴡ🛡️"
__help__ = """
*𝐀ɴᴛɪ-𝐍sғᴡ🛡️* — Optional local explicit-media checks using NudeNet ONNX

• `/antiporn` — Toggle anti-NSFW settings or check status.
• `/nsfwstatus` — Check detection model status.

*Behavior:*
Media scanning is OFF by default. Group admins can opt in; User mode covers members and Admin mode also scans administrators. Abuse-word moderation is controlled separately.
"""

class NSFWDetector:
    """Compatibility wrapper around the installed local NudeNet ONNX model."""

    @property
    def loaded(self) -> bool:
        return nsfw_engine.state == "ready"

    @property
    def loading(self) -> bool:
        return nsfw_engine.state == "loading"

    async def wait_ready(self, timeout=45):
        if self.loaded:
            return True
        try:
            await asyncio.wait_for(
                nsfw_engine.classify((self._blank_frame(),), 0.99, False),
                timeout=timeout,
            )
        except Exception:
            return False
        return self.loaded

    @staticmethod
    def _blank_frame() -> bytes:
        from PIL import Image

        image = Image.new("RGBA", (32, 32), (255, 255, 255, 255))
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        return buffer.getvalue()

    async def is_nsfw(self, image_bytes: bytes) -> bool:
        try:
            result = await nsfw_engine.classify((bytes(image_bytes),), 0.92, False)
            return bool(result["explicit"])
        except Exception as exc:
            logging.warning("Local explicit-media check failed (%s).", type(exc).__name__)
            return False

    async def check_video_frame(self, video_path: str) -> bool:
        try:
            import cv2

            capture = cv2.VideoCapture(video_path)
            if not capture.isOpened():
                return False
            ok, frame = capture.read()
            capture.release()
            if not ok or frame is None:
                return False
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
            from PIL import Image
            import numpy as np

            image = Image.fromarray(np.asarray(frame))
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
            return await self.is_nsfw(buffer.getvalue())
        except Exception:
            return False

detector = NSFWDetector()

async def is_user_admin(chat_id: int, user_id: int):
    from management.helpers.decorator import protected_ids, user_admin_cache
    if user_id in protected_ids:
        return True
    k = (chat_id, user_id, 'a')
    res = user_admin_cache.get(k)
    if res is not None:
        return res
    try:
        member = await pbot.get_chat_member(chat_id, user_id)
        res = member.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)
        user_admin_cache[k] = res
        return res
    except:
        return False

async def get_antiporn_keyboard(chat_id: int):
    user_mode = await get_antinsfw(chat_id)
    admin_mode = await get_antinsfw_admin(chat_id)
    
    u_text = f"🟢 User Mode: ON" if user_mode else "🔴 User Mode: OFF"
    u_style = ButtonStyle.SUCCESS if user_mode else ButtonStyle.DANGER
    
    a_text = f"🟢 Admin Mode: ON" if admin_mode else "🔴 Admin Mode: OFF"
    a_style = ButtonStyle.SUCCESS if admin_mode else ButtonStyle.DANGER
    
    return IKM([
        [IKB(font(u_text), callback_data="ap_toggle_user", style=u_style)],
        [IKB(font(a_text), callback_data="ap_toggle_admin", style=a_style)]
    ])

@pbot.on_message(filters.command(["antiporn", "antipornadmin"], prefixes=prefix_cmds) & filters.group)
async def antiporn_cmd(_, message: Message):
    if not await is_user_admin(message.chat.id, message.from_user.id):
        return await message.reply_text(font("❌ You must be an admin to use this command."))

    if len(message.command) > 1:
        arg = message.command[1].lower()
        if message.command[0].lower() == "antiporn":
            if arg == "on":
                await set_antinsfw(message.chat.id, True)
            elif arg == "off":
                await set_antinsfw(message.chat.id, False)
        else: # antipornadmin
            if arg == "on":
                await set_antinsfw_admin(message.chat.id, True)
            elif arg == "off":
                await set_antinsfw_admin(message.chat.id, False)

    u_mode = await get_antinsfw(message.chat.id)
    a_mode = await get_antinsfw_admin(message.chat.id)

    status_text = (
        f"🛡️ <b>Anti-NSFW Status</b>\n\n"
        f"👥 <b>Users Mode:</b> {'Enabled' if u_mode else 'Disabled'}\n"
        f"👮 <b>Admin Mode:</b> {'Enabled' if a_mode else 'Disabled'}\n\n"
        f"Click the buttons below to toggle."
    )

    await message.reply_text(
        font(status_text),
        reply_markup=await get_antiporn_keyboard(message.chat.id),
        parse_mode=enums.ParseMode.HTML
    )

@pbot.on_callback_query(filters.regex(r"^ap_toggle_"))
async def ap_toggle_cb(_, query: CallbackQuery):
    user_id = query.from_user.id
    chat_id = query.message.chat.id

    if not await is_user_admin(chat_id, user_id):
        return await query.answer(font("❌ This button is for admins only!"), show_alert=True)

    action = query.data.split("_")[-1]

    if action == "user":
        curr = await get_antinsfw(chat_id)
        await set_antinsfw(chat_id, not curr)
    else: # admin
        curr = await get_antinsfw_admin(chat_id)
        await set_antinsfw_admin(chat_id, not curr)

    u_mode = await get_antinsfw(chat_id)
    a_mode = await get_antinsfw_admin(chat_id)

    status_text = (
        f"🛡️ <b>Anti-NSFW Status</b>\n\n"
        f"👥 <b>Users Mode:</b> {'Enabled' if u_mode else 'Disabled'}\n"
        f"👮 <b>Admin Mode:</b> {'Enabled' if a_mode else 'Disabled'}\n\n"
        f"Click the buttons below to toggle."
    )
    
    await query.message.edit_text(
        font(status_text),
        reply_markup=await get_antiporn_keyboard(chat_id),
        parse_mode=enums.ParseMode.HTML
    )
    await query.answer(font("Status Updated"))

@pbot.on_message(filters.command("nsfwstatus", prefixes=prefix_cmds) & filters.group)
async def nsfw_status_cmd(_, message: Message):
    if not await is_user_admin(message.chat.id, message.from_user.id):
        return await message.reply_text(font("❌ You must be an admin to use this command."))
    
    if not detector.loaded and not detector.loading:
        await detector.wait_ready(timeout=12)

    if detector.loaded:
        status_text = (
            "✅ <b>Local model: Ready</b>\n\n"
            "🤖 <b>Engine:</b> NudeNet ONNX\n"
            "📊 <b>Default explicit-content threshold:</b> 95%\n"
            "🔒 Images are analyzed locally; they are not sent to a third-party API."
        )
    elif detector.loading:
        status_text = (
            "🔄 <b>Model Loading...</b>\n\n"
            "⏳ Please wait, model will be ready soon"
        )
    else:
        status_text = (
            "❌ <b>Model Failed</b>\n\n"
            "🐛 NSFW detection is currently <b>disabled</b>"
        )
    
    await message.reply_text(font(status_text), parse_mode=enums.ParseMode.HTML)
