from pyrogram import filters, enums
from pyrogram.types import Message
from management import pbot, LOGGER, font
from config import OWNER_ID, prefix_cmds, settings
import asyncio
import json
import stat
import subprocess
import tempfile
import zipfile
import os
from pathlib import Path
from pathlib import PureWindowsPath

MODULE = {}
MODULE["Backup"] = {
    "description": "Database backup and restore commands",
    "commands": {
        "backup": "Create a backup of all databases",
        "restore": "Restore databases from backup file",
        "backupinfo": "View backup file contents"
    }
}


def create_zip(source_dir, output_filename):
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, os.path.dirname(source_dir))
                zipf.write(file_path, arcname)


def run_mongo_tool(tool: str, *args: str) -> None:
    if not settings.MONGO_DB_URI:
        raise RuntimeError("MONGO_DB_URI is not configured.")
    with tempfile.TemporaryDirectory(prefix="eiko-mongo-config-") as temp_dir:
        config_path = Path(temp_dir) / "mongo-tools.yml"
        config_path.write_text(
            f"uri: {json.dumps(settings.MONGO_DB_URI)}\n", encoding="utf-8"
        )
        os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)
        try:
            result = subprocess.run(
                [tool, "--config", str(config_path), *args],
                capture_output=True,
                text=True,
                timeout=900,
                check=False,
            )
        except FileNotFoundError as exc:
            raise RuntimeError("MongoDB Database Tools are not installed.") from exc
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f"{tool} timed out.") from exc
        if result.returncode:
            raise RuntimeError(f"{tool} exited with status {result.returncode}.")


def safe_extract(zip_path: str, destination: str) -> None:
    destination_path = Path(destination).resolve()
    with zipfile.ZipFile(zip_path, "r") as archive:
        bad_member = archive.testzip()
        if bad_member:
            raise ValueError("The backup archive failed its integrity check.")
        total_size = sum(member.file_size for member in archive.infolist())
        if total_size > 1_000_000_000:
            raise ValueError("The archive exceeds the 1 GB extraction limit.")
        for member in archive.infolist():
            name = member.filename
            member_path = Path(name)
            windows_path = PureWindowsPath(name)
            target = (destination_path / member_path).resolve()
            if (
                member_path.is_absolute()
                or windows_path.is_absolute()
                or "\\" in name
                or ".." in member_path.parts
                or target != destination_path and destination_path not in target.parents
                or stat.S_ISLNK(member.external_attr >> 16)
            ):
                raise ValueError("The archive contains an unsafe path.")
        archive.extractall(destination_path)


@pbot.on_message(filters.command("backup", prefix_cmds) & filters.user(OWNER_ID), group=118)
async def backup_database(_, message: Message):
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text(font("⚠️ Use this command in private chat."))

    m = await message.reply_text(font("🔄 Backing up..."))
    
    try:
        with tempfile.TemporaryDirectory(prefix="eiko-backup-") as temp_dir:
            dump_dir = Path(temp_dir) / "dump"
            archive_path = Path(temp_dir) / "backup.zip"
            await asyncio.to_thread(run_mongo_tool, "mongodump", "--out", str(dump_dir))
            await m.edit_text(font("📦 Compressing..."))
            await asyncio.to_thread(create_zip, str(dump_dir), str(archive_path))
            await message.reply_document(document=str(archive_path), caption="✅ Backup complete")
        await m.delete()
        LOGGER.info("Database backup completed.")
    except Exception as exc:
        LOGGER.warning("Database backup failed (%s).", type(exc).__name__)
        await m.edit_text(
            "❌ Backup failed. Check MongoDB Database Tools, Atlas network access, and database permissions."
        )


@pbot.on_message(filters.command("backupinfo", prefix_cmds) & filters.user(OWNER_ID), group=119)
async def backup_info(_, message: Message):
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text(font("⚠️ Use this command in private chat."))
    
    if not message.reply_to_message or not message.reply_to_message.document:
        return await message.reply_text(font("❌ Reply to backup.zip file with /backupinfo"))
    
    m = await message.reply_text(font("📥 Checking backup..."))
    
    try:
        with tempfile.TemporaryDirectory(prefix="eiko-backup-info-") as temp_dir:
            archive_path = Path(temp_dir) / "backup.zip"
            extract_dir = Path(temp_dir) / "unpacked"
            file_path = await message.reply_to_message.download(file_name=str(archive_path))
            if not file_path or not os.path.exists(file_path):
                return await m.edit_text(font("❌ Failed to download backup file"))
            await asyncio.to_thread(safe_extract, file_path, str(extract_dir))
            dump_dir = extract_dir / "dump"
            if not dump_dir.is_dir():
                return await m.edit_text("❌ This ZIP does not contain a recognized MongoDB backup.")
            databases = []
            collections_info = ""
            for db_path in sorted(dump_dir.iterdir()):
                if not db_path.is_dir():
                    continue
                bson_files = sorted(db_path.glob("*.bson"))
                if bson_files:
                    databases.append(db_path.name)
                    collections_info += f"\n📁 {db_path.name}\n"
                    for bson_file in bson_files:
                        size_mb = bson_file.stat().st_size / (1024 * 1024)
                        collections_info += f"  └ {bson_file.stem} ({size_mb:.2f} MB)\n"
            info_text = f"Backup information\n\nDatabases: {len(databases)}\n{collections_info}"
            await m.edit_text(info_text[:3900])
    except Exception as exc:
        LOGGER.warning("Backup inspection failed (%s).", type(exc).__name__)
        await m.edit_text("❌ Could not inspect this archive. It may be invalid or too large.")


@pbot.on_message(filters.command("restore", prefix_cmds) & filters.user(OWNER_ID), group=120)
async def restore_database(_, message: Message):
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text(font("⚠️ Use this command in private chat."))
    
    if not message.reply_to_message or not message.reply_to_message.document:
        return await message.reply_text(font("❌ Reply to backup.zip file with /restore"))
    
    m = await message.reply_text(font("📥 Downloading backup..."))
    
    try:
        with tempfile.TemporaryDirectory(prefix="eiko-restore-") as temp_dir:
            archive_path = Path(temp_dir) / "backup.zip"
            extract_dir = Path(temp_dir) / "unpacked"
            file_path = await message.reply_to_message.download(file_name=str(archive_path))
            if not file_path or not os.path.exists(file_path):
                return await m.edit_text(font("❌ Failed to download backup file"))
            await m.edit_text(font("📦 Validating backup archive..."))
            await asyncio.to_thread(safe_extract, file_path, str(extract_dir))
            dump_dir = extract_dir / "dump"
            if not dump_dir.is_dir() or not any(dump_dir.rglob("*.bson")):
                return await m.edit_text("❌ This ZIP does not contain a recognized MongoDB backup.")
            await m.edit_text(font("🔄 Restoring databases... This replaces matching collections."))
            await asyncio.to_thread(
                run_mongo_tool, "mongorestore", "--drop", str(dump_dir)
            )
        await m.edit_text(font("✅ Restore complete!\nRestart bot: /restart"))
        LOGGER.info("Database restore completed.")
    except Exception as exc:
        LOGGER.warning("Database restore failed (%s).", type(exc).__name__)
        await m.edit_text(
            "❌ Restore failed. Check MongoDB Database Tools, archive format, Atlas access, and database permissions."
        )


__mod_name__ = "𝐁ᴀᴄᴋᴜᴘ🔃"
__help__ = """
**Database Backup & Restore**

Owner only commands:

• /backup - Create database backup
• /backupinfo - Check backup contents (reply to backup.zip)
• /restore - Restore from backup (reply to backup.zip)

**Note:** All commands work in private chat only.
"""
