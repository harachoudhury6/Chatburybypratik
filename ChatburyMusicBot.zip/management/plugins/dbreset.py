from pyrogram import filters
from management import pbot, font
from config import DEV_LIST, settings
from database import get_database

db_client = None
database = get_database(settings.MONGO_DB_NAME)
db2_client = None
database2 = get_database(settings.MONGO_DB2_NAME)


@pbot.on_message(filters.command("resetdb") & filters.user(DEV_LIST), group=-398)
async def resetdb_request(_, message):
    await message.reply_text(
        "⚠️ Are you sure you want to reset **ALL DATABASES**?\n"
        "This will delete all data permanently!\n\n"
        "Type `/confirmreset` to continue."
    )



@pbot.on_message(filters.command("confirmreset") & filters.user(DEV_LIST))
async def resetdb_confirm(_, message):
    # Reset first DB
    collections1 = await database.list_collection_names()
    for col in collections1:
        await database[col].delete_many({})

    # Reset second DB
    collections2 = await database2.list_collection_names()
    for col in collections2:
        await database2[col].delete_many({})

    await message.reply_text(font("✅ Both databases (`AloneX` & `AloneX2`) have been fully reset!"))
