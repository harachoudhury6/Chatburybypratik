"""Owner-only broadcast wizard with URL buttons and an explicit final review."""

from __future__ import annotations

import asyncio
import logging
import time
from urllib.parse import urlparse

from pyrogram import enums, filters
from pyrogram.enums import ButtonStyle, ChatMemberStatus, ChatType
from pyrogram.errors import (
    ChannelInvalid,
    ChatWriteForbidden,
    FloodWait,
    PeerIdInvalid,
    UserIsBlocked,
)
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import settings
from management import pbot, prefix_cmds
from management.db.chats import add_chat, get_all_chats, remove_chat, update_chats_status
from management.db.users import get_all_active_users, update_users_status

logger = logging.getLogger("eiko.broadcast")

OWNER_ID = settings.OWNER_ID
_OWNER_FILTER = filters.user(OWNER_ID) if OWNER_ID else filters.create(lambda *_: False)
_FLOWS: dict[int, dict] = {}
_BROADCAST_LOCK = asyncio.Lock()
_ACTIVE_CANCEL = False
_FLOW_TTL_SECONDS = 15 * 60
_SEND_DELAY_SECONDS = 0.1
_GROUP_CHECK_CONCURRENCY = 4

_BUTTON_STYLES = {
    "primary": ButtonStyle.PRIMARY,
    "success": ButtonStyle.SUCCESS,
    "danger": ButtonStyle.DANGER,
}


def request_stop_broadcast(owner_id: int) -> bool:
    global _ACTIVE_CANCEL
    if owner_id != OWNER_ID or not _BROADCAST_LOCK.locked():
        return False
    _ACTIVE_CANCEL = True
    return True


def _touch(flow: dict) -> None:
    flow["expires_at"] = time.monotonic() + _FLOW_TTL_SECONDS


def _is_valid_flow(owner_id: int) -> dict | None:
    flow = _FLOWS.get(owner_id)
    if not flow:
        return None
    if flow.get("expires_at", 0) < time.monotonic():
        _FLOWS.pop(owner_id, None)
        return None
    _touch(flow)
    return flow


def _control_keyboard(*, include_confirm: bool = False, include_stop: bool = False):
    buttons = []
    if include_confirm:
        buttons.append(
            InlineKeyboardButton(
                "✅ Confirm and send",
                callback_data="owner_broadcast:confirm",
                style=ButtonStyle.SUCCESS,
            )
        )
    if include_stop:
        buttons.append(
            InlineKeyboardButton(
                "⏹ Stop",
                callback_data="owner_broadcast:stop",
                style=ButtonStyle.DANGER,
            )
        )
    else:
        buttons.append(
            InlineKeyboardButton(
                "✏️ Change",
                callback_data="owner_broadcast:change",
                style=ButtonStyle.PRIMARY,
            )
        )
        buttons.append(
            InlineKeyboardButton(
                "❌ Cancel",
                callback_data="owner_broadcast:cancel",
                style=ButtonStyle.DANGER,
            )
        )
    return InlineKeyboardMarkup([buttons])


def _button_keyboard(buttons: list[dict]) -> InlineKeyboardMarkup | None:
    if not buttons:
        return None
    rows = []
    for index in range(0, len(buttons), 2):
        row = []
        for item in buttons[index : index + 2]:
            row.append(
                InlineKeyboardButton(
                    item["text"],
                    url=item["url"],
                    style=_BUTTON_STYLES[item["style"]],
                )
            )
        rows.append(row)
    return InlineKeyboardMarkup(rows)


def _remember_source_message(flow: dict, message) -> None:
    flow["source_chat_id"] = message.chat.id
    flow["source_message_id"] = message.id
    flow["source_text"] = message.text
    flow["source_caption"] = message.caption


async def _copy_to_chat(client, target_id: int, flow: dict, markup):
    # Copy the original owner-authored message so formatting, captions, and
    # premium custom-emoji entities survive both preview and delivery.
    return await client.copy_message(
        chat_id=target_id,
        from_chat_id=flow["source_chat_id"],
        message_id=flow["source_message_id"],
        reply_markup=markup,
    )


def _valid_https_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return (
            parsed.scheme == "https"
            and bool(parsed.netloc)
            and " " not in value
            and len(value) <= 2048
        )
    except ValueError:
        return False


def _new_flow(mode: str) -> dict:
    return {
        "mode": mode if mode in {"all", "users", "chats"} else "all",
        "step": "message",
        "buttons": [],
        "button_count": 0,
        "pending_button": {},
        "targets": [],
        "source_chat_id": None,
        "source_message_id": None,
        "source_text": None,
        "source_caption": None,
        "preview_message_id": None,
        "control_message_id": None,
        "expires_at": time.monotonic() + _FLOW_TTL_SECONDS,
    }


async def begin_owner_broadcast(
    client,
    owner_id: int,
    *,
    mode: str = "all",
    source_message=None,
) -> None:
    """Start a private broadcast conversation; nothing is sent until Confirm."""
    if not OWNER_ID or owner_id != OWNER_ID:
        return
    if _BROADCAST_LOCK.locked():
        return await client.send_message(
            owner_id, "A broadcast is already running. Wait for it to finish or stop it."
        )
    if _is_valid_flow(owner_id):
        return await client.send_message(
            owner_id, "A broadcast setup is already open. Finish it or press Cancel first."
        )

    flow = _new_flow(mode)
    _FLOWS[owner_id] = flow
    if source_message is not None:
        if source_message.chat.id != owner_id:
            _FLOWS.pop(owner_id, None)
            return await client.send_message(
                owner_id, "Start the broadcast in private and send the content there."
            )
        _remember_source_message(flow, source_message)
        flow["step"] = "buttons"
        return await client.send_message(
            owner_id,
            "Would you like to add URL buttons to this broadcast?",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "✅ Yes", callback_data="owner_broadcast:buttons_yes",
                        style=ButtonStyle.SUCCESS,
                    ),
                    InlineKeyboardButton(
                        "No buttons", callback_data="owner_broadcast:buttons_no",
                        style=ButtonStyle.PRIMARY,
                    ),
                ]]
            ),
        )

    await client.send_message(
        owner_id,
        "Send the message, photo, video, or other content to broadcast. "
        "Use /cancel at any time to stop setup.",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("❌ Cancel", callback_data="owner_broadcast:cancel",
                                   style=ButtonStyle.DANGER)]]
        ),
    )


async def _eligible_group(client, chat_id: int, bot_id: int) -> tuple[bool, bool]:
    """Return whether the bot can post in this tracked group or channel."""
    for attempt in range(2):
        try:
            chat = await client.get_chat(chat_id)
            if chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP, ChatType.CHANNEL):
                return False, False
            member = await client.get_chat_member(chat_id, bot_id)
            if member.status not in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER):
                return False, False
            if chat.type == ChatType.CHANNEL:
                rights = getattr(member, "privileges", None)
                if not rights or not getattr(rights, "can_post_messages", False):
                    return False, False
            return True, False
        except FloodWait as exc:
            if attempt or exc.value > 10:
                return False, True
            await asyncio.sleep(exc.value + 1)
        except (PeerIdInvalid, ChannelInvalid, ChatWriteForbidden):
            return False, False
        except Exception as exc:
            logger.debug("Could not verify broadcast group (%s).", type(exc).__name__)
            return False, True
    return False, True


async def _get_targets(client, mode: str) -> tuple[list[tuple[int, str]], int]:
    targets: list[tuple[int, str]] = []
    seen: set[int] = set()
    unverifiable_chats = 0

    if mode in {"all", "users"}:
        users = await get_all_active_users()
        for raw_id in users:
            try:
                user_id = int(raw_id)
            except (TypeError, ValueError):
                continue
            if user_id > 0 and user_id != OWNER_ID and user_id not in seen:
                targets.append((user_id, "user"))
                seen.add(user_id)

    if mode in {"all", "chats"}:
        candidates = []
        for raw_id in await get_all_chats():
            try:
                chat_id = int(raw_id)
            except (TypeError, ValueError):
                continue
            if chat_id < 0 and chat_id not in seen:
                candidates.append(chat_id)
                seen.add(chat_id)

        me = await client.get_me()
        semaphore = asyncio.Semaphore(_GROUP_CHECK_CONCURRENCY)

        async def check_one(chat_id: int):
            async with semaphore:
                await asyncio.sleep(0.1)
                return chat_id, await _eligible_group(client, chat_id, me.id)

        checks = await asyncio.gather(
            *(check_one(chat_id) for chat_id in candidates),
            return_exceptions=True,
        )
        for item in checks:
            if isinstance(item, BaseException):
                unverifiable_chats += 1
                continue
            chat_id, (eligible, uncertain) = item
            if eligible:
                targets.append((chat_id, "chat"))
            elif uncertain:
                unverifiable_chats += 1
    return targets, unverifiable_chats


async def _show_preview(client, owner_id: int, flow: dict) -> None:
    if _FLOWS.get(owner_id) is not flow:
        return
    _touch(flow)
    flow["step"] = "preparing"
    status = await client.send_message(
        owner_id, "Checking active users and verifying groups/channels where I can post…"
    )
    try:
        targets, unverifiable = await _get_targets(client, flow["mode"])
    except Exception as exc:
        logger.warning("Could not prepare broadcast recipients (%s).", type(exc).__name__)
        flow["step"] = "buttons"
        return await status.edit_text(
            "I couldn't load the recipient list. No broadcast was sent. "
            "Check the database connection and try again."
        )
    if _FLOWS.get(owner_id) is not flow:
        return await status.edit_text("Broadcast setup cancelled. Nothing was sent.")
    flow["targets"] = targets

    preview_markup = _button_keyboard(flow["buttons"])
    try:
        copied = await _copy_to_chat(client, owner_id, flow, preview_markup)
        flow["preview_message_id"] = getattr(copied, "id", None) or getattr(
            copied, "message_id", None
        )
    except Exception as exc:
        logger.warning("Could not create broadcast preview (%s).", type(exc).__name__)
        flow["step"] = "message"
        return await status.edit_text(
            "I couldn't preview that content, so it cannot be broadcast. "
            "Send a different message or use /cancel."
        )
    if _FLOWS.get(owner_id) is not flow:
        try:
            await client.delete_messages(
                owner_id,
                getattr(copied, "id", None) or getattr(copied, "message_id", None),
            )
        except Exception:
            pass
        return await status.edit_text("Broadcast setup cancelled. Nothing was sent.")

    users = sum(kind == "user" for _, kind in targets)
    chats = sum(kind == "chat" for _, kind in targets)
    flow["step"] = "preview"
    _touch(flow)
    message = (
        "<b>Broadcast preview</b>\n"
        f"Private users who started the bot: <b>{users}</b>\n"
        f"Groups/channels where I can post: <b>{chats}</b>\n"
        f"Total recipients: <b>{len(targets)}</b>\n"
    )
    if unverifiable:
        message += (
            f"Chats I could not verify (excluded): <b>{unverifiable}</b>\n"
        )
    message += "\nReview the copied message and buttons above. Nothing will be sent until you confirm."
    control = await client.send_message(
        owner_id,
        message,
        parse_mode=enums.ParseMode.HTML,
        reply_markup=_control_keyboard(include_confirm=bool(targets)),
    )
    flow["control_message_id"] = control.id
    try:
        await status.edit_text("Recipient check complete. Review the broadcast preview above.")
    except Exception:
        pass


async def _prompt_button_count(client, owner_id: int, flow: dict) -> None:
    flow["step"] = "button_count"
    _touch(flow)
    await client.send_message(
        owner_id,
        "Choose 1, 2, or 3 URL buttons.",
        reply_markup=InlineKeyboardMarkup(
            [[
                InlineKeyboardButton("1 button", callback_data="owner_broadcast:count_1",
                                     style=ButtonStyle.PRIMARY),
                InlineKeyboardButton("2 buttons", callback_data="owner_broadcast:count_2",
                                     style=ButtonStyle.PRIMARY),
                InlineKeyboardButton("3 buttons", callback_data="owner_broadcast:count_3",
                                     style=ButtonStyle.PRIMARY),
            ]]
        ),
    )


async def _ask_button_label(client, owner_id: int, flow: dict) -> None:
    flow["step"] = "button_label"
    _touch(flow)
    await client.send_message(
        owner_id,
        f"Send the text for button {len(flow['buttons']) + 1}/"
        f"{flow['button_count']} (1–64 characters). Stylish Unicode text is supported.",
    )


async def _send_copy(client, owner_id: int, target_id: int, flow: dict) -> tuple[bool, bool]:
    """Return (sent, should_deactivate_target); retry transient FloodWait a bounded number."""
    markup = _button_keyboard(flow["buttons"])
    for attempt in range(3):
        try:
            await _copy_to_chat(client, target_id, flow, markup)
            return True, False
        except FloodWait as exc:
            if attempt == 2 or exc.value > 120:
                return False, False
            await asyncio.sleep(exc.value + 1)
        except (PeerIdInvalid, ChatWriteForbidden, ChannelInvalid, UserIsBlocked):
            return False, True
        except Exception as exc:
            logger.warning("Broadcast delivery failed (%s).", type(exc).__name__)
            return False, False
    return False, False


async def _run_broadcast(client, owner_id: int, flow: dict, control_message) -> None:
    global _ACTIVE_CANCEL
    async with _BROADCAST_LOCK:
        _ACTIVE_CANCEL = False
        flow["step"] = "sending"
        total = len(flow["targets"])
        sent = failed = 0
        inactive_users: list[int] = []
        inactive_groups: list[int] = []
        try:
            await control_message.edit_text(
                f"Broadcast sending…\nSent: 0\nFailed: 0\nTotal: {total}",
                reply_markup=_control_keyboard(include_stop=True),
            )
            for index, (target_id, kind) in enumerate(flow["targets"], start=1):
                if _ACTIVE_CANCEL:
                    break
                success, deactivate = await _send_copy(client, owner_id, target_id, flow)
                if success:
                    sent += 1
                else:
                    failed += 1
                    if deactivate:
                        (inactive_users if kind == "user" else inactive_groups).append(target_id)

                if index % 20 == 0 or index == total:
                    try:
                        await control_message.edit_text(
                            f"Broadcast sending…\nSent: {sent}\nFailed: {failed}\n"
                            f"Checked: {index}/{total}",
                            reply_markup=_control_keyboard(include_stop=True),
                        )
                    except Exception:
                        pass
                await asyncio.sleep(_SEND_DELAY_SECONDS)

            if inactive_users:
                await update_users_status(inactive_users, status=False)
            if inactive_groups:
                await update_chats_status(inactive_groups, status=False)
            stopped = _ACTIVE_CANCEL
            state = "stopped" if stopped else "finished"
            await control_message.edit_text(
                f"Broadcast {state}.\n"
                f"Sent: {sent}\nFailed: {failed}\n"
                f"Recipients: {total}\n"
            f"Inactive users/chats marked inactive: "
                f"{len(inactive_users) + len(inactive_groups)}"
            )
        except Exception as exc:
            logger.exception("Broadcast run failed (%s).", type(exc).__name__)
            try:
                await control_message.edit_text(
                    f"Broadcast stopped after an internal error.\nSent: {sent}\nFailed: {failed}"
                )
            except Exception:
                pass
        finally:
            _ACTIVE_CANCEL = False
            _FLOWS.pop(owner_id, None)


@pbot.on_message(
    filters.command(["broadcast_all"], prefix_cmds) & _OWNER_FILTER & filters.private,
    group=22,
)
async def broadcast_all_command(client, message):
    await begin_owner_broadcast(
        client,
        message.from_user.id,
        mode="all",
        source_message=message.reply_to_message,
    )


@pbot.on_message(
    filters.command(["broadcast_users"], prefix_cmds) & _OWNER_FILTER & filters.private,
    group=23,
)
async def broadcast_users_command(client, message):
    await begin_owner_broadcast(
        client,
        message.from_user.id,
        mode="users",
        source_message=message.reply_to_message,
    )


@pbot.on_message(
    filters.command(["broadcast_chats"], prefix_cmds) & _OWNER_FILTER & filters.private,
    group=24,
)
async def broadcast_chats_command(client, message):
    await begin_owner_broadcast(
        client,
        message.from_user.id,
        mode="chats",
        source_message=message.reply_to_message,
    )


@pbot.on_message(filters.private & _OWNER_FILTER, group=-9990)
async def owner_broadcast_input(client, message):
    owner_id = message.from_user.id if message.from_user else 0
    flow = _is_valid_flow(owner_id)
    if not flow or flow["step"] == "preview" or flow["step"] in {"preparing", "sending"}:
        return
    raw_text = (message.text or "").strip()
    if raw_text.casefold() == "/cancel":
        _FLOWS.pop(owner_id, None)
        return await message.reply_text("Broadcast setup cancelled. Nothing was sent.")

    step = flow["step"]
    if step == "message":
        if raw_text.startswith("/") or not (
            message.text or message.caption or message.media
        ):
            return await message.reply_text(
                "Send the content to broadcast, or use /cancel."
            )
        _remember_source_message(flow, message)
        flow["step"] = "buttons"
        _touch(flow)
        return await message.reply_text(
            "Would you like to add URL buttons?",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton("✅ Yes", callback_data="owner_broadcast:buttons_yes",
                                         style=ButtonStyle.SUCCESS),
                    InlineKeyboardButton("No buttons", callback_data="owner_broadcast:buttons_no",
                                         style=ButtonStyle.PRIMARY),
                ]]
            ),
        )
    if step == "button_label":
        if not raw_text or raw_text.startswith("/") or len(raw_text) > 64:
            return await message.reply_text(
                "Button text must be 1–64 characters. Send the label again."
            )
        flow["pending_button"] = {"text": raw_text}
        flow["step"] = "button_url"
        _touch(flow)
        return await message.reply_text(
            "Send the HTTPS URL for this button (for example, https://t.me/yourchannel)."
        )
    if step == "button_url":
        if not _valid_https_url(raw_text):
            return await message.reply_text(
                "That link is not valid. Send a complete HTTPS URL, or use /cancel."
            )
        flow["pending_button"]["url"] = raw_text
        flow["step"] = "button_style"
        _touch(flow)
        return await message.reply_text(
            "Choose this button's color.",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton("Primary", callback_data="owner_broadcast:style_primary",
                                         style=ButtonStyle.PRIMARY),
                    InlineKeyboardButton("Success", callback_data="owner_broadcast:style_success",
                                         style=ButtonStyle.SUCCESS),
                    InlineKeyboardButton("Danger", callback_data="owner_broadcast:style_danger",
                                         style=ButtonStyle.DANGER),
                ]]
            ),
        )
    if raw_text.startswith("/"):
        return
    return await message.reply_text("Use the buttons shown above, or /cancel to stop.")


@pbot.on_callback_query(filters.regex(r"^owner_broadcast:"))
async def owner_broadcast_callback(client, query: CallbackQuery):
    if (
        not query.from_user
        or query.from_user.id != OWNER_ID
        or not query.message
        or query.message.chat.type != ChatType.PRIVATE
    ):
        return await query.answer("This is an owner-only private control.", show_alert=True)

    owner_id = query.from_user.id
    action = query.data.split(":", 1)[1]
    flow = _is_valid_flow(owner_id)
    if action == "stop":
        if not _BROADCAST_LOCK.locked():
            return await query.answer("No broadcast is running.", show_alert=True)
        global _ACTIVE_CANCEL
        _ACTIVE_CANCEL = True
        return await query.answer("Stopping after the current send.")
    if action == "cancel":
        if flow and flow.get("preview_message_id"):
            try:
                await client.delete_messages(owner_id, flow["preview_message_id"])
            except Exception:
                pass
        _FLOWS.pop(owner_id, None)
        await query.answer("Broadcast cancelled.")
        return await query.message.edit_text("Broadcast setup cancelled. Nothing was sent.")
    if not flow:
        return await query.answer("This setup expired. Open /admin and start again.", show_alert=True)

    if action == "buttons_yes":
        if flow["step"] != "buttons":
            return await query.answer("This step has already changed.", show_alert=True)
        await query.answer()
        return await _prompt_button_count(client, owner_id, flow)
    if action == "buttons_no":
        if flow["step"] != "buttons":
            return await query.answer("This step has already changed.", show_alert=True)
        flow["buttons"] = []
        await query.answer()
        return await _show_preview(client, owner_id, flow)
    if action in {"count_1", "count_2", "count_3"}:
        if flow["step"] != "button_count":
            return await query.answer("This step has already changed.", show_alert=True)
        flow["button_count"] = int(action[-1])
        await query.answer()
        return await _ask_button_label(client, owner_id, flow)
    if action.startswith("style_"):
        if flow["step"] != "button_style":
            return await query.answer("This step has already changed.", show_alert=True)
        style = action.removeprefix("style_")
        if style not in _BUTTON_STYLES:
            return await query.answer("Unknown button style.", show_alert=True)
        button = dict(flow["pending_button"])
        button["style"] = style
        flow["buttons"].append(button)
        flow["pending_button"] = {}
        await query.answer()
        if len(flow["buttons"]) < flow["button_count"]:
            return await _ask_button_label(client, owner_id, flow)
        return await _show_preview(client, owner_id, flow)
    if action == "change":
        if flow["step"] != "preview":
            return await query.answer("This preview is no longer editable.", show_alert=True)
        if flow.get("preview_message_id"):
            try:
                await client.delete_messages(owner_id, flow["preview_message_id"])
            except Exception:
                pass
        flow.update(
            step="message",
            source_chat_id=None,
            source_message_id=None,
            source_text=None,
            source_caption=None,
            preview_message_id=None,
            control_message_id=query.message.id,
            buttons=[],
            button_count=0,
            pending_button={},
            targets=[],
        )
        _touch(flow)
        await query.answer()
        return await query.message.edit_text(
            "Send the replacement message or media. Use /cancel to stop.",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("❌ Cancel", callback_data="owner_broadcast:cancel",
                                       style=ButtonStyle.DANGER)]]
            ),
        )
    if action == "confirm":
        if flow["step"] != "preview":
            return await query.answer("This preview is no longer active.", show_alert=True)
        if not flow["targets"]:
            return await query.answer("There are no eligible recipients.", show_alert=True)
        if _BROADCAST_LOCK.locked():
            return await query.answer("A broadcast is already running.", show_alert=True)
        await query.answer("Confirmed. Sending the broadcast.")
        return await _run_broadcast(client, owner_id, flow, query.message)
    return await query.answer("This broadcast action is unavailable.", show_alert=True)


@pbot.on_chat_member_updated()
async def track_broadcast_destination(_, update):
    """Track groups/channels as the bot joins or leaves, for later verified broadcasts."""
    try:
        old_member = update.old_chat_member
        new_member = update.new_chat_member
        bot = await pbot.get_me()
        if not new_member or not new_member.user or new_member.user.id != bot.id:
            return
        status = new_member.status
        if status in {
            ChatMemberStatus.MEMBER,
            ChatMemberStatus.ADMINISTRATOR,
            ChatMemberStatus.OWNER,
        }:
            await add_chat(update.chat.id, getattr(update.chat, "username", None))
        elif status in {ChatMemberStatus.LEFT, ChatMemberStatus.BANNED}:
            await remove_chat(update.chat.id)
    except Exception as exc:
        logger.debug("Could not update broadcast destination registry (%s).", type(exc).__name__)


@pbot.on_message(filters.channel, group=-9991)
async def track_existing_broadcast_channel(_, message):
    """Discover channels the bot already managed before membership tracking was added."""
    try:
        chat = message.chat
        await add_chat(chat.id, getattr(chat, "username", None))
    except Exception as exc:
        logger.debug("Could not register a channel post (%s).", type(exc).__name__)


__help__ = """
Owner private broadcast panel. Every broadcast requires a preview and an explicit confirmation.
"""
