


from management import app, LOGS_CHANNEL, LOGGER
from telegram import Update
from management.helpers.utils import get_as_document, get_message_link
from management.helpers.scripts import paste
from telegram.constants import ParseMode



import logging
import traceback
import html
import json

async def error_handler(update, context) -> None:
    """Log the error and send a telegram message to notify the developer."""
    # Log the error before we do anything else, so we can see it even if something breaks.
    LOGGER.error("Exception while handling an update:", exc_info=context.error)

    # traceback.format_exception returns the usual python message about an exception, but as a
    # list of strings rather than a single string, so we have to join them together.
    tb_list = traceback.format_exception(None, context.error, context.error.__traceback__)
    tb_string = "".join(tb_list)

    # Build the message with some markup and additional information about what happened.
    # You might need to add some logic to deal with messages longer than the 4096 character limit.
    update_str = update.to_dict() if isinstance(update, Update) else str(update)
    
    message = (
        "An exception was raised while handling an update\n"
        f"<pre>update = {html.escape(json.dumps(update_str, indent=2, ensure_ascii=False))}"
        "</pre>\n\n"
        f"<pre>context.chat_data = {html.escape(str(context.chat_data))}</pre>\n\n"
        f"<pre>context.user_data = {html.escape(str(context.user_data))}</pre>\n\n"
        f"<pre>{html.escape(tb_string)}</pre>"
    )

    # Finally, send the message

    if "make sure that only one bot instance is running" in message:
          return #ignore 
      
    if len(message) > 4000:
      
        document = get_as_document(message)
        data = await paste(message)

        if 'error' in data:
             caption = "Paste link not available at the movement."
        else:
            raw_url, paste_url = data.get('raw_url'), data.get('paste_url')
            caption = (
                f"> Paste link: {paste_url}\n"
                f"> Raw link: {raw_url}\n"
            )

      
        link = get_message_link(update.effective_message)
        if LOGS_CHANNEL:
            await context.bot.send_document(
                  LOGS_CHANNEL,
                  document=document,
                  caption=caption
            )
      
    else: 
        if LOGS_CHANNEL:
            await context.bot.send_message(
                  chat_id=LOGS_CHANNEL,
                  text=message,
                  parse_mode=ParseMode.HTML
                 )



app.add_error_handler(error_handler)
