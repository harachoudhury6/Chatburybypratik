import os
import zipfile
import subprocess
import shutil
import time
import logging
import tempfile
import re
import stat
from pathlib import Path, PureWindowsPath
from telegram import Update, constants
from telegram.ext import ContextTypes
from management import app, prefix_cmds, BOT_USERNAME, font
from management.helpers.decorator import Command, sudos_only, only_private
from github import Github
import config

TEMP_DIR = "temp_repos"
os.makedirs(TEMP_DIR, exist_ok=True)

TEMP_CONFIG = {}

def run(cmd, cwd):
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        capture_output=True,
        env=_git_push_environment() if cmd[:2] == ["git", "push"] else None,
    )
    if proc.returncode != 0:
        token = config.settings.GITHUB_TOKEN or ""
        output = proc.stderr or proc.stdout
        if token:
            output = output.replace(token, "[REDACTED]")
        raise RuntimeError(f"Git command failed (exit {proc.returncode}): {output[:1200]}")
    return proc.stdout


def _git_push_environment():
    token = config.settings.GITHUB_TOKEN
    if not token:
        raise RuntimeError("GITHUB_TOKEN is not configured.")
    descriptor, askpass = tempfile.mkstemp(prefix="eiko-git-askpass-")
    with os.fdopen(descriptor, "w", encoding="utf-8") as file:
        file.write('#!/bin/sh\ncase "$1" in *Username*) echo x-access-token ;; *) echo "$GITHUB_TOKEN" ;; esac\n')
    os.chmod(askpass, 0o700)
    TEMP_CONFIG["askpass"] = askpass
    return {
        **os.environ,
        "GIT_ASKPASS": askpass,
        "GITHUB_TOKEN": token,
        "GIT_TERMINAL_PROMPT": "0",
    }


def safe_rm(path):
    if not path:
        return
    try:
        if os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def safe_extract_upload(zip_path, destination):
    destination_path = Path(destination).resolve()
    with zipfile.ZipFile(zip_path, "r") as archive:
        if archive.testzip():
            raise ValueError("The ZIP failed its integrity check.")
        if sum(item.file_size for item in archive.infolist()) > 1_000_000_000:
            raise ValueError("The ZIP is too large to extract safely.")
        for item in archive.infolist():
            item_path = Path(item.filename)
            target = (destination_path / item_path).resolve()
            if (
                item_path.is_absolute()
                or PureWindowsPath(item.filename).is_absolute()
                or "\\" in item.filename
                or ".." in item_path.parts
                or target != destination_path and destination_path not in target.parents
                or stat.S_ISLNK(item.external_attr >> 16)
            ):
                raise ValueError("The ZIP contains an unsafe path.")
        archive.extractall(destination_path)


def config_valid():
    if not TEMP_CONFIG:
        return False
    if time.time() - TEMP_CONFIG.get("timestamp", 0) > 300:
        TEMP_CONFIG.clear()
        return False
    return True


@Command("gitconfig")
@sudos_only
@only_private
async def gitconfig(update: Update, context: ContextTypes.DEFAULT_TYPE):
    m = update.effective_message
    if not config.settings.GITHUB_TOKEN:
        return await m.reply_text(
            "GitHub uploads are disabled. Add the optional GITHUB_TOKEN Replit Secret first."
        )
    if len(context.args) < 2:
        return await m.reply_text(
            "» ᴜsᴀɢᴇ :- `/gitconfig username email`",
            parse_mode=constants.ParseMode.MARKDOWN
        )
    name = context.args[0]
    email = context.args[1]
    TEMP_CONFIG.update({"name": name, "email": email, "timestamp": time.time()})
    await m.reply_text(font("✅ ɢɪᴛʜᴜʙ ᴄᴏɴꜰɪɢ sᴇᴛ sᴜᴄᴄᴇssғᴜʟʟʏ! (ᴠᴀʟɪᴅ ꜰᴏʀ 5 ᴍɪɴᴜᴛᴇs)"))


@Command(["gitupload", "gt"])
@sudos_only
@only_private
async def gitupload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    m = update.effective_message
    bot = context.bot

    if len(context.args) < 1:
        return await m.reply_text(
            "» ᴜsᴀɢᴇ :- `/gitupload repo_name private/public branch_name` (ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴢɪᴘ ғɪʟᴇ)",
            parse_mode=constants.ParseMode.MARKDOWN
        )

    if not config_valid():
        return await m.reply_text(font("⚠️ ᴄᴏɴꜰɪɢ ᴇxᴘɪʀᴇᴅ ᴏʀ ɴᴏᴛ sᴇᴛ!\n\n» ᴘʟᴇᴀsᴇ ʀᴜɴ `/gitconfig` ғɪʀsᴛ."))

    GITHUB_NAME = TEMP_CONFIG["name"]
    GITHUB_EMAIL = TEMP_CONFIG["email"]
    GITHUB_TOKEN = config.settings.GITHUB_TOKEN
    g = Github(GITHUB_TOKEN)

    repo_name = context.args[0]
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", repo_name):
        return await m.reply_text("❌ Repo name must use only letters, numbers, dot, underscore, or hyphen.")
    visibility = context.args[1].lower() if len(context.args) >= 2 else "public"
    if visibility not in {"private", "public"}:
        return await m.reply_text("❌ Visibility must be `private` or `public`.")
    is_private = visibility == "private"
    branch_name = context.args[2] if len(context.args) >= 3 else "main"
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,100}", branch_name):
        return await m.reply_text("❌ Branch name is invalid.")

    replied = m.reply_to_message
    if not (replied and replied.document and replied.document.file_name.endswith(".zip")):
        return await m.reply_text(font("⚠️ ᴘʟᴇᴀsᴇ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴢɪᴘ ғɪʟᴇ!"))

    if not replied.document.file_name.lower().endswith(".zip"):
        return await m.reply_text(font("⚠️ Please reply to a ZIP file."))
    work_dir = tempfile.mkdtemp(prefix="upload-", dir=TEMP_DIR)
    zip_path = os.path.join(work_dir, "upload.zip")
    extract_root = os.path.join(work_dir, "extracted")
    final_path = os.path.join(work_dir, "repository")

    status = await m.reply_text(font("⏳ ᴘʀᴏᴄᴇssɪɴɢ ʏᴏᴜʀ ʀᴇqᴜᴇsᴛ..."))

    try:
        file = await bot.get_file(replied.document.file_id)
        await file.download_to_drive(custom_path=zip_path)

        safe_extract_upload(zip_path, extract_root)

        inner_items = os.listdir(extract_root)
        inner_dirs = [d for d in inner_items if os.path.isdir(os.path.join(extract_root, d))]
        inner_files = [f for f in inner_items if os.path.isfile(os.path.join(extract_root, f))]

        if len(inner_dirs) == 1 and not inner_files:
            shutil.move(os.path.join(extract_root, inner_dirs[0]), final_path)
        else:
            shutil.move(extract_root, final_path)

        for root, dirs, _ in os.walk(final_path):
            if ".git" in dirs:
                safe_rm(os.path.join(root, ".git"))

        user = g.get_user()
        repo = user.create_repo(repo_name, private=is_private, description="sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ ᴜᴘʟᴏᴀᴅ ʙʏ :- ᴀʟᴏɴᴇ ᴄᴏᴅᴇʀ", auto_init=False)


        run(["git", "init"], cwd=final_path)
        run(["git", "config", "user.email", GITHUB_EMAIL], cwd=final_path)
        run(["git", "config", "user.name", GITHUB_NAME], cwd=final_path)
        run(["git", "remote", "add", "origin", repo.clone_url], cwd=final_path)
        git_exclude = Path(final_path) / ".git" / "info" / "exclude"
        with git_exclude.open("a", encoding="utf-8") as file:
            file.write(
                "\n.env\n.env.*\n!.env.example\nsessions/\n*.session\n*.session-*\n"
                "cookies.txt\ncookies.json\n*.pem\n*.key\n"
            )
        run(["git", "add", "."], cwd=final_path)

        status_out = subprocess.run(["git", "status", "--porcelain"], cwd=final_path, text=True, capture_output=True)
        if status_out.stdout.strip():
            run(["git", "commit", "-m", "ᴜᴘʟᴏᴀᴅᴇᴅ-ʙʏ-ᴀʟᴏɴᴇ-ᴄᴏᴅᴇʀ"], cwd=final_path)
        else:
            run(["git", "commit", "--allow-empty", "-m", "ɴᴇᴡ-ᴜᴘᴅᴀᴛᴇ-ʙʏ-ᴀʟᴏɴᴇ-ᴄᴏᴅᴇʀ"], cwd=final_path)

        run(["git", "branch", "-M", branch_name], cwd=final_path)
        run(["git", "push", "-u", "origin", branch_name], cwd=final_path)

    except Exception as e:
        logging.error("[GITHUB UPLOADER ERROR] %s", type(e).__name__)
        safe_rm(work_dir)
        safe_rm(TEMP_CONFIG.pop("askpass", None))
        if status:
            await status.delete()
        return await m.reply_text(
            f"❌ GitHub upload failed ({type(e).__name__}). Check the GITHUB_TOKEN secret, repo name, and permissions."
        )

    # Cleanup
    safe_rm(work_dir)
    safe_rm(TEMP_CONFIG.pop("askpass", None))
    await status.delete()
    await m.reply_text(
        f"✅ ʀᴇᴘᴏ `{repo_name}` ᴜᴘʟᴏᴀᴅᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ!\n\n"
        f"🔒 ᴠɪsɪʙɪʟɪᴛʏ :- `{'Private' if is_private else 'Public'}`\n"
        f"🌿 ʙʀᴀɴᴄʜ :- `{branch_name}`\n\n"
        f"🔗 ᴜʀʟ :- {repo.html_url}",
        parse_mode=constants.ParseMode.MARKDOWN
    )
