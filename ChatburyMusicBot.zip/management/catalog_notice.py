"""Send a catalog-channel card when this bot is promoted in a group."""

from __future__ import annotations

import html
import logging
from typing import Any

from config import CATALOG_CHANNEL_ID

logger = logging.getLogger("eiko.management.catalog")
_sent_events: set[tuple[int, int, int]] = set()

_ADMIN_RIGHTS = (
    ("can_manage_chat", "Manage chat"),
    ("can_delete_messages", "Delete messages"),
    ("can_restrict_members", "Restrict members"),
    ("can_invite_users", "Invite users"),
    ("can_pin_messages", "Pin messages"),
    ("can_promote_members", "Promote members"),
    ("can_change_info", "Change group info"),
    ("can_manage_video_chats", "Manage voice/video chats"),
    ("can_manage_topics", "Manage topics"),
)


def _status(member: Any) -> str:
    value = getattr(member, "status", "")
    return str(getattr(value, "value", value)).lower()


async def send_bot_admin_catalog_notice(bot: Any, update: Any) -> bool:
    """Post one admin summary for a bot promotion; return whether posting worked."""
    if not CATALOG_CHANNEL_ID:
        logger.error("Catalog notice skipped: CATALOG_CHANNEL_ID is not configured.")
        return False

    membership = getattr(update, "my_chat_member", None)
    chat = getattr(update, "effective_chat", None)
    if not membership or not chat or getattr(chat, "type", "") not in (
        "group",
        "supergroup",
    ):
        return False

    old_member = getattr(membership, "old_chat_member", None)
    new_member = getattr(membership, "new_chat_member", None)
    if _status(new_member) != "administrator" or _status(old_member) == "administrator":
        return False

    bot_user = getattr(new_member, "user", None)
    event_key = (
        int(chat.id),
        int(getattr(bot_user, "id", 0) or 0),
        int(getattr(membership, "date", 0) or 0),
    )
    if event_key in _sent_events:
        return True

    try:
        profile = await bot.get_chat(chat.id)
        me = await bot.get_me()
        title = html.escape(getattr(profile, "title", None) or getattr(chat, "title", None) or "Telegram group")
        username = getattr(me, "username", None)
        bot_link = f"https://t.me/{username}" if username else None
        actor = getattr(update, "effective_user", None)
        actor_text = html.escape(
            getattr(actor, "full_name", None)
            or getattr(actor, "username", None)
            or "Group administrator"
        )
        rights = [
            label
            for attr, label in _ADMIN_RIGHTS
            if getattr(new_member, attr, False) is True
        ]
        rights_text = "\n".join(f"• {html.escape(right)}" for right in rights)
        if not rights_text:
            rights_text = "• Administrator status granted; no additional rights were reported."
        text = (
            "<b>Bot added as a group administrator</b>\n\n"
            f"<b>Group:</b> {title}\n"
            f"<b>Group ID:</b> <code>{chat.id}</code>\n"
            f"<b>Added by:</b> {actor_text}\n"
            f"<b>Bot permissions:</b>\n{rights_text}"
        )
        if bot_link:
            text += f'\n\n<a href="{html.escape(bot_link, quote=True)}">Open bot</a>'

        photo = getattr(getattr(profile, "photo", None), "big_file_id", None)
        try:
            if photo:
                await bot.send_photo(
                    chat_id=CATALOG_CHANNEL_ID,
                    photo=photo,
                    caption=text,
                    parse_mode="HTML",
                )
            else:
                await bot.send_message(
                    chat_id=CATALOG_CHANNEL_ID,
                    text=text,
                    parse_mode="HTML",
                    disable_web_page_preview=True,
                )
        except Exception:
            if not photo:
                raise
            logger.warning(
                "Could not attach group avatar to catalog notice; trying text-only.",
                exc_info=True,
            )
            await bot.send_message(
                chat_id=CATALOG_CHANNEL_ID,
                text=text,
                parse_mode="HTML",
                disable_web_page_preview=True,
            )

        _sent_events.add(event_key)
        if len(_sent_events) > 5000:
            _sent_events.clear()
        logger.info("Catalog admin notice posted for group %s.", chat.id)
        return True
    except Exception:
        logger.exception(
            "Failed to post catalog notice for group %s; check channel membership and post permission.",
            getattr(chat, "id", "unknown"),
        )
        return False
