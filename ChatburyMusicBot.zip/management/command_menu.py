"""Telegram command menus with separate public and administrator scopes."""

from __future__ import annotations

import logging
from typing import Any

from pyrogram import types
from pyrogram.enums import ButtonStyle

logger = logging.getLogger("eiko.commands")

_GROUP_NAMES = tuple(
    """
    start help mcommands admin promote demote pin unpin purge invitelink
    ban unban mute unmute kick warn warns unwarn resetwarn warnlimit
    setwarnaction addwarn nowarn strongwarn lock unlock locks adminlock locktypes
    filter filters stopfilter stopall save get notes clear renotes welcome goodbye
    setwelcome setgoodbye clearwelcome antiraid autoantiraid raidtime
    raidactiontime flood setflood clearflood antiedit antiforward
    antichannel antilink antitag antiporn nsfwstatus request approval approve
    unapprove joinmute rules setrules resetrules info id report alive ping support
    privacy donate play playforce vplay pause resume skip stop queue playing seek
    activevc playmode musicsettings auth unauth reload language music similar
    recommend radio autoplay rec unsave favorites history top
    """.split()
)

_PUBLIC_NAMES = tuple(
    """
    start help mcommands info id report alive ping support privacy donate
    play pause resume skip stop queue playing seek music similar
    recommend rec save unsave favorites history top
    """.split()
)

_PRIVATE_NAMES = _PUBLIC_NAMES
MUSIC_ONLY_COMMANDS = (
    "play playforce vplay vplayforce pause resume skip stop queue playing seek "
    "activevc playmode musicsettings music similar recommend radio autoplay rec "
    "save unsave favorites history top auth unauth"
).split()
_MUSIC_ONLY_NAMES = tuple(MUSIC_ONLY_COMMANDS)
_OWNER_PRIVATE_NAMES = _PUBLIC_NAMES + (
    "admin",
    "login",
    "logout",
    "setmusicaccount",
    "removemusicaccount",
    "broadcast",
    "broadcast_all",
    "broadcast_users",
    "broadcast_chats",
    "gcast",
    "stop_gcast",
    "stop_broadcast",
)

_DESCRIPTIONS = {
    "start": "Start the bot and open its welcome menu.",
    "help": "Open management and music help.",
    "mcommands": "List the commands shown in Telegram.",
    "admin": "Open the admin command list or manage a replied-to member.",
    "broadcast": "Open the owner-only broadcast confirmation flow.",
    "broadcast_all": "Prepare a broadcast to active users and eligible groups.",
    "broadcast_users": "Prepare a confirmed broadcast to active private users.",
    "broadcast_chats": "Prepare a confirmed broadcast to groups where the bot is admin.",
    "gcast": "Legacy alias for the owner-only broadcast confirmation flow.",
    "stop_gcast": "Stop the active owner broadcast after its current delivery.",
    "stop_broadcast": "Stop the active owner broadcast after its current delivery.",
    "adminlist": "Show the group's administrators.",
    "ban": "Ban a member from the group.",
    "unban": "Unban a member from the group.",
    "reload": "Refresh this group's administrator list.",
    "mute": "Mute a member in the group.",
    "unmute": "Unmute a member in the group.",
    "kick": "Remove a member from the group.",
    "warn": "Warn a member.",
    "warns": "Check a member's warning count.",
    "resetwarn": "Clear a member's warnings.",
    "lock": "Lock a group message type.",
    "unlock": "Unlock a group message type.",
    "locks": "Show the group's current locks.",
    "filter": "Add an automatic reply filter.",
    "filters": "List this group's filters.",
    "stopfilter": "Remove a filter.",
    "stopall": "Remove all filters.",
    "save": "Save the current track; admins can use /save <tag> to save a note.",
    "get": "Retrieve a saved note.",
    "notes": "List saved notes.",
    "welcome": "Configure the group's welcome message.",
    "goodbye": "Configure the group's goodbye message.",
    "setwelcome": "Set the group's welcome message.",
    "setgoodbye": "Set the group's goodbye message.",
    "antiraid": "Configure group raid protection.",
    "flood": "Configure flood protection.",
    "antiedit": "Configure edited-message protection.",
    "antiforward": "Configure forwarded-message protection.",
    "antichannel": "Configure channel-message protection.",
    "antilink": "Configure invite-link protection.",
    "antitag": "Configure mass-mention protection.",
    "antiporn": "Configure NSFW protection.",
    "rules": "Show the group's rules.",
    "setrules": "Set the group's rules.",
    "resetrules": "Remove the group's rules.",
    "info": "Show group details, tracked activity, admins, or a member's group status.",
    "id": "Show a Telegram user or chat ID.",
    "report": "Report a message to the group admins.",
    "play": "Search YouTube and play or queue a song in voice chat.",
    "playforce": "Put a song at the front of the voice-chat queue.",
    "vplay": "Play or queue a YouTube video in voice chat.",
    "vplayforce": "Put a video at the front of the voice-chat queue.",
    "pause": "Pause voice-chat playback.",
    "resume": "Resume voice-chat playback.",
    "skip": "Skip the current song.",
    "next": "Skip the current song.",
    "stop": "Stop playback and clear the queue.",
    "end": "Stop playback and clear the queue.",
    "queue": "Show the voice-chat queue.",
    "playing": "Show the currently playing track.",
    "seek": "Seek forward or to a timestamp.",
    "seekback": "Seek backward in the current track.",
    "activevc": "Show active voice chats.",
    "ac": "Show active voice chats.",
    "playmode": "Set who can control voice-chat playback.",
    "musicsettings": "Open music settings.",
    "auth": "Allow a member to control music.",
    "unauth": "Remove a member's music-control access.",
    "musicstats": "Show music-bot status.",
    "similar": "Recommend tracks related to the current song.",
    "recommend": "Recommend tracks related to a song name.",
    "radio": "Start or stop automatic related-track playback.",
    "autoplay": "Toggle same-artist autoplay.",
    "rec": "Send the current track as an MP3 to your private chat.",
    "unsave": "Remove a track from your favorites.",
    "favorites": "List your saved music tracks.",
    "history": "Show recent tracks played in this group.",
    "top": "Show the most played tracks in this group.",
    "language": "Set the group's bot language.",
    "music": "Open music help.",
    "alive": "Check whether the bot is online.",
    "ping": "Check the bot response time.",
    "support": "Open bot support information.",
    "privacy": "Show the privacy policy.",
    "donate": "Show donation information.",
    "login": "Owner only: connect the music playback account in this private chat.",
    "logout": "Owner only: disconnect the music playback account.",
    "setmusicaccount": "Owner only: change the playback account ID in private chat.",
    "removemusicaccount": "Owner only: remove the custom playback account ID and restore the configured default.",
}

if len(_GROUP_NAMES) > 100 or len(set(_GROUP_NAMES)) != len(_GROUP_NAMES):
    raise RuntimeError("Telegram group command menus must contain at most 100 unique commands.")
if len(_PRIVATE_NAMES) > 100 or len(set(_PRIVATE_NAMES)) != len(_PRIVATE_NAMES):
    raise RuntimeError("Telegram private command menus must contain at most 100 unique commands.")
if len(_OWNER_PRIVATE_NAMES) > 100 or len(set(_OWNER_PRIVATE_NAMES)) != len(_OWNER_PRIVATE_NAMES):
    raise RuntimeError("Telegram owner command menus must contain at most 100 unique commands.")
if len(set(_MUSIC_ONLY_NAMES)) != len(_MUSIC_ONLY_NAMES):
    raise RuntimeError("Music-only group command menu contains duplicate commands.")

_ALL_NAMES = tuple(
    dict.fromkeys((*_GROUP_NAMES, *_OWNER_PRIVATE_NAMES, *_MUSIC_ONLY_NAMES))
)
_COMMAND_DESCRIPTIONS = {
    name: _DESCRIPTIONS.get(
        name, f"Run /{name}; use /help for the command's usage and permissions."
    )
    for name in _ALL_NAMES
}


def _telegram_commands(names: tuple[str, ...]) -> list[types.BotCommand]:
    return [
        types.BotCommand(command=name, description=_COMMAND_DESCRIPTIONS[name][:256])
        for name in names
    ]


async def install_command_menus(client: Any) -> None:
    """Publish user-safe menus and an expanded group-admin menu."""
    from config import settings

    scopes = [
        (types.BotCommandScopeAllPrivateChats(), _PRIVATE_NAMES, "private chats"),
        (types.BotCommandScopeAllGroupChats(), _PUBLIC_NAMES, "group users"),
        (
            types.BotCommandScopeAllChatAdministrators(),
            _GROUP_NAMES,
            "group administrators",
        ),
    ]
    if settings.OWNER_ID:
        scopes.append(
            (
                types.BotCommandScopeChat(chat_id=settings.OWNER_ID),
                _OWNER_PRIVATE_NAMES,
                "owner private chat",
            )
        )
    for scope, names, label in scopes:
        try:
            await client.set_bot_commands(_telegram_commands(names), scope=scope)
        except Exception as exc:
            logger.warning(
                "Could not set the Telegram command menu for %s (%s).",
                label,
                type(exc).__name__,
            )
        else:
            logger.info("Telegram command menu set for %s (%d commands).", label, len(names))
    try:
        from music import db

        for chat_id in sorted(await db.get_music_only_chat_ids()):
            await set_music_only_chat_commands(client, chat_id)
    except Exception as exc:
        logger.warning(
            "Could not restore music-only group command menus (%s).",
            type(exc).__name__,
        )
    try:
        # This is Telegram's native commands menu, not a custom slash key.
        await client.set_chat_menu_button(menu_button=types.MenuButtonCommands())
    except Exception as exc:
        logger.warning(
            "Could not enable Telegram's native commands menu (%s).",
            type(exc).__name__,
        )


async def set_music_only_chat_commands(client: Any, chat_id: int) -> None:
    scope = types.BotCommandScopeChat(chat_id=int(chat_id))
    await client.set_bot_commands(_telegram_commands(_MUSIC_ONLY_NAMES), scope=scope)


async def restore_chat_commands(client: Any, chat_id: int) -> None:
    """Remove the per-chat override so Telegram falls back to normal group scopes."""
    await client.delete_bot_commands(
        scope=types.BotCommandScopeChat(chat_id=int(chat_id))
    )


def is_inline_command_query(query: str | None) -> bool:
    """Return whether an inline query asks for command suggestions."""
    text = (query or "").strip().lower()
    if not text or text in {"commands", "command", "cmd", "help"}:
        return True
    if text.startswith("/"):
        return True
    if text.startswith(("commands ", "command ", "cmd ")):
        return True
    first = text.split(maxsplit=1)[0]
    return first in _COMMAND_DESCRIPTIONS


def inline_command_matches(query: str | None) -> list[tuple[str, str]] | None:
    """Return menu entries for a command lookup, or None for a non-command query."""
    text = (query or "").strip().lower()
    if not is_inline_command_query(text):
        return None

    if text.startswith("/"):
        needle = text[1:].split(maxsplit=1)[0].split("@", 1)[0]
    elif text.startswith(("commands ", "command ", "cmd ")):
        needle = text.split(maxsplit=1)[1].strip().lstrip("/")
    elif text in {"", "commands", "command", "cmd", "help"}:
        needle = ""
    else:
        needle = text.split(maxsplit=1)[0]

    names = _ALL_NAMES if not needle else tuple(
        name
        for name in _ALL_NAMES
        if name.startswith(needle) or needle in name
    )
    return [(name, _COMMAND_DESCRIPTIONS[name]) for name in names[:30]]


def format_command_names() -> str:
    """Compact public command inventory for the in-chat /mcommands helper."""
    lines = ["Available Telegram commands (the menu is limited to 100 per chat):"]
    lines.append(" ".join(f"`/{name}`" for name in _PUBLIC_NAMES))
    lines.append("Use `/help` for module-specific usage and permission details.")
    return "\n".join(lines)


def format_admin_commands() -> str:
    """Return the expanded command inventory shown privately to group admins."""
    return (
        "<b>Administrator command menu</b>\n"
        "These controls are available to group administrators:\n\n"
        + " ".join(f"<code>/{name}</code>" for name in _GROUP_NAMES)
        + "\n\nUse /help for usage, permissions, and module details."
    )


def build_group_admin_keyboard(chat_id: int, bot_username: str):
    """Open the permission-checked, group-scoped management dashboard."""
    from management import font

    return types.InlineKeyboardMarkup(
        [
            [
                types.InlineKeyboardButton(
                    font("Protection"),
                    callback_data=f"groupdash:section:{chat_id}:protection",
                    style=ButtonStyle.PRIMARY,
                ),
                types.InlineKeyboardButton(
                    font("Welcome"),
                    callback_data=f"groupdash:section:{chat_id}:welcome",
                    style=ButtonStyle.PRIMARY,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    font("Moderation"),
                    callback_data=f"groupdash:section:{chat_id}:moderation",
                    style=ButtonStyle.DANGER,
                ),
                types.InlineKeyboardButton(
                    font("Notes & Filters"),
                    callback_data=f"groupdash:section:{chat_id}:content",
                    style=ButtonStyle.PRIMARY,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    font("Reports"),
                    callback_data=f"groupdash:section:{chat_id}:reports",
                    style=ButtonStyle.PRIMARY,
                ),
                types.InlineKeyboardButton(
                    font("Statistics"),
                    callback_data=f"groupdash:section:{chat_id}:group_stats",
                    style=ButtonStyle.SUCCESS,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    font("Backup & Config"),
                    callback_data=f"groupdash:section:{chat_id}:backup",
                    style=ButtonStyle.PRIMARY,
                ),
                types.InlineKeyboardButton(
                    font("Music Settings"),
                    callback_data=f"adminpanel:music:{chat_id}",
                    style=ButtonStyle.SUCCESS,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    font("Refresh Dashboard"),
                    callback_data=f"groupdash:home:{chat_id}",
                    style=ButtonStyle.PRIMARY,
                )
            ],
        ]
    )


def build_private_group_admin_keyboard(chat_id: int):
    """Build private group-admin controls scoped to one verified group."""
    from management import font

    return types.InlineKeyboardMarkup(
        [
            [
                types.InlineKeyboardButton(
                    font("Group dashboard"),
                    callback_data=f"groupdash:home:{chat_id}",
                    style=ButtonStyle.SUCCESS,
                )
            ],
            [
                types.InlineKeyboardButton(
                    "📋 Admin commands",
                    callback_data=f"adminpanel:commands:{chat_id}",
                )
            ],
        ]
    )


def build_owner_admin_keyboard():
    """Owner-only controls for account setup, help, and confirmed broadcasts."""
    return types.InlineKeyboardMarkup(
        [
            [
                types.InlineKeyboardButton(
                    "Set owner username",
                    callback_data="owner_admin:owner_username",
                    style=ButtonStyle.PRIMARY,
                ),
                types.InlineKeyboardButton(
                    "Set support username",
                    callback_data="owner_admin:support_username",
                    style=ButtonStyle.SUCCESS,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    "Clear owner username",
                    callback_data="owner_admin:clear_owner_username",
                    style=ButtonStyle.DANGER,
                ),
                types.InlineKeyboardButton(
                    "Reset support username",
                    callback_data="owner_admin:reset_support_username",
                    style=ButtonStyle.PRIMARY,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    "Set music account user ID",
                    callback_data="owner_admin:music_id",
                    style=ButtonStyle.PRIMARY,
                ),
                types.InlineKeyboardButton(
                    "Remove custom ID",
                    callback_data="owner_admin:remove_music_id",
                    style=ButtonStyle.DANGER,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    "Add music-only group ID",
                    callback_data="owner_admin:music_only_chat_add",
                    style=ButtonStyle.SUCCESS,
                ),
                types.InlineKeyboardButton(
                    "Remove music-only group ID",
                    callback_data="owner_admin:music_only_chat_remove",
                    style=ButtonStyle.DANGER,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    "Set play-search indicator",
                    callback_data="owner_admin:search_indicator",
                    style=ButtonStyle.SUCCESS,
                ),
                types.InlineKeyboardButton(
                    "Reset play-search indicator",
                    callback_data="owner_admin:reset_search_indicator",
                    style=ButtonStyle.DANGER,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    "Login / logout help",
                    callback_data="owner_admin:login_help",
                    style=ButtonStyle.PRIMARY,
                ),
                types.InlineKeyboardButton(
                    "Owner commands",
                    callback_data="owner_admin:commands",
                    style=ButtonStyle.PRIMARY,
                ),
            ],
            [
                types.InlineKeyboardButton(
                    "Create broadcast",
                    callback_data="owner_admin:broadcast",
                    style=ButtonStyle.SUCCESS,
                ),
            ],
        ]
    )


def format_owner_commands() -> str:
    """Return owner-only music account controls for the owner's private chat."""
    owner_names = (
        "admin",
        "login",
        "logout",
        "setmusicaccount",
        "removemusicaccount",
        "broadcast",
        "broadcast_all",
        "broadcast_users",
        "broadcast_chats",
        "gcast",
        "stop_gcast",
        "stop_broadcast",
    )
    return (
        "<b>Owner command menu</b>\n"
        "These private account controls are available only to the configured bot owner:\n\n"
        + " ".join(f"<code>/{name}</code>" for name in owner_names)
        + "\n\nBroadcast delivery always requires a preview and explicit confirmation. "
        "Set a positive personal Telegram user ID (not a group chat ID), then use "
        "/login to authorize it. /removemusicaccount restores the configured default ID. "
        "Use /logout first only when a music assistant is actually connected."
    )
