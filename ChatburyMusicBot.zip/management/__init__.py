"""Compatibility surface for EikoRobot's management plugins."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any

import aiohttp
from telegram import constants
from telegram.ext import ApplicationBuilder, Defaults
from telegraph.aio import Telegraph
from telethon import TelegramClient

from config import *
from config import settings
from database import get_client, get_database
import music
from management.helpers.font_helper import apply_custom_font

LOGGER = logging.getLogger("eiko.management")
START_TIME = time.time()
FORMAT = "[Bot] %(message)s"
MODULE: dict[str, str] = {}
database = get_database(settings.MONGO_DB_NAME)
database2 = get_database(settings.MONGO_DB2_NAME)
db = database
db_client = get_client()
db2_client = db_client
pbot = music.app
bot = music.app
userbot = music.userbot
user = music.userbot.one
MANAGEMENT_SESSION_NAME = (
    os.getenv(
        "MANAGEMENT_SESSION_NAME",
        f"sessions/management_mtproto_{settings.BOT_ID}",
    ).strip()
    or f"sessions/management_mtproto_{settings.BOT_ID}"
)
tbot = TelegramClient(
    MANAGEMENT_SESSION_NAME,
    settings.API_ID,
    settings.API_HASH,
    connection_retries=3,
)
tbot.handlers_loaded = set()
multi_clients = {0: pbot}
work_loads = {0: 0}
font = apply_custom_font
aiohttpsession: aiohttp.ClientSession | None = None
process: dict[str, Any] = {}

telegraph = Telegraph(access_token=settings.TELEGRAPH_TOKEN, domain="graph.org")


async def telegraph_create() -> None:
    await telegraph.create_account(
        short_name=settings.BOT_NAME,
        author_name=settings.BOT_NAME,
        author_url=(
            "https://t.me/" + settings.BOT_USERNAME.lstrip("@")
            if settings.BOT_USERNAME
            else "https://t.me/"
        ),
    )


class HybridApplication:
    """Keep PTB handler registration while delegating Bot API events to Kurigram."""

    _ptb_names = {
        "add_handler",
        "add_error_handler",
        "bot_data",
        "chat_data",
        "user_data",
        "job_queue",
        "process_update",
        "initialize",
        "start",
        "stop",
        "shutdown",
        "running",
        "handlers",
    }

    def __init__(self, client: Any, application: Any) -> None:
        self._client = client
        self._application = application

    @property
    def bot(self) -> Any:
        return self._application.bot

    @property
    def telegram_application(self) -> Any:
        return self._application

    def __getattr__(self, name: str) -> Any:
        if name in self._ptb_names:
            return getattr(self._application, name)
        return getattr(self._client, name)


ptb_defaults = Defaults(
    parse_mode=constants.ParseMode.MARKDOWN,
    allow_sending_without_reply=True,
    do_quote=True,
)
ptb_application = (
    ApplicationBuilder().defaults(ptb_defaults).token(settings.BOT_TOKEN).build()
    if settings.BOT_TOKEN
    else None
)
app = HybridApplication(pbot, ptb_application) if ptb_application else pbot


async def init_aiohttp_session() -> None:
    global aiohttpsession
    if aiohttpsession is None or aiohttpsession.closed:
        aiohttpsession = aiohttp.ClientSession()


async def start_all_clients() -> None:
    """Start only the legacy MTProto event client; Kurigram owns Bot API polling."""
    if not tbot.is_connected():
        await tbot.start(bot_token=settings.BOT_TOKEN)
        LOGGER.info("Legacy MTProto event handlers connected.")


async def stop_all_clients() -> None:
    if tbot.is_connected():
        await tbot.disconnect()
    if aiohttpsession and not aiohttpsession.closed:
        await aiohttpsession.close()


async def send_restart(application: Any = None) -> None:
    if not application or not settings.LOG_GROUP_ID:
        return
    try:
        with open("restart_data.txt", encoding="utf-8") as file:
            chat_id, message_id = map(int, file.read().strip().split(":"))
        await application.bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text="Bot restarted successfully.",
        )
        os.remove("restart_data.txt")
    except FileNotFoundError:
        return
    except Exception as exc:
        LOGGER.warning("Could not update restart status (%s).", type(exc).__name__)


async def initialize_database() -> None:
    from management.db import (
        afk,
        antiflood,
        antiforward_db,
        antiraid,
        antiremovelink_db,
        antitag_db,
        approval_db,
        autofilter,
        banall_db,
        bio_filter,
        chatbot,
        fsub,
        ghost_db,
        greetings,
        ignore,
        joinmute_db,
        locks_db,
        logchannel_db,
        mediadelete_db,
        moderation,
        owner_profile,
        search_indicator,
        nightmode_db,
        notes,
        riddle,
        sudo,
        users,
        warn_db,
        filter as filter_db,
    )

    await users.initialize_db_users()
    await afk.initialize_afk_users()
    await users.initialize_db_premium_users()
    await autofilter.initialize_db_chats()
    await chatbot.initialize_db_chats()
    await ignore.initialize_db_users()
    await notes.initialize_chats()
    await fsub.initialize_chats()
    await riddle.initialize_db_chats()
    await warn_db.initialize_chats()
    await moderation.initialize_moderation()
    await locks_db.initialize_chats()
    await antiflood.initialize_chats()
    await antiraid.initialize_chats()
    await approval_db.initialize_chats()
    await filter_db.initialize_chats()
    await antiremovelink_db.initialize_chats()
    await joinmute_db.initialize_chats()
    await antiforward_db.initialize_chats()
    await mediadelete_db.initialize_chats()
    await antitag_db.initialize_chats()
    await ghost_db.initialize_chats()
    await nightmode_db.initialize_chats()
    await logchannel_db.initialize_chats()
    await bio_filter.initialize_chats()
    await greetings.initialize_chats()
    await banall_db.initialize_chats()
    await sudo.initialize_cache()
    try:
        await owner_profile.initialize_public_profile()
    except Exception as exc:
        LOGGER.warning(
            "Could not load owner/support usernames (%s); using configured defaults.",
            type(exc).__name__,
        )
    try:
        await search_indicator.initialize_search_indicator()
    except Exception as exc:
        LOGGER.warning(
            "Could not load the music search indicator (%s); using the default.",
            type(exc).__name__,
        )
    LOGGER.info("Management database collections initialized.")
    if settings.LOG_GROUP_ID:
        try:
            await pbot.send_message(
                settings.LOG_GROUP_ID,
                "Eiko management modules initialized.",
            )
        except Exception as exc:
            LOGGER.warning("Could not send startup log (%s).", type(exc).__name__)


if not hasattr(tbot, "handlers_loaded"):
    tbot.handlers_loaded = set()
