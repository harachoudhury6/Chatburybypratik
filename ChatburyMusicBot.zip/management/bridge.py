"""Translate Kurigram updates for the existing python-telegram-bot handlers."""

from __future__ import annotations

import itertools
import logging
from datetime import date, datetime
from typing import Any

from telegram import Update
from pyrogram import filters

logger = logging.getLogger("eiko.telegram.bridge")
_update_ids = itertools.count(1)


def _date(value: Any) -> int | None:
    if isinstance(value, datetime):
        return int(value.timestamp())
    if isinstance(value, date):
        return int(datetime.combine(value, datetime.min.time()).timestamp())
    return int(value) if isinstance(value, (int, float)) else None


def _enum(value: Any) -> Any:
    return getattr(value, "value", value)


def _user(user: Any) -> dict[str, Any] | None:
    if user is None:
        return None
    result = {
        "id": user.id,
        "is_bot": bool(getattr(user, "is_bot", False)),
        "first_name": getattr(user, "first_name", None) or "User",
    }
    for name in (
        "last_name",
        "username",
        "language_code",
        "is_premium",
        "added_to_attachment_menu",
        "can_join_groups",
        "can_read_all_group_messages",
        "supports_inline_queries",
    ):
        value = getattr(user, name, None)
        if value is not None:
            result[name] = value
    return result


def _chat(chat: Any) -> dict[str, Any] | None:
    if chat is None:
        return None
    result = {"id": chat.id, "type": _enum(chat.type)}
    for name in ("title", "username", "first_name", "last_name", "is_forum"):
        value = getattr(chat, name, None)
        if value is not None:
            result[name] = value
    return result


def _entity(entity: Any) -> dict[str, Any]:
    result = {
        "type": _enum(entity.type),
        "offset": entity.offset,
        "length": entity.length,
    }
    for name in ("url", "language", "custom_emoji_id"):
        value = getattr(entity, name, None)
        if value is not None:
            result[name] = value
    user = _user(getattr(entity, "user", None))
    if user:
        result["user"] = user
    return result


def _file(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    result: dict[str, Any] = {}
    for name in (
        "file_id",
        "file_unique_id",
        "width",
        "height",
        "duration",
        "file_name",
        "mime_type",
        "file_size",
        "title",
        "performer",
        "emoji",
        "is_animated",
        "is_video",
        "has_spoiler",
        "set_name",
        "supports_streaming",
        "thumbnail",
    ):
        item = getattr(value, name, None)
        if item is not None:
            if name == "thumbnail":
                thumb = _file(item)
                if thumb:
                    result["thumbnail"] = thumb
            else:
                result[name] = item
    return result or None


def _member(
    member: Any,
    *,
    fallback_user: Any = None,
    fallback_status: str = "left",
) -> dict[str, Any]:
    # Pyrogram legitimately omits a participant on first joins and removals.
    # Treat a missing side of the transition as "left" instead of letting the
    # bridge crash before the existing welcome/goodbye handlers can run.
    if member is None:
        result: dict[str, Any] = {"status": fallback_status}
        user = _user(fallback_user)
        if user:
            result["user"] = user
        return result

    status = getattr(member, "status", None)
    result = {"status": _enum(status) if status is not None else fallback_status}
    user = _user(getattr(member, "user", None))
    if user is None:
        user = _user(fallback_user)
    if user:
        result["user"] = user
    until_date = _date(getattr(member, "until_date", None))
    if until_date is not None:
        result["until_date"] = until_date
    privileges = getattr(member, "privileges", None)
    if privileges:
        for name in (
            "can_be_edited",
            "is_anonymous",
            "can_manage_chat",
            "can_delete_messages",
            "can_manage_video_chats",
            "can_restrict_members",
            "can_promote_members",
            "can_change_info",
            "can_invite_users",
            "can_post_messages",
            "can_edit_messages",
            "can_pin_messages",
            "can_manage_topics",
        ):
            value = getattr(privileges, name, None)
            if value is not None:
                result[name] = value
    return result


def _message(message: Any, depth: int = 0) -> dict[str, Any]:
    result: dict[str, Any] = {
        "message_id": message.id,
        "date": _date(getattr(message, "date", None)),
        "chat": _chat(message.chat),
    }
    sender = _user(getattr(message, "from_user", None))
    if sender:
        result["from"] = sender
    sender_chat = _chat(getattr(message, "sender_chat", None))
    if sender_chat:
        result["sender_chat"] = sender_chat
    text = getattr(message, "text", None)
    caption = getattr(message, "caption", None)
    if text is not None:
        result["text"] = text
    if caption is not None:
        result["caption"] = caption
    for source, target in (
        ("entities", "entities"),
        ("caption_entities", "caption_entities"),
    ):
        entities = getattr(message, source, None)
        if entities:
            result[target] = [_entity(item) for item in entities]
    for name in ("edit_date", "media_group_id", "message_thread_id"):
        value = getattr(message, name, None)
        if value is not None:
            result[name] = _date(value) if name == "edit_date" else value

    for name in ("photo",):
        items = getattr(message, name, None)
        if items:
            photos = items if isinstance(items, (list, tuple)) else (items,)
            serialized = [item for obj in photos if (item := _file(obj))]
            if serialized:
                result[name] = serialized
    for name in (
        "animation",
        "audio",
        "document",
        "sticker",
        "video",
        "video_note",
        "voice",
    ):
        item = _file(getattr(message, name, None))
        if item:
            result[name] = item
    for name in ("contact", "location", "venue", "poll", "dice"):
        value = getattr(message, name, None)
        if value is not None:
            fields = (
                ("phone_number", "first_name", "last_name", "user_id", "vcard")
                if name == "contact"
                else ("latitude", "longitude", "horizontal_accuracy", "live_period", "heading", "proximity_alert_radius")
                if name == "location"
                else ("title", "address", "foursquare_id", "foursquare_type", "google_place_id", "google_place_type")
                if name == "venue"
                else ("id", "question", "total_voter_count", "is_closed", "type", "allows_multiple_answers", "correct_option_id", "explanation")
                if name == "poll"
                else ("emoji", "value")
            )
            item = {key: getattr(value, key) for key in fields if getattr(value, key, None) is not None}
            if name == "venue" and getattr(value, "location", None):
                location = value.location
                item["location"] = {
                    "latitude": location.latitude,
                    "longitude": location.longitude,
                }
            if name == "poll":
                item["options"] = [
                    {"text": option.text, "voter_count": getattr(option, "voter_count", 0)}
                    for option in (getattr(value, "options", None) or [])
                ]
            if item:
                result[name] = item

    for name in ("new_chat_title", "delete_chat_photo", "group_chat_created", "supergroup_chat_created"):
        value = getattr(message, name, None)
        if value:
            result[name] = value if isinstance(value, bool) else str(value)
    for name in ("new_chat_members",):
        members = getattr(message, name, None)
        if members:
            result[name] = [item for obj in members if (item := _user(obj))]
    left = _user(getattr(message, "left_chat_member", None))
    if left:
        result["left_chat_member"] = left
    reply = getattr(message, "reply_to_message", None)
    if reply is not None and depth < 2:
        result["reply_to_message"] = _message(reply, depth + 1)
    pinned = getattr(message, "pinned_message", None)
    if pinned is not None and depth < 1:
        result["pinned_message"] = _message(pinned, depth + 1)
    return {key: value for key, value in result.items() if value is not None}


def _update(payload: dict[str, Any], bot: Any) -> Update:
    return Update.de_json({"update_id": next(_update_ids), **payload}, bot)


async def install_bridge(client: Any, application: Any) -> None:
    if getattr(client, "_eiko_ptb_bridge_installed", False):
        return

    @client.on_message(filters.all, group=99_999)
    async def message_bridge(_, message):
        payload = {"message": _message(message)}
        if message.edit_date:
            payload = {"edited_message": _message(message)}
        await application.process_update(_update(payload, application.bot))

    @client.on_callback_query(filters.all, group=99_999)
    async def callback_bridge(_, query):
        payload = {
            "callback_query": {
                "id": query.id,
                "from": _user(query.from_user),
                "chat_instance": query.chat_instance,
                "data": query.data,
            }
        }
        if query.message:
            payload["callback_query"]["message"] = _message(query.message)
        if query.inline_message_id:
            payload["callback_query"]["inline_message_id"] = query.inline_message_id
        await application.process_update(_update(payload, application.bot))

    @client.on_chat_member_updated(group=99_999)
    async def chat_member_bridge(_, event):
        payload_key = "chat_member"
        bot_user = getattr(_, "me", None)
        bot_id = getattr(bot_user, "id", None)
        new_member = getattr(event, "new_chat_member", None)
        old_member = getattr(event, "old_chat_member", None)
        member_user = getattr(new_member, "user", None) or getattr(
            old_member, "user", None
        )
        if bot_id is not None and getattr(member_user, "id", None) == bot_id:
            payload_key = "my_chat_member"
        await application.process_update(
            _update(
                {
                    payload_key: {
                        "chat": _chat(event.chat),
                        "from": _user(event.from_user),
                        "date": _date(event.date),
                        "old_chat_member": _member(
                            old_member,
                            fallback_user=member_user,
                            fallback_status="left",
                        ),
                        "new_chat_member": _member(
                            new_member,
                            fallback_user=member_user,
                            fallback_status="left",
                        ),
                    }
                },
                application.bot,
            )
        )

    client._eiko_ptb_bridge_installed = True
    logger.info("Management handlers are connected to the shared Kurigram updates.")
