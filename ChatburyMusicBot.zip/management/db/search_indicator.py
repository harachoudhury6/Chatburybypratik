"""Owner-configurable text or sticker shown while a music search is running."""

from __future__ import annotations

from datetime import datetime, timezone

from management import database

_collection = database["music_search_indicator"]
_indicator: dict[str, str | None] = {"kind": "text", "value": None}


def get_search_indicator() -> dict[str, str | None]:
    return dict(_indicator)


async def initialize_search_indicator() -> None:
    document = await _collection.find_one({"_id": "global"})
    if document and document.get("kind") in {"text", "sticker"}:
        value = document.get("value")
        if isinstance(value, str) and value:
            _indicator.update(kind=document["kind"], value=value)


async def set_search_indicator(kind: str, value: str) -> None:
    if kind not in {"text", "sticker"} or not value:
        raise ValueError("Choose text or sticker and provide a value.")
    if len(value) > 200:
        raise ValueError("The search message must be 200 characters or fewer.")
    await _collection.update_one(
        {"_id": "global"},
        {"$set": {
            "kind": kind,
            "value": value,
            "updated_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )
    _indicator.update(kind=kind, value=value)


async def reset_search_indicator() -> None:
    await _collection.delete_one({"_id": "global"})
    _indicator.update(kind="text", value=None)
