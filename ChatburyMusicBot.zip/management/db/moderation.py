"""Persistent settings, strike counters, and audit records for auto moderation."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from pymongo import ReturnDocument

from config import settings
from management import database

settings_collection = database["moderation_settings"]
strikes_collection = database["moderation_strikes"]
dedupe_collection = database["moderation_dedupe"]
audit_collection = database["moderation_audit"]

_SETTING_KEYS = {
    "selling_enabled",
    "selling_gc_url",
    "selling_min_score",
    "spam_repeat_limit",
    "spam_mention_limit",
    "explicit_threshold",
    "abuse_terms",
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _strike_id(chat_id: int, user_id: int) -> str:
    return f"{chat_id}:{user_id}"


async def initialize_moderation() -> None:
    """Create non-unique indexes; document identity is enforced with _id."""
    await audit_collection.create_index([("chat_id", 1), ("created_at", -1)])
    await dedupe_collection.create_index(
        "created_at", expireAfterSeconds=int(timedelta(days=60).total_seconds())
    )


async def get_chat_settings(chat_id: int) -> dict[str, Any]:
    stored = await settings_collection.find_one({"_id": chat_id}) or {}
    return {
        "chat_id": chat_id,
        "selling_enabled": bool(stored.get("selling_enabled", False)),
        "selling_gc_url": (
            stored.get("selling_gc_url")
            if "selling_gc_url" in stored
            else settings.SELLING_GC_URL
        ),
        "selling_min_score": int(stored.get("selling_min_score", 4)),
        "spam_repeat_limit": int(stored.get("spam_repeat_limit", 5)),
        "spam_mention_limit": int(stored.get("spam_mention_limit", 8)),
        "explicit_threshold": float(stored.get("explicit_threshold", 0.95)),
        "abuse_terms": list(stored.get("abuse_terms", [])),
    }


async def set_chat_setting(chat_id: int, key: str, value: Any) -> None:
    if key not in _SETTING_KEYS:
        raise ValueError("Unsupported moderation setting.")
    await settings_collection.update_one(
        {"_id": chat_id},
        {"$set": {key: value, "chat_id": chat_id, "updated_at": _now()}},
        upsert=True,
    )


async def clear_chat_setting(chat_id: int, key: str) -> None:
    if key not in _SETTING_KEYS:
        raise ValueError("Unsupported moderation setting.")
    await settings_collection.update_one(
        {"_id": chat_id},
        {"$unset": {key: ""}, "$set": {"chat_id": chat_id, "updated_at": _now()}},
        upsert=True,
    )


async def claim_message(chat_id: int, message_id: int) -> bool:
    """Persistently claim a message so duplicate updates cannot act twice."""
    key = f"{chat_id}:{message_id}"
    result = await dedupe_collection.update_one(
        {"_id": key},
        {"$setOnInsert": {"chat_id": chat_id, "message_id": message_id, "created_at": _now()}},
        upsert=True,
    )
    return result.upserted_id is not None


async def add_strike(
    chat_id: int, user_id: int, reason: str, message_id: int
) -> int:
    """Increment the stable per-chat user counter atomically."""
    record = await strikes_collection.find_one_and_update(
        {"_id": _strike_id(chat_id, user_id)},
        {
            "$inc": {"count": 1},
            "$push": {"reasons": {"$each": [reason], "$slice": -20}},
            "$set": {"chat_id": chat_id, "user_id": user_id, "updated_at": _now()},
            "$setOnInsert": {"created_at": _now()},
        },
        upsert=True,
        return_document=ReturnDocument.AFTER,
    )
    return int((record or {}).get("count", 0))


async def get_strike_record(chat_id: int, user_id: int) -> dict[str, Any]:
    return await strikes_collection.find_one(
        {"_id": _strike_id(chat_id, user_id)}
    ) or {"chat_id": chat_id, "user_id": user_id, "count": 0, "reasons": []}


async def set_strike_count(chat_id: int, user_id: int, count: int) -> None:
    await strikes_collection.update_one(
        {"_id": _strike_id(chat_id, user_id)},
        {
            "$set": {
                "chat_id": chat_id,
                "user_id": user_id,
                "count": count,
                "updated_at": _now(),
            },
            "$setOnInsert": {"created_at": _now(), "reasons": []},
        },
        upsert=True,
    )
    if count == 0:
        await strikes_collection.update_one(
            {"_id": _strike_id(chat_id, user_id)},
            {"$set": {"reasons": []}},
        )


async def reset_strikes(chat_id: int, user_id: int) -> None:
    await strikes_collection.delete_one({"_id": _strike_id(chat_id, user_id)})


async def add_audit_record(
    *,
    chat_id: int,
    user_id: int,
    message_id: int,
    action: str,
    reason: str,
) -> None:
    record_id = f"{chat_id}:{message_id}:{action}"
    await audit_collection.update_one(
        {"_id": record_id},
        {
            "$setOnInsert": {
                "chat_id": chat_id,
                "user_id": user_id,
                "message_id": message_id,
                "action": action,
                "reason": reason[:300],
                "created_at": _now(),
            }
        },
        upsert=True,
    )


async def get_recent_audit(chat_id: int, limit: int = 10) -> list[dict[str, Any]]:
    cursor = (
        audit_collection.find({"chat_id": chat_id})
        .sort("created_at", -1)
        .limit(max(1, min(limit, 20)))
    )
    return await cursor.to_list(length=max(1, min(limit, 20)))
