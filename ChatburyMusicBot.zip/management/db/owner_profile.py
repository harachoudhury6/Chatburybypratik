"""Persistent public owner/support usernames used by bot contact buttons."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from urllib.parse import urlparse

from config import settings
from management import database

_collection = database["bot_public_profile"]
_DEFAULTS = {
    "owner_username": settings.OWNER_USERNAME or None,
    "support_username": settings.SUPPORT_USERNAME or "tgnxt",
}
_profile = dict(_DEFAULTS)
_USERNAME_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]{4,31}\Z")


def normalize_username(value: str) -> str:
    """Accept a Telegram username, @username, or direct t.me profile URL."""
    candidate = (value or "").strip()
    if candidate.startswith("t.me/"):
        candidate = f"https://{candidate}"
    if candidate.startswith(("https://t.me/", "http://t.me/")):
        parsed = urlparse(candidate)
        candidate = parsed.path.strip("/").split("/", 1)[0]
    candidate = candidate.removeprefix("@").strip()
    if not _USERNAME_RE.fullmatch(candidate):
        raise ValueError(
            "Send a Telegram username with 5–32 letters, numbers, or underscores "
            "(for example @tgnxt)."
        )
    return candidate


def get_public_profile() -> dict[str, str | None]:
    """Return the process-local profile cache with safe defaults."""
    return dict(_profile)


def username_url(username: str | None) -> str | None:
    normalized = (username or "").strip().lstrip("@")
    if not normalized or not _USERNAME_RE.fullmatch(normalized):
        return None
    return f"https://t.me/{normalized}"


async def initialize_public_profile() -> None:
    """Load saved links, creating the default profile once when needed."""
    document = await _collection.find_one_and_update(
        {"_id": "public_links"},
        {
            "$setOnInsert": {
                **_DEFAULTS,
                "created_at": datetime.now(timezone.utc),
            }
        },
        upsert=True,
        return_document=True,
    )
    if not document:
        document = await _collection.find_one({"_id": "public_links"}) or {}
    for key, fallback in _DEFAULTS.items():
        stored = document.get(key, fallback)
        try:
            _profile[key] = normalize_username(stored) if stored else fallback
        except ValueError:
            _profile[key] = fallback


async def set_public_username(field: str, value: str) -> str:
    """Validate and persist one owner/support username."""
    if field not in _DEFAULTS:
        raise ValueError("Unknown public profile field.")
    username = normalize_username(value)
    await _collection.update_one(
        {"_id": "public_links"},
        {
            "$set": {
                field: username,
                "updated_at": datetime.now(timezone.utc),
            }
        },
        upsert=True,
    )
    _profile[field] = username
    return username


async def reset_public_username(field: str) -> str | None:
    """Restore a profile field to its environment-configured default."""
    if field not in _DEFAULTS:
        raise ValueError("Unknown public profile field.")
    fallback = _DEFAULTS[field]
    if fallback:
        await _collection.update_one(
            {"_id": "public_links"},
            {
                "$set": {
                    field: fallback,
                    "updated_at": datetime.now(timezone.utc),
                }
            },
            upsert=True,
        )
    else:
        await _collection.update_one(
            {"_id": "public_links"},
            {
                "$unset": {field: ""},
                "$set": {"updated_at": datetime.now(timezone.utc)},
            },
            upsert=True,
        )
    _profile[field] = fallback
    return fallback
