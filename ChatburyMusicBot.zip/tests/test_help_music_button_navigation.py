import re
import json
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from pyrogram import enums

from config import BOT_NAME
from management.plugins.base import _gsb
from music.helpers import buttons
from music.plugins import callbacks


def _all_buttons(markup):
    return [button for row in markup.inline_keyboard for button in row]


class HelpMusicButtonNavigationTests(unittest.TestCase):
    def test_start_menu_has_separate_music_and_help_buttons(self):
        callbacks_by_text = {
            button.text: button.callback_data for button in _all_buttons(_gsb(1234))
        }
        self.assertEqual(callbacks_by_text["ᴍᴜꜱɪᴄ ᴘʟᴀʏᴇʀ"], "music_help_home_1234")
        self.assertEqual(callbacks_by_text["ʜᴇʟᴘ & ᴄᴏᴍᴍᴀɴᴅꜱ"], "help_1234")
        self.assertIn("ɢʀᴏᴜᴘ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ", callbacks_by_text)

    def test_music_help_filter_does_not_capture_music_start_callback(self):
        pattern = callbacks.MUSIC_HELP_CALLBACK_PATTERN
        self.assertIsNotNone(re.search(pattern, "help"))
        self.assertIsNotNone(re.search(pattern, "help play"))
        self.assertIsNotNone(re.search(pattern, "help back"))
        self.assertIsNotNone(re.search(pattern, "help close"))
        self.assertIsNone(re.search(pattern, "settings_back_helper"))

    def test_help_buttons_use_callbacks_handled_by_help_route(self):
        language = json.loads(Path("music/locales/en.json").read_text())
        test_language = {**language, "back": "Back"}
        root_callbacks = {
            button.callback_data for button in _all_buttons(buttons.help_markup(test_language))
        }
        root_labels = {
            button.text: button.callback_data
            for button in _all_buttons(buttons.help_markup(test_language))
        }
        back_callbacks = {
            button.callback_data for button in _all_buttons(
                buttons.help_markup(test_language, back=True)
            )
        }
        self.assertIn("help play", root_callbacks)
        self.assertEqual(root_labels["Back"], "settings_back_helper")
        self.assertNotIn("help close", root_callbacks)
        self.assertEqual(back_callbacks, {"help back"})
        self.assertTrue(all(
            callback.startswith("help ")
            for callback in root_callbacks
            if callback != "settings_back_helper"
        ))

    def test_each_visible_help_category_has_a_translation(self):
        language = json.loads(Path("music/locales/en.json").read_text())
        for command in ("admins", "auth", "blist", "lang", "ping", "play", "queue", "stats", "sudo"):
            with self.subTest(command=command):
                self.assertTrue(language.get(f"help_{command}"))
                self.assertTrue(language.get(f"help_{('admins', 'auth', 'blist', 'lang', 'ping', 'play', 'queue', 'stats', 'sudo').index(command)}"))


class HelpMusicCallbackTests(unittest.IsolatedAsyncioTestCase):
    async def test_every_visible_help_category_opens_its_content(self):
        language = json.loads(Path("music/locales/en.json").read_text())
        commands = ("admins", "auth", "blist", "lang", "ping", "play", "queue", "stats", "sudo")
        for command in commands:
            with self.subTest(command=command):
                query = SimpleNamespace(
                    data=f"help {command}",
                    lang=language,
                    answer=AsyncMock(),
                    edit_message_text=AsyncMock(),
                    edit_message_caption=AsyncMock(),
                )
                with patch.object(buttons, "help_markup", return_value="back-keyboard"):
                    await callbacks._help.__wrapped__(None, query)
                query.answer.assert_awaited_once()
                query.edit_message_text.assert_awaited_once_with(
                    text=language[f"help_{command}"],
                    reply_markup="back-keyboard",
                )
                query.edit_message_caption.assert_not_awaited()

    async def test_music_button_opens_music_start_menu(self):
        query = SimpleNamespace(
            message=SimpleNamespace(
                chat=SimpleNamespace(type=enums.ChatType.PRIVATE)
            ),
            from_user=SimpleNamespace(first_name="Listener"),
            lang={"start_pm": "Welcome {}, {}"},
            answer=AsyncMock(),
            edit_message_text=AsyncMock(),
            edit_message_caption=AsyncMock(),
        )

        with patch.object(buttons, "start_key", return_value="music-start-keyboard"):
            await callbacks._back_helper.__wrapped__(None, query)

        query.answer.assert_awaited_once()
        query.edit_message_text.assert_awaited_once_with(
            f"Welcome Listener, {BOT_NAME}",
            reply_markup="music-start-keyboard",
        )
        query.edit_message_caption.assert_not_awaited()

    async def test_help_back_returns_to_music_help_categories(self):
        query = SimpleNamespace(
            data="help back",
            lang={"help_menu": "Music help categories"},
            answer=AsyncMock(),
            edit_message_text=AsyncMock(),
            edit_message_caption=AsyncMock(),
        )

        with patch.object(buttons, "help_markup", return_value="help-keyboard"):
            await callbacks._help.__wrapped__(None, query)

        query.answer.assert_awaited_once()
        query.edit_message_text.assert_awaited_once_with(
            text=f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\nMusic help categories",
            reply_markup="help-keyboard",
        )

    async def test_music_button_opens_branded_music_board_with_back_markup(self):
        query = SimpleNamespace(
            data="music_help_home_1234",
            message=SimpleNamespace(chat=SimpleNamespace(id=123, type=enums.ChatType.PRIVATE)),
            from_user=SimpleNamespace(id=1234),
            lang={"help_menu": "Music commands"},
            answer=AsyncMock(),
            edit_message_text=AsyncMock(),
            edit_message_caption=AsyncMock(),
        )
        with patch.object(buttons, "help_markup", return_value="music-board-keyboard"):
            await callbacks._music_help_home.__wrapped__(None, query)
        query.answer.assert_awaited_once()
        query.edit_message_text.assert_awaited_once_with(
            text=f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\nMusic commands",
            reply_markup="music-board-keyboard",
        )

