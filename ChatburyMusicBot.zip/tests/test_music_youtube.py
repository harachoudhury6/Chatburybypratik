import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import yt_dlp

import music.core.youtube as youtube_module
from music.core.youtube import YouTube, _failure_category


class YouTubeSearchTests(unittest.IsolatedAsyncioTestCase):
    async def test_search_skips_sign_in_gated_result_and_uses_next_audio_result(self):
        client = YouTube()
        seen = []

        async def fake_extract(target, _options, attempts=3):
            seen.append(target)
            if target == "ytsearch1:295":
                return {
                    "entries": [
                        {
                            "id": "A1234567890",
                            "webpage_url": "https://www.youtube.com/watch?v=A1234567890",
                        }
                    ]
                }
            if target == "ytsearch3:295":
                return {
                    "entries": [
                        {
                            "id": "A1234567890",
                            "webpage_url": "https://www.youtube.com/watch?v=A1234567890",
                        },
                        {
                            "id": "B1234567890",
                            "webpage_url": "https://www.youtube.com/watch?v=B1234567890",
                        },
                    ]
                }
            if target.endswith("A1234567890"):
                raise yt_dlp.utils.DownloadError(
                    "Sign in to confirm you are not a bot"
                )
            return {
                "id": "B1234567890",
                "title": "295 public version",
                "webpage_url": target,
                "duration": 180,
                "formats": [{"acodec": "opus", "vcodec": "none"}],
            }

        with patch.object(
            client, "_extract_with_retry", new=AsyncMock(side_effect=fake_extract)
        ):
            track = await client.search("295", 123)

        self.assertIsNotNone(track)
        self.assertEqual(track.id, "B1234567890")
        self.assertEqual(seen[:2], ["ytsearch1:295", "ytsearch3:295"])
        self.assertIn("B1234567890", seen[-1])
        self.assertIsNone(client.last_error)

    async def test_search_returns_stream_url_from_first_public_audio_result(self):
        client = YouTube()
        audio_info = {
            "id": "S1234567890",
            "title": "Sawaal",
            "webpage_url": "https://www.youtube.com/watch?v=S1234567890",
            "duration": 180,
            "formats": [
                {
                    "url": "https://media.example/audio-low",
                    "acodec": "opus",
                    "vcodec": "none",
                    "abr": 64,
                },
                {
                    "url": "https://media.example/audio-high",
                    "acodec": "opus",
                    "vcodec": "none",
                    "abr": 128,
                    "http_headers": {"User-Agent": "yt-dlp"},
                },
            ],
        }
        with patch.object(
            client,
            "_extract_with_retry",
            new=AsyncMock(return_value={"entries": [audio_info]}),
        ) as extract:
            track = await client.search("sawaal", 123)

        extract.assert_awaited_once()
        self.assertEqual(extract.await_args.args[0], "ytsearch1:sawaal")
        self.assertEqual(track.stream_url, "https://media.example/audio-high")
        self.assertEqual(track.stream_headers, {"User-Agent": "yt-dlp"})

    async def test_explicit_soundcloud_search_uses_yt_dlp_extractor(self):
        client = YouTube()
        with patch.object(
            client,
            "_extract_with_retry",
            new=AsyncMock(
                return_value={
                    "entries": [
                        {
                            "id": "2170118373",
                            "title": "Sawaal",
                            "extractor_key": "Soundcloud",
                            "webpage_url": "https://soundcloud.com/example/sawaal",
                            "duration": 120,
                            "formats": [{"acodec": "aac", "vcodec": "none"}],
                        }
                    ]
                }
            ),
        ) as extract:
            track = await client.search("scsearch1:sawaal", 123)

        self.assertEqual(extract.await_args.args[0], "scsearch1:sawaal")
        self.assertIsNotNone(track)
        self.assertEqual(track.id, "sc_2170118373")
        self.assertEqual(track.url, "https://soundcloud.com/example/sawaal")

    def test_authentication_challenge_is_not_classified_as_host_rate_limit(self):
        error = yt_dlp.utils.DownloadError("Sign in to confirm you are not a bot")
        self.assertEqual(_failure_category(error), "requires_signin")
        self.assertEqual(
            _failure_category(yt_dlp.utils.DownloadError("HTTP Error 429: Too Many Requests")),
            "rate_limited",
        )

    def test_cleanup_only_removes_unreferenced_managed_downloads(self):
        client = YouTube()
        with tempfile.TemporaryDirectory() as temp_dir:
            downloads = Path(temp_dir)
            file_path = downloads / "A1234567890.mp3"
            file_path.write_bytes(b"x" * 1024)
            with patch.object(youtube_module, "DOWNLOAD_DIR", downloads):
                queue_with_reference = SimpleNamespace(
                    queues={-100: [SimpleNamespace(file_path=str(file_path))]}
                )
                self.assertFalse(
                    client.cleanup_download(str(file_path), queue_with_reference)
                )
                self.assertTrue(file_path.exists())
                self.assertTrue(client.cleanup_download(str(file_path)))
                self.assertFalse(file_path.exists())
