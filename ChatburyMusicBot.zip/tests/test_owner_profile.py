import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from management.db import owner_profile
from config import settings
from music.plugins import account
from pyrogram import enums


class OwnerProfileTests(unittest.IsolatedAsyncioTestCase):
    def test_normalizes_supported_username_inputs(self):
        self.assertEqual(owner_profile.normalize_username("@tgnxt"), "tgnxt")
        self.assertEqual(owner_profile.normalize_username("tgnxt"), "tgnxt")
        self.assertEqual(
            owner_profile.normalize_username("https://t.me/tgnxt"), "tgnxt"
        )
        self.assertEqual(owner_profile.normalize_username("t.me/tgnxt"), "tgnxt")

    def test_rejects_invalid_or_non_profile_links(self):
        for value in ("abc", "https://example.com/tgnxt", "https://t.me/", "@bad-name"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                owner_profile.normalize_username(value)

    def test_username_url_only_returns_valid_direct_profile_links(self):
        self.assertEqual(
            owner_profile.username_url("tgnxt"), "https://t.me/tgnxt"
        )
        self.assertIsNone(owner_profile.username_url(None))
        self.assertIsNone(owner_profile.username_url("not-valid"))

    async def test_profile_load_save_and_reset_persist_values(self):
        collection = SimpleNamespace(
            find_one_and_update=AsyncMock(
                return_value={
                    "owner_username": "ownername",
                    "support_username": "tgnxt",
                }
            ),
            find_one=AsyncMock(return_value=None),
            update_one=AsyncMock(),
        )
        with (
            patch.object(owner_profile, "_collection", collection),
            patch.object(owner_profile, "_profile", dict(owner_profile._DEFAULTS)),
        ):
            await owner_profile.initialize_public_profile()
            self.assertEqual(
                owner_profile.get_public_profile()["owner_username"], "ownername"
            )

            saved = await owner_profile.set_public_username(
                "support_username", "@supporter"
            )
            self.assertEqual(saved, "supporter")
            self.assertEqual(
                owner_profile.get_public_profile()["support_username"], "supporter"
            )

            reset = await owner_profile.reset_public_username("support_username")
            self.assertEqual(reset, "tgnxt")
            self.assertEqual(
                owner_profile.get_public_profile()["support_username"], "tgnxt"
            )
            self.assertEqual(collection.update_one.await_count, 2)

    async def test_owner_panel_prompts_and_saves_support_username(self):
        account._pending_public_username_inputs.pop(settings.OWNER_ID, None)
        query = SimpleNamespace(
            from_user=SimpleNamespace(id=settings.OWNER_ID),
            message=SimpleNamespace(
                chat=SimpleNamespace(type=enums.ChatType.PRIVATE),
                reply_text=AsyncMock(),
            ),
            data="owner_admin:support_username",
            answer=AsyncMock(),
        )
        await account.owner_admin_callback(None, query)
        self.assertEqual(
            account._pending_public_username_inputs[settings.OWNER_ID][0],
            "support_username",
        )

        message = SimpleNamespace(
            from_user=SimpleNamespace(id=settings.OWNER_ID),
            chat=SimpleNamespace(type=enums.ChatType.PRIVATE),
            text="@supportname",
            reply_text=AsyncMock(),
        )
        with patch.object(
            owner_profile,
            "set_public_username",
            new=AsyncMock(return_value="supportname"),
        ) as save_username:
            await account.capture_public_username_input(None, message)

        save_username.assert_awaited_once_with("support_username", "@supportname")
        self.assertNotIn(settings.OWNER_ID, account._pending_public_username_inputs)
        self.assertIn("Support username saved", message.reply_text.await_args.args[0])

    async def test_non_owner_cannot_open_public_username_setting(self):
        query = SimpleNamespace(
            from_user=SimpleNamespace(id=settings.OWNER_ID + 1),
            message=SimpleNamespace(
                chat=SimpleNamespace(type=enums.ChatType.PRIVATE),
                reply_text=AsyncMock(),
            ),
            data="owner_admin:owner_username",
            answer=AsyncMock(),
        )
        await account.owner_admin_callback(None, query)

        query.answer.assert_awaited_once()
        self.assertTrue(query.answer.await_args.kwargs.get("show_alert"))
        self.assertNotIn(settings.OWNER_ID, account._pending_public_username_inputs)


if __name__ == "__main__":
    unittest.main()
