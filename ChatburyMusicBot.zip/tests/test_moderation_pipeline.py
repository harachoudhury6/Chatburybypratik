import io
import os
import shutil
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import ANY, AsyncMock, call, patch

from PIL import Image, ImageDraw, ImageFont

from management.helpers import media_moderation
from management.helpers.media_moderation import scan_message_media
from management.helpers.moderation_rules import find_abusive_term
from management.plugins import moderation_guard


class ModerationPipelineTests(unittest.IsolatedAsyncioTestCase):
    def test_repeated_identical_messages_reach_spam_limit(self):
        counts = [
            moderation_guard._record_repeat(-100999, 999, "same text", message_id)[0]
            for message_id in range(1, 6)
        ]
        self.assertEqual(counts, [1, 2, 3, 4, 5])

    async def test_warning_counter_bans_on_third_strike(self):
        message = SimpleNamespace(
            id=100,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Test"),
        )
        client = SimpleNamespace(ban_chat_member=AsyncMock())
        add_strike = AsyncMock(side_effect=[1, 2, 3])
        delete = AsyncMock(return_value=True)

        with (
            patch.object(moderation_guard, "_claim_action", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "_delete_message", new=delete),
            patch.object(moderation_guard, "add_strike", new=add_strike),
            patch.object(moderation_guard, "_send_notice", new=AsyncMock()) as notice,
            patch.object(moderation_guard, "_audit", new=AsyncMock()),
        ):
            for expected in ("Warning 1/3", "Warning 2/3", "Warning 3/3"):
                await moderation_guard._handle_abuse(client, message, "test term")
                self.assertIn(expected, notice.await_args.args[2])

        delete.assert_has_awaits([call(message), call(message), call(message)])
        client.ban_chat_member.assert_awaited_once_with(-100123, 2468)

    async def test_duplicate_message_does_not_add_a_second_warning(self):
        message = SimpleNamespace(
            id=103,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Test", is_bot=False),
        )
        with (
            patch.object(moderation_guard, "_claim_action", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "_delete_message", new=AsyncMock()) as delete,
            patch.object(moderation_guard, "add_strike", new=AsyncMock()) as add_strike,
            patch.object(moderation_guard, "_send_notice", new=AsyncMock()) as notice,
        ):
            await moderation_guard._handle_abuse(object(), message, "test term")
        delete.assert_not_awaited()
        add_strike.assert_not_awaited()
        notice.assert_not_awaited()

    async def test_bot_sender_is_never_banned_by_abuse_handler(self):
        message = SimpleNamespace(
            id=104,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=777, first_name="Bot", is_bot=True),
        )
        client = SimpleNamespace(ban_chat_member=AsyncMock())
        with (
            patch.object(moderation_guard, "_claim_action", new=AsyncMock()) as claim,
            patch.object(moderation_guard, "_delete_message", new=AsyncMock()) as delete,
            patch.object(moderation_guard, "add_strike", new=AsyncMock()) as add_strike,
        ):
            await moderation_guard._handle_abuse(client, message, "test term")
            await moderation_guard._handle_explicit_media(
                client, message, "test category", 0.99
            )
        claim.assert_not_awaited()
        delete.assert_not_awaited()
        add_strike.assert_not_awaited()
        client.ban_chat_member.assert_not_awaited()

    async def test_confident_text_abuse_is_handled_before_media_scan(self):
        message = SimpleNamespace(
            id=105,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Test", is_bot=False),
            text="m@d4rch0d",
            caption=None,
        )
        client = SimpleNamespace(me=SimpleNamespace(id=9000))
        with (
            patch.object(moderation_guard, "_is_group_admin", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "is_user_approved", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "is_abuse_enabled", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "get_antinsfw", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "get_antinsfw_admin", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "get_chat_settings", new=AsyncMock(return_value={})),
            patch.object(
                moderation_guard,
                "scan_message_media",
                new=AsyncMock(side_effect=AssertionError("text should be handled before media scan")),
            ),
            patch.object(moderation_guard, "_handle_abuse", new=AsyncMock()) as handle,
        ):
            with self.assertRaises(moderation_guard.StopPropagation):
                await moderation_guard._moderate_message(client, message)
        handle.assert_awaited_once_with(client, message, ANY)

    async def test_group_admins_are_exempt_from_abuse_warnings(self):
        message = SimpleNamespace(
            id=106,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Admin", is_bot=False),
            text="madarchod",
            caption=None,
        )
        with (
            patch.object(moderation_guard, "_is_group_admin", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "is_user_approved", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "is_abuse_enabled", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "get_antinsfw", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "get_antinsfw_admin", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "get_chat_settings", new=AsyncMock(return_value={})),
            patch.object(moderation_guard, "_handle_abuse", new=AsyncMock()) as handle,
        ):
            await moderation_guard._moderate_message(
                SimpleNamespace(me=SimpleNamespace(id=9000)), message
            )

        handle.assert_not_awaited()

    async def test_explicit_media_filter_scans_members_and_admins(self):
        for is_admin in (False, True):
            with self.subTest(is_admin=is_admin):
                message = SimpleNamespace(
                    id=107,
                    chat=SimpleNamespace(id=-100123),
                    from_user=SimpleNamespace(id=2468, first_name="Test", is_bot=False),
                    text=None,
                    caption=None,
                )
                scan = SimpleNamespace(
                    has_media=True,
                    analyzed=True,
                    frames=(b"mock-frame",),
                    ocr_text="",
                    ocr_analyzed=True,
                    reason=None,
                )
                client = SimpleNamespace(me=SimpleNamespace(id=9000))
                with (
                    patch.object(
                        moderation_guard,
                        "_is_group_admin",
                        new=AsyncMock(return_value=is_admin),
                    ),
                    patch.object(
                        moderation_guard, "is_user_approved", new=AsyncMock(return_value=False)
                    ),
                    patch.object(
                        moderation_guard, "is_abuse_enabled", new=AsyncMock(return_value=True)
                    ),
                    patch.object(
                        moderation_guard, "get_antinsfw", new=AsyncMock(return_value=True)
                    ),
                    patch.object(
                        moderation_guard,
                        "get_antinsfw_admin",
                        new=AsyncMock(return_value=True),
                    ),
                    patch.object(
                        moderation_guard, "get_chat_settings", new=AsyncMock(return_value={})
                    ),
                    patch.object(
                        moderation_guard, "scan_message_media", new=AsyncMock(return_value=scan)
                    ) as scan_media,
                    patch.object(
                        moderation_guard.nsfw_engine,
                        "classify",
                        new=AsyncMock(
                            return_value={
                                "explicit": True,
                                "confidence": 0.99,
                                "category": "FEMALE_GENITALIA_EXPOSED",
                            }
                        ),
                    ),
                    patch.object(
                        moderation_guard, "_handle_explicit_media", new=AsyncMock()
                    ) as handle,
                ):
                    with self.assertRaises(moderation_guard.StopPropagation):
                        await moderation_guard._moderate_message(client, message)
                scan_media.assert_awaited_once_with(client, message)
                handle.assert_awaited_once_with(
                    client, message, "FEMALE_GENITALIA_EXPOSED", 0.99
                )

    async def test_delete_permission_failure_is_reported_in_warning(self):
        message = SimpleNamespace(
            id=106,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Test", is_bot=False),
        )
        with (
            patch.object(moderation_guard, "_claim_action", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "_delete_message", new=AsyncMock(return_value=False)),
            patch.object(moderation_guard, "add_strike", new=AsyncMock(return_value=1)),
            patch.object(moderation_guard, "_send_notice", new=AsyncMock()) as notice,
            patch.object(moderation_guard, "_audit", new=AsyncMock()),
        ):
            await moderation_guard._handle_abuse(object(), message, "test term")
        self.assertIn("Warning 1/3", notice.await_args.args[2])
        self.assertIn("could not delete", notice.await_args.args[2])

    async def test_selling_notice_uses_configured_link_and_sixty_seconds(self):
        message = SimpleNamespace(
            id=101,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Test"),
        )
        with (
            patch.object(moderation_guard, "_claim_action", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "_delete_message", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "_send_notice", new=AsyncMock()) as notice,
            patch.object(moderation_guard, "_audit", new=AsyncMock()),
        ):
            await moderation_guard._handle_selling(
                object(), message, "https://t.me/OfficialSellingInvite"
            )

        markup = notice.await_args.args[3]
        button = markup.inline_keyboard[0][0]
        self.assertEqual(button.text, "🛍️ Join Selling GC")
        self.assertEqual(button.url, "https://t.me/OfficialSellingInvite")
        self.assertEqual(notice.await_args.kwargs["ttl"], 60)

    async def test_temporary_notice_is_deleted_after_requested_delay(self):
        notice = SimpleNamespace(delete=AsyncMock())
        with patch.object(moderation_guard.asyncio, "sleep", new=AsyncMock()) as sleep:
            await moderation_guard._delete_after(notice, 60)
        sleep.assert_awaited_once_with(60)
        notice.delete.assert_awaited_once()

    async def test_explicit_media_handler_attempts_removal_and_ban(self):
        message = SimpleNamespace(
            id=102,
            chat=SimpleNamespace(id=-100123),
            from_user=SimpleNamespace(id=2468, first_name="Test"),
        )
        client = SimpleNamespace(ban_chat_member=AsyncMock())
        with (
            patch.object(moderation_guard, "_claim_action", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "_delete_message", new=AsyncMock(return_value=True)),
            patch.object(moderation_guard, "_send_notice", new=AsyncMock()) as notice,
            patch.object(moderation_guard, "_audit", new=AsyncMock()),
        ):
            await moderation_guard._handle_explicit_media(
                client, message, "MALE_GENITALIA_EXPOSED", 0.97
            )
        client.ban_chat_member.assert_awaited_once_with(-100123, 2468)
        self.assertIn("you were banned", notice.await_args.args[2])

    @unittest.skipUnless(shutil.which("tesseract"), "Tesseract is not installed.")
    async def test_image_ocr_text_reaches_abuse_detector(self):
        image = Image.new("RGB", (1000, 260), "white")
        ImageDraw.Draw(image).text(
            (30, 40), "fuck", fill="black", font=ImageFont.load_default(size=120)
        )
        content = io.BytesIO()
        image.save(content, format="PNG")
        data = content.getvalue()
        photo = SimpleNamespace(file_size=len(data), file_name="sample.png")
        message = SimpleNamespace(
            photo=photo,
            sticker=None,
            animation=None,
            video=None,
            video_note=None,
            document=None,
        )

        class Client:
            async def download_media(self, message, in_memory=False):
                self.used_memory_download = in_memory
                return io.BytesIO(data)

        result = await scan_message_media(Client(), message)
        self.assertTrue(result.analyzed, result.reason)
        self.assertTrue(result.ocr_analyzed, result.reason)
        self.assertIsNotNone(find_abusive_term(result.ocr_text), result.ocr_text)

    @unittest.skipUnless(shutil.which("tesseract"), "Tesseract is not installed.")
    async def test_sticker_ocr_text_reaches_abuse_detector(self):
        image = Image.new("RGB", (1000, 260), "white")
        ImageDraw.Draw(image).text(
            (30, 40), "fuck", fill="black", font=ImageFont.load_default(size=120)
        )
        content = io.BytesIO()
        image.save(content, format="WEBP")
        data = content.getvalue()
        sticker = SimpleNamespace(
            file_size=len(data),
            file_name="sample.webp",
            is_video=False,
            is_animated=False,
        )
        message = SimpleNamespace(
            photo=None,
            sticker=sticker,
            animation=None,
            video=None,
            video_note=None,
            document=None,
        )

        class Client:
            async def download_media(self, message, in_memory=False):
                self.used_memory_download = in_memory
                return io.BytesIO(data)

        result = await scan_message_media(Client(), message)
        self.assertTrue(result.analyzed, result.reason)
        self.assertTrue(result.ocr_analyzed, result.reason)
        self.assertIsNotNone(find_abusive_term(result.ocr_text), result.ocr_text)

    async def test_ocr_failure_keeps_decoded_frames_for_visual_analysis(self):
        photo = SimpleNamespace(file_size=3, file_name="sample.png")
        message = SimpleNamespace(
            photo=photo,
            sticker=None,
            animation=None,
            video=None,
            video_note=None,
            document=None,
        )

        class Client:
            async def download_media(self, message, in_memory=False):
                return io.BytesIO(b"raw")

        with (
            patch.object(
                media_moderation,
                "_extract_frames",
                new=AsyncMock(return_value=(b"decoded-frame",)),
            ),
            patch.object(
                media_moderation,
                "_ocr_frames",
                new=AsyncMock(side_effect=RuntimeError("OCR unavailable")),
            ),
        ):
            result = await scan_message_media(Client(), message)
        self.assertTrue(result.analyzed)
        self.assertFalse(result.ocr_analyzed)
        self.assertEqual(result.frames, (b"decoded-frame",))
        self.assertIn("OCR unavailable", result.reason)

    async def test_unsupported_media_is_not_reported_as_scanned(self):
        photo = SimpleNamespace(file_size=3, file_name="sample.unknown")
        message = SimpleNamespace(
            photo=photo,
            sticker=None,
            animation=None,
            video=None,
            video_note=None,
            document=None,
        )

        class Client:
            async def download_media(self, message, in_memory=False):
                return io.BytesIO(b"raw")

        with (
            patch.object(
                media_moderation,
                "_extract_frames",
                new=AsyncMock(return_value=()),
            ),
            patch.object(media_moderation, "_ocr_frames", new=AsyncMock()) as ocr,
        ):
            result = await scan_message_media(Client(), message)
        self.assertTrue(result.has_media)
        self.assertFalse(result.analyzed)
        self.assertFalse(result.ocr_analyzed)
        self.assertIn("No image frames", result.reason)
        ocr.assert_not_awaited()

    async def test_animated_sticker_uses_tgs_frame_renderer(self):
        with patch.object(
            media_moderation,
            "_tgs_frames",
            new=AsyncMock(return_value=(b"frame-one",)),
        ) as render:
            frames = await media_moderation._extract_frames(
                Path("animated.tgs"), ".tgs", "application/x-tgsticker", None
            )
        self.assertEqual(frames, (b"frame-one",))
        render.assert_awaited_once()

    def test_ocr_language_config_uses_only_installed_requested_data(self):
        import pytesseract

        media_moderation._ocr_languages = None
        try:
            with (
                patch.dict(os.environ, {"MODERATION_OCR_LANGUAGES": "rus+ben+eng"}),
                patch.object(pytesseract, "get_languages", return_value={"ben", "eng"}),
            ):
                self.assertEqual(media_moderation._choose_ocr_languages(), "ben+eng")
        finally:
            media_moderation._ocr_languages = None


if __name__ == "__main__":
    unittest.main()
