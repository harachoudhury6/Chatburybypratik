import unittest
from types import SimpleNamespace

from management.bridge import _member


class BridgeMemberTests(unittest.TestCase):
    def test_missing_previous_member_is_normalized_as_left(self):
        user = SimpleNamespace(id=42, is_bot=False, first_name="New member")

        self.assertEqual(
            _member(None, fallback_user=user),
            {
                "status": "left",
                "user": {"id": 42, "is_bot": False, "first_name": "New member"},
            },
        )

    def test_existing_member_status_is_preserved(self):
        user = SimpleNamespace(id=42, is_bot=False, first_name="New member")
        member = SimpleNamespace(status="member", user=user)

        converted = _member(member)
        self.assertEqual(converted["status"], "member")
        self.assertEqual(converted["user"]["id"], 42)


if __name__ == "__main__":
    unittest.main()
