import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from management.db import abuse_db, antinsfw_db, moderation


class ModerationStorageTests(unittest.IsolatedAsyncioTestCase):
    async def test_explicit_media_filters_default_off_but_respect_chat_opt_in(self):
        collection = SimpleNamespace(find_one=AsyncMock(return_value=None))
        with patch.object(antinsfw_db, "COLL", collection):
            self.assertFalse(await antinsfw_db.get_antinsfw(-100123))
            self.assertFalse(await antinsfw_db.get_antinsfw_admin(-100123))

        collection.find_one = AsyncMock(
            return_value={"antiporn": True, "antiporn_admin": True}
        )
        with patch.object(antinsfw_db, "COLL", collection):
            self.assertTrue(await antinsfw_db.get_antinsfw(-100123))
            self.assertTrue(await antinsfw_db.get_antinsfw_admin(-100123))

    async def test_abuse_filter_is_on_by_default_but_respects_explicit_opt_out(self):
        collection = SimpleNamespace(find_one=AsyncMock(return_value=None))
        with patch.object(abuse_db, "db", collection):
            self.assertTrue(await abuse_db.is_abuse_enabled(-100123))

        collection.find_one = AsyncMock(return_value={"enabled": False})
        with patch.object(abuse_db, "db", collection):
            self.assertFalse(await abuse_db.is_abuse_enabled(-100123))

    async def test_strikes_use_atomic_per_chat_user_mongo_record(self):
        collection = SimpleNamespace(
            find_one_and_update=AsyncMock(return_value={"count": 2})
        )
        with patch.object(moderation, "strikes_collection", collection):
            count = await moderation.add_strike(-100123, 456, "abuse", 789)

        self.assertEqual(count, 2)
        collection.find_one_and_update.assert_awaited_once()
        query, update = collection.find_one_and_update.await_args.args
        self.assertEqual(query, {"_id": "-100123:456"})
        self.assertEqual(update["$inc"], {"count": 1})
        self.assertEqual(update["$set"]["chat_id"], -100123)
        self.assertEqual(update["$set"]["user_id"], 456)
        self.assertEqual(update["$push"]["reasons"]["$each"], ["abuse"])

    async def test_message_claim_prevents_persistent_duplicate_action(self):
        collection = SimpleNamespace(
            update_one=AsyncMock(
                side_effect=[
                    SimpleNamespace(upserted_id="-100123:789"),
                    SimpleNamespace(upserted_id=None),
                ]
            )
        )
        with patch.object(moderation, "dedupe_collection", collection):
            first = await moderation.claim_message(-100123, 789)
            duplicate = await moderation.claim_message(-100123, 789)

        self.assertTrue(first)
        self.assertFalse(duplicate)
        self.assertEqual(collection.update_one.await_count, 2)


if __name__ == "__main__":
    unittest.main()
