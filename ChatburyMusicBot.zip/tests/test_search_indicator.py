import unittest
import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from management.db import search_indicator
from music.plugins import account


class SearchIndicatorTests(unittest.IsolatedAsyncioTestCase):
    async def test_custom_text_and_sticker_are_persisted_in_cache(self):
        fake_collection = unittest.mock.Mock()
        fake_collection.update_one = AsyncMock()
        with patch.object(search_indicator, "_collection", fake_collection):
            await search_indicator.set_search_indicator("text", "Finding your track")
            self.assertEqual(
                search_indicator.get_search_indicator(),
                {"kind": "text", "value": "Finding your track"},
            )
            await search_indicator.set_search_indicator("sticker", "sticker-file-id")
            self.assertEqual(
                search_indicator.get_search_indicator(),
                {"kind": "sticker", "value": "sticker-file-id"},
            )

    async def test_reset_restores_default_and_rejects_long_value(self):
        fake_collection = unittest.mock.Mock()
        fake_collection.update_one = AsyncMock()
        fake_collection.delete_one = AsyncMock()
        with patch.object(search_indicator, "_collection", fake_collection):
            await search_indicator.set_search_indicator("text", "Custom")
            await search_indicator.reset_search_indicator()
            self.assertEqual(
                search_indicator.get_search_indicator(),
                {"kind": "text", "value": None},
            )
            with self.assertRaises(ValueError):
                await search_indicator.set_search_indicator("text", "x" * 201)

    async def test_owner_custom_emoji_is_saved_and_previewed_with_its_id(self):
        owner_id = 12345
        entity = SimpleNamespace(
            type="custom_emoji", offset=0, length=2, custom_emoji_id="987654321"
        )
        message = SimpleNamespace(
            from_user=SimpleNamespace(id=owner_id),
            text="👋",
            entities=[entity],
            sticker=None,
            reply_text=AsyncMock(),
        )
        account._pending_search_indicator_inputs[owner_id] = (
            time.monotonic() + 60
        )
        saver = AsyncMock()
        try:
            with (
                patch.object(account.settings, "OWNER_ID", owner_id),
                patch("management.db.search_indicator.set_search_indicator", saver),
            ):
                await account.capture_search_indicator_input(None, message)
        finally:
            account._pending_search_indicator_inputs.pop(owner_id, None)
        saved_markup = "<emoji id=987654321>👋</emoji>"
        saver.assert_awaited_once_with("text", saved_markup)
        self.assertIn(saved_markup, message.reply_text.await_args_list[0].args[0])

    async def test_mapped_unicode_emoji_is_converted_to_configured_custom_id(self):
        owner_id = 12346
        message = SimpleNamespace(
            from_user=SimpleNamespace(id=owner_id),
            text="🔥",
            entities=[],
            sticker=None,
            reply_text=AsyncMock(),
        )
        account._pending_search_indicator_inputs[owner_id] = time.monotonic() + 60
        saver = AsyncMock()
        try:
            with (
                patch.object(account.settings, "OWNER_ID", owner_id),
                patch("management.db.search_indicator.set_search_indicator", saver),
            ):
                await account.capture_search_indicator_input(None, message)
        finally:
            account._pending_search_indicator_inputs.pop(owner_id, None)
        saver.assert_awaited_once_with(
            "text", "<emoji id=5859539275372040586>🔥</emoji>"
        )
