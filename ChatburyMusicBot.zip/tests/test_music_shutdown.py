import asyncio
import unittest
from unittest.mock import AsyncMock, patch

import music


class MusicShutdownTests(unittest.IsolatedAsyncioTestCase):
    async def test_expected_task_cancellation_does_not_abort_shutdown(self):
        task = asyncio.create_task(asyncio.sleep(60))

        with (
            patch.object(music, "tasks", [task]),
            patch.object(music.anon, "clients", []),
            patch.object(music.app, "exit", new_callable=AsyncMock),
            patch.object(music.userbot, "exit", new_callable=AsyncMock),
            patch.object(music.db, "close", new_callable=AsyncMock),
        ):
            await music.stop()

        self.assertTrue(task.cancelled())
