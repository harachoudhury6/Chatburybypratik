import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from pyrogram import enums

import config as app_config
from config import settings
import music.core.userbot as userbot_module
from music.plugins import account
from music.plugins.account import parse_music_account_id, set_music_account_command


class MusicAccountConfigTests(unittest.IsolatedAsyncioTestCase):
    def test_music_assistants_use_numeric_saved_session_names(self):
        with tempfile.TemporaryDirectory() as directory:
            with (
                patch.object(userbot_module.config, "MUSIC_SESSION_DIR", directory),
                patch.object(userbot_module, "Client") as client_factory,
            ):
                userbot_module.Userbot()

        names = [call.kwargs["name"] for call in client_factory.call_args_list]
        self.assertEqual(
            names,
            [
                "music_assistant_1",
                "music_assistant_2",
                "music_assistant_3",
            ],
        )

    def test_account_id_parser_accepts_numeric_id_and_reset(self):
        self.assertEqual(parse_music_account_id("123456789"), 123456789)
        self.assertIsNone(parse_music_account_id("reset"))
        self.assertIsNone(parse_music_account_id(" RESET "))

    def test_account_id_parser_rejects_invalid_values(self):
        for value in ("0", "-123", "abc", "1234567890123456"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_music_account_id(value)

    def test_managed_session_name_validation_accepts_legacy_names_safely(self):
        self.assertTrue(account._is_managed_session_name("music_assistant_e"))
        self.assertTrue(account._is_managed_session_name("music_assistant_1"))
        self.assertFalse(account._is_managed_session_name("../music_assistant_e"))
        self.assertFalse(account._is_managed_session_name("management_mtproto"))

    async def test_logout_cleans_orphaned_managed_music_session(self):
        with tempfile.TemporaryDirectory() as directory:
            session_path = Path(directory) / "music_assistant_e.session"
            session_path.touch()
            fake_client = SimpleNamespace(
                connect=AsyncMock(return_value=True),
                log_out=AsyncMock(),
                disconnect=AsyncMock(),
            )
            with (
                patch.object(account.userbot, "sessions_dir", Path(directory)),
                patch.object(account, "Client", return_value=fake_client),
            ):
                count, failed = await account._logout_orphan_music_sessions()

            self.assertEqual(count, 1)
            self.assertFalse(failed)
            self.assertFalse(session_path.exists())
            fake_client.connect.assert_awaited_once()
            fake_client.log_out.assert_awaited_once()

    async def test_failed_orphan_logout_preserves_session_for_retry(self):
        with tempfile.TemporaryDirectory() as directory:
            session_path = Path(directory) / "music_assistant_e.session"
            session_path.touch()
            fake_client = SimpleNamespace(
                connect=AsyncMock(side_effect=ConnectionError("network unavailable")),
                log_out=AsyncMock(),
                disconnect=AsyncMock(),
                is_connected=False,
            )
            with (
                patch.object(account.userbot, "sessions_dir", Path(directory)),
                patch.object(account, "Client", return_value=fake_client),
            ):
                count, failed = await account._logout_orphan_music_sessions()

            self.assertEqual(count, 0)
            self.assertTrue(failed)
            self.assertTrue(session_path.exists())
            fake_client.disconnect.assert_awaited_once()

    def test_runtime_account_id_update_keeps_legacy_config_alias_in_sync(self):
        original_id = settings.MUSIC_ACCOUNT_ID
        try:
            app_config.set_music_account_id(987654321)
            self.assertEqual(settings.MUSIC_ACCOUNT_ID, 987654321)
            self.assertEqual(app_config.MUSIC_ACCOUNT_ID, 987654321)
            with self.assertRaises(ValueError):
                app_config.set_music_account_id(0)
        finally:
            app_config.set_music_account_id(original_id)

    async def test_non_owner_cannot_change_music_account_id(self):
        message = SimpleNamespace(
            from_user=SimpleNamespace(id=settings.OWNER_ID + 1),
            chat=SimpleNamespace(type=enums.ChatType.PRIVATE),
            command=["setmusicaccount", "123456789"],
            reply_text=AsyncMock(),
        )
        await set_music_account_command(None, message)

        message.reply_text.assert_awaited_once()
        self.assertIn("Only the configured bot owner", message.reply_text.await_args.args[0])

    async def test_owner_must_use_private_chat_for_account_id_change(self):
        message = SimpleNamespace(
            from_user=SimpleNamespace(id=settings.OWNER_ID),
            chat=SimpleNamespace(type=enums.ChatType.SUPERGROUP),
            command=["setmusicaccount", "123456789"],
            reply_text=AsyncMock(),
        )
        await set_music_account_command(None, message)

        message.reply_text.assert_awaited_once()
        self.assertIn("private chat", message.reply_text.await_args.args[0])

    async def test_set_id_saves_and_clears_incomplete_local_login_without_logout(self):
        original_id = settings.MUSIC_ACCOUNT_ID
        try:
            with tempfile.TemporaryDirectory() as directory:
                stale_session = Path(directory) / "music_assistant_e.session"
                stale_session.touch()
                message = SimpleNamespace(reply_text=AsyncMock())
                with (
                    patch.object(account.userbot, "sessions_dir", Path(directory)),
                    patch.object(account.userbot, "clients", []),
                    patch.object(account.anon, "clients", []),
                    patch.object(
                        account.userbot, "one", SimpleNamespace(is_connected=False)
                    ),
                    patch.object(
                        account.userbot, "two", SimpleNamespace(is_connected=False)
                    ),
                    patch.object(
                        account.userbot, "three", SimpleNamespace(is_connected=False)
                    ),
                    patch.object(account.config, "SESSION1", None),
                    patch.object(account.config, "SESSION2", None),
                    patch.object(account.config, "SESSION3", None),
                    patch.object(
                        account.db,
                        "get_music_account_id_override",
                        new=AsyncMock(return_value=None),
                    ),
                    patch.object(
                        account.db, "set_music_account_id_override", new=AsyncMock()
                    ) as save_override,
                ):
                    await account._save_music_account_id(message, 987654321)

                save_override.assert_awaited_once_with(987654321)
                self.assertFalse(stale_session.exists())
                response = message.reply_text.await_args.args[0]
                self.assertIn("user ID 987654321 saved", response)
                self.assertIn("does not log those accounts out", response)
                self.assertEqual(settings.MUSIC_ACCOUNT_ID, 987654321)
        finally:
            app_config.set_music_account_id(original_id)

    async def test_remove_id_restores_default_without_requiring_logout(self):
        original_id = settings.MUSIC_ACCOUNT_ID
        try:
            app_config.set_music_account_id(987654321)
            message = SimpleNamespace(reply_text=AsyncMock())
            with tempfile.TemporaryDirectory() as directory:
                with (
                    patch.object(account.userbot, "clients", []),
                    patch.object(account.anon, "clients", []),
                    patch.object(
                        account.userbot, "one", SimpleNamespace(is_connected=False)
                    ),
                    patch.object(
                        account.userbot, "two", SimpleNamespace(is_connected=False)
                    ),
                    patch.object(
                        account.userbot, "three", SimpleNamespace(is_connected=False)
                    ),
                    patch.object(account.config, "SESSION1", None),
                    patch.object(account.config, "SESSION2", None),
                    patch.object(account.config, "SESSION3", None),
                    patch.object(
                        account.db,
                        "get_music_account_id_override",
                        new=AsyncMock(return_value=987654321),
                    ),
                    patch.object(
                        account.db, "clear_music_account_id_override", new=AsyncMock()
                    ) as clear_override,
                    patch.object(account.userbot, "sessions_dir", Path(directory)),
                ):
                    await account._save_music_account_id(message, None)

            clear_override.assert_awaited_once()
            self.assertEqual(
                settings.MUSIC_ACCOUNT_ID, settings.DEFAULT_MUSIC_ACCOUNT_ID
            )
            self.assertIn(
                f"configured default ({settings.DEFAULT_MUSIC_ACCOUNT_ID})",
                message.reply_text.await_args.args[0],
            )
        finally:
            app_config.set_music_account_id(original_id)


if __name__ == "__main__":
    unittest.main()
