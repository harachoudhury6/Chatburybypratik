import asyncio
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from management.helpers.plain_text import (
    _patch_sender_method,
    _remap_entities,
    _sanitize_bot_commands,
    _sanitize_reply_markup,
    format_bot_text,
    format_button_label,
    strip_emoji_text,
)
from management.plugins.broadcast import _copy_to_chat, _remember_source_message
from pyrogram.enums import ButtonStyle
from pyrogram.types import (
    BotCommand as PyrogramBotCommand,
    InlineKeyboardButton as PyrogramButton,
    InlineKeyboardMarkup as PyrogramMarkup,
)
from telegram import (
    BotCommand as TelegramBotCommand,
    InlineKeyboardButton as TelegramButton,
    InlineKeyboardMarkup as TelegramMarkup,
)


class PlainTextTests(unittest.TestCase):
    def test_removes_emoji_sequences_but_keeps_words_and_numbers(self):
        cleaned, _ = strip_emoji_text("⚠️ Warning 1️⃣/3 — नमस्ते 🎵")
        self.assertEqual(cleaned, "Warning 1/3 — नमस्ते")
        self.assertNotRegex(cleaned, r"[\U0001F300-\U0001FAFF]")

    def test_removes_zwj_flags_skin_tones_and_keycaps(self):
        cleaned, _ = strip_emoji_text("👨‍👩‍👧‍👦 🇮🇳 👍🏽 #️⃣ 42")
        self.assertEqual(cleaned, "# 42")

    def test_removes_custom_emoji_markup_without_damaging_surrounding_text(self):
        cleaned, _ = strip_emoji_text(
            'Start <emoji id=123456789>🎵</emoji> end '
            '<tg-emoji emoji-id="123456789">✨</tg-emoji>'
        )
        self.assertEqual(cleaned, "Start end")

    def test_remaps_utf16_entity_offsets_when_emoji_is_removed(self):
        class Entity:
            def __init__(self, offset, length):
                self.offset = offset
                self.length = length

        text = "A 🎵 bold"
        cleaned, offsets = strip_emoji_text(text)
        entity = Entity(offset=5, length=4)  # UTF-16 offsets for "bold"
        remapped, = _remap_entities([entity], offsets)
        self.assertEqual(cleaned, "A bold")
        self.assertEqual((remapped.offset, remapped.length), (2, 4))

    def test_styles_text_but_preserves_html_commands_usernames_and_links(self):
        text = "Hello 🎵 /help @PrikshaMusicBot https://t.me/help <b>OK</b>"
        styled, _ = format_bot_text(text)
        self.assertNotRegex(styled, r"[\U0001F300-\U0001FAFF]")
        self.assertIn("ʜᴇʟʟᴏ", styled)
        self.assertIn("/help", styled)
        self.assertIn("@PrikshaMusicBot", styled)
        self.assertIn("https://t.me/help", styled)
        self.assertIn("<b>ᴏᴋ</b>", styled)
        self.assertIn("01:25", format_bot_text("01:25")[0])

    def test_remaps_entity_offsets_after_emoji_removal_and_font_expansion(self):
        class Entity:
            def __init__(self, offset, length):
                self.offset = offset
                self.length = length

        text = "A 🎵 bold"
        styled, offsets = format_bot_text(text)
        entity = Entity(offset=5, length=4)
        remapped, = _remap_entities([entity], offsets)
        self.assertEqual(styled, "ᴀ ʙᴏʟᴅ")
        self.assertEqual((remapped.offset, remapped.length), (2, 4))

    def test_uppercase_and_lowercase_use_the_same_small_caps_style(self):
        self.assertEqual(format_bot_text("HELP AND COMMAND")[0], "ʜᴇʟᴘ ᴀɴᴅ ᴄᴏᴍᴍᴀɴᴅ")
        self.assertEqual(format_bot_text("Help and command")[0], "ʜᴇʟᴘ ᴀɴᴅ ᴄᴏᴍᴍᴀɴᴅ")

    def test_rec_button_keeps_its_requested_dot_and_uses_the_same_font(self):
        label = format_button_label("• Rec")
        self.assertTrue(label.startswith("• "))
        self.assertEqual(label[2:], format_bot_text("Rec")[0])

        markup = PyrogramMarkup(
            [[PyrogramButton("• Rec", callback_data="controls rec -100123")]]
        )
        styled = _sanitize_reply_markup(markup)
        self.assertTrue(styled.inline_keyboard[0][0].text.startswith("• "))
        self.assertEqual(
            styled.inline_keyboard[0][0].callback_data,
            "controls rec -100123",
        )

    def test_sender_filter_styles_text_and_caption(self):
        class FakeSender:
            async def send_message(self, text, reply_markup=None, entities=None):
                return text, reply_markup, entities

        _patch_sender_method(FakeSender, "send_message", (("text", "entities"),))

        async def run():
            markup = object()
            text, returned_markup, _ = await FakeSender().send_message(
                "Hello 🎵", reply_markup=markup
            )
            self.assertEqual(text, format_bot_text("Hello 🎵")[0])
            self.assertIs(returned_markup, markup)

        asyncio.run(run())

    def test_keyboards_are_styled_without_changing_actions_or_custom_icon_fields(self):
        pyro_markup = PyrogramMarkup(
            [[
                PyrogramButton(
                    "🔄 Help",
                    callback_data="help_123",
                    icon_custom_emoji_id="123456789",
                    style=ButtonStyle.SUCCESS,
                )
            ]]
        )
        telegram_markup = TelegramMarkup(
            [[
                TelegramButton(
                    "🎵 Open",
                    url="https://t.me/PrikshaMusicBot",
                    icon_custom_emoji_id="123456789",
                )
            ]]
        )

        for original in (pyro_markup, telegram_markup):
            with self.subTest(markup=type(original).__module__):
                styled = _sanitize_reply_markup(original)
                before = original.inline_keyboard[0][0]
                after = styled.inline_keyboard[0][0]
                self.assertNotEqual(after.text, before.text)
                self.assertEqual(strip_emoji_text(after.text)[0], after.text)
                self.assertIsNone(after.icon_custom_emoji_id)
                if before.callback_data:
                    self.assertEqual(after.callback_data, before.callback_data)
                if before.url:
                    self.assertEqual(after.url, before.url)
                if hasattr(before, "style"):
                    self.assertEqual(after.style, before.style)

    def test_help_keyboard_keeps_its_callback_routes_after_styling(self):
        from management.helpers import misc

        async def run():
            with patch.object(misc, "MODULE", {"music": "Music help"}):
                misc._MODULE_SORTED = None
                misc._MODULE_BUTTONS_CACHE.clear()
                misc.help_keyboard_data.cache_clear()
                try:
                    original = await misc.get_help_button(
                        None, SimpleNamespace(id=92837465)
                    )
                    styled = _sanitize_reply_markup(original)
                    original_buttons = [
                        button for row in original.inline_keyboard for button in row
                    ]
                    styled_buttons = [
                        button for row in styled.inline_keyboard for button in row
                    ]
                    self.assertTrue(any(
                        button.callback_data
                        and button.callback_data.startswith("help_music_")
                        for button in styled_buttons
                    ))
                    self.assertEqual(
                        [button.callback_data for button in original_buttons],
                        [button.callback_data for button in styled_buttons],
                    )
                    for button in styled_buttons:
                        self.assertEqual(strip_emoji_text(button.text)[0], button.text)
                        self.assertIsNone(button.icon_custom_emoji_id)
                finally:
                    misc._MODULE_SORTED = None
                    misc._MODULE_BUTTONS_CACHE.clear()
                    misc.help_keyboard_data.cache_clear()

        asyncio.run(run())

    def test_command_descriptions_are_styled_but_command_names_are_unchanged(self):
        for command in (
            PyrogramBotCommand("help", "Open help 🎵"),
            TelegramBotCommand("help", "Open help 🎵"),
        ):
            styled, = _sanitize_bot_commands([command])
            self.assertEqual(styled.command, "help")
            self.assertEqual(strip_emoji_text(styled.description)[0], styled.description)
            self.assertNotEqual(styled.description, command.description)

    def test_media_group_caption_is_styled_without_changing_the_media_object(self):
        class InputMedia:
            def __init__(self, caption):
                self.caption = caption
                self.caption_entities = None

        class FakeSender:
            async def send_media_group(self, media, reply_markup=None):
                return media, reply_markup

        _patch_sender_method(FakeSender, "send_media_group", ())

        async def run():
            original = InputMedia("Cover 🎵, now playing")
            markup = object()
            media, returned_markup = await FakeSender().send_media_group(
                [original], reply_markup=markup
            )
            self.assertEqual(
                media[0].caption, format_bot_text("Cover 🎵, now playing")[0]
            )
            self.assertEqual(original.caption, "Cover 🎵, now playing")
            self.assertIs(returned_markup, markup)

        asyncio.run(run())

    def test_broadcast_copy_preserves_original_text_and_caption_entities(self):
        class FakeClient:
            def __init__(self):
                self.sent = []

            async def send_message(self, **kwargs):
                self.sent.append(("text", kwargs))
                return kwargs

            async def copy_message(self, **kwargs):
                self.sent.append(("copy", kwargs))
                return kwargs

        async def run():
            client = FakeClient()
            markup = object()
            flow = {}
            _remember_source_message(
                flow,
                SimpleNamespace(
                    chat=SimpleNamespace(id=100),
                    id=7,
                    text="Hello 🎵!",
                    caption=None,
                ),
            )
            await _copy_to_chat(client, 200, flow, markup)
            self.assertEqual(client.sent[-1][0], "copy")
            self.assertEqual(
                client.sent[-1][1],
                {
                    "chat_id": 200,
                    "from_chat_id": 100,
                    "message_id": 7,
                    "reply_markup": markup,
                },
            )

            _remember_source_message(
                flow,
                SimpleNamespace(
                    chat=SimpleNamespace(id=100),
                    id=8,
                    text=None,
                    caption="New track 🎶",
                ),
            )
            await _copy_to_chat(client, 200, flow, markup)
            self.assertEqual(client.sent[-1][0], "copy")
            self.assertEqual(client.sent[-1][1]["message_id"], 8)
            self.assertIs(client.sent[-1][1]["reply_markup"], markup)

        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
