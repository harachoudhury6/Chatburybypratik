import unittest

from management.helpers.moderation_rules import (
    classify_selling,
    find_abusive_term,
    spam_signals,
    valid_telegram_url,
)


class ModerationRuleTests(unittest.TestCase):
    def test_hinglish_and_evasion(self):
        for text in (
            "MADARCHOD",
            "maa ke lode",
            "behen ke laude",
            "bkc",
            "bc",
            "fuuuuuck",
            "f u c k",
            "m@darch0d",
        ):
            with self.subTest(text=text):
                self.assertIsNotNone(find_abusive_term(text))

    def test_devanagari_and_odia(self):
        for text in ("मादरचोद", "ମାଇଚୋଦ", "ଭୋକାଚୋଦା"):
            with self.subTest(text=text):
                self.assertIsNotNone(find_abusive_term(text))

    def test_bengali_russian_and_other_language_lexicons(self):
        for text in (
            "মাদারচোদ",
            "madarachoda",
            "блядь",
            "blyad",
            "M.K.C.",
            "Mkc",
            "MKC!!!",
            "hijueputa",
            "arschloch",
            "ابن القحبة",
        ):
            with self.subTest(language_sample=text):
                self.assertIsNotNone(find_abusive_term(text))

    def test_spacing_punctuation_digits_and_repeated_letters(self):
        for text in ("m k c", "m.a.d.a.r.c.h.o.d", "m@d4rch0d", "fuuuuuck"):
            with self.subTest(obfuscated=text):
                self.assertIsNotNone(find_abusive_term(text))

    def test_harmless_context(self):
        for text in (
            "This service is good",
            "Sex education is important",
            "The classic is on the table",
            "I like Russian music",
            "Please discuss the word in class",
        ):
            with self.subTest(text=text):
                self.assertIsNone(find_abusive_term(text))

    def test_selling_and_spam_confidence(self):
        self.assertTrue(classify_selling("Selling my iPhone for ₹20000, DM me")[0])
        self.assertFalse(classify_selling("I bought a phone yesterday")[0])
        self.assertIn(
            "suspicious_link_promotion",
            spam_signals("Free money guaranteed https://example.invalid"),
        )
        self.assertIn(
            "excessive_mentions",
            spam_signals("@one @two @three", mention_limit=2),
        )
        self.assertEqual(spam_signals("I like this group"), [])

    def test_selling_url_validation(self):
        self.assertTrue(valid_telegram_url("https://t.me/NocturnalGC"))
        self.assertFalse(valid_telegram_url("http://t.me/NocturnalGC"))
        self.assertFalse(valid_telegram_url("https://example.invalid/group"))


if __name__ == "__main__":
    unittest.main()
