import unittest

from music.helpers._premium_emoji import (
    PREMIUM_EMOJI_IDS,
    premium_emoji_markup,
    premium_emoji_markup_from_entities,
)


class PremiumEmojiTests(unittest.TestCase):
    def test_custom_emoji_markup_uses_the_supplied_ids(self):
        for emoji, emoji_id in PREMIUM_EMOJI_IDS.items():
            with self.subTest(emoji=emoji):
                self.assertEqual(
                    premium_emoji_markup(emoji),
                    f"<emoji id={emoji_id}>{emoji}</emoji>",
                )

    def test_existing_custom_emoji_tags_are_not_nested(self):
        existing = "<emoji id=123>✅</emoji>"
        self.assertEqual(premium_emoji_markup(existing), existing)

    def test_multiple_emojis_and_unmapped_symbols_are_preserved(self):
        result = premium_emoji_markup("🎵 Play ✅ — ▸▸I")
        self.assertIn("<emoji id=5891249688933305846>🎵</emoji>", result)
        self.assertIn("<emoji id=5823396554345549784>✅</emoji>", result)
        self.assertIn("▸▸I", result)

    def test_owner_custom_emoji_id_is_preserved_and_plain_input_is_escaped(self):
        from types import SimpleNamespace

        entity = SimpleNamespace(
            type="custom_emoji",
            offset=0,
            length=2,
            custom_emoji_id="987654321",
        )
        self.assertEqual(
            premium_emoji_markup_from_entities("👋", [entity]),
            "<emoji id=987654321>👋</emoji>",
        )
        self.assertEqual(
            premium_emoji_markup_from_entities("<hello>", []),
            "&lt;hello&gt;",
        )
