import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from pyrogram import StopPropagation, enums

from music.core.mongo import MongoDB
from music.helpers._play import _music_access_allowed, _unauthorized_reply
from music.plugins import account
from music.plugins.account import (
    _OWNER_MUSIC_ACCOUNT_INPUT_GROUP,
    _OWNER_MUSIC_ONLY_CHAT_INPUT_GROUP,
    _OWNER_PUBLIC_USERNAME_INPUT_GROUP,
    _OWNER_SEARCH_INDICATOR_INPUT_GROUP,
    _pending_music_only_chat_inputs,
    capture_music_only_chat_id_input,
    parse_music_only_chat_id,
)
from music.plugins.auth import _auth
from music.plugins.music_only_mode import (
    enforce_music_only_callbacks,
    enforce_music_only_commands,
)
from management import command_menu


class MusicAuthorizationTests(unittest.IsolatedAsyncioTestCase):
    def test_owner_text_input_handlers_use_distinct_dispatch_groups(self):
        groups = {
            _OWNER_PUBLIC_USERNAME_INPUT_GROUP,
            _OWNER_MUSIC_ACCOUNT_INPUT_GROUP,
            _OWNER_SEARCH_INDICATOR_INPUT_GROUP,
            _OWNER_MUSIC_ONLY_CHAT_INPUT_GROUP,
        }
        self.assertEqual(len(groups), 4)

    async def test_music_only_group_id_input_is_saved_and_confirmed(self):
        owner_id = account.settings.OWNER_ID
        target_id = -1001234567890
        _pending_music_only_chat_inputs[owner_id] = account.time.monotonic() + 60
        target = SimpleNamespace(type=enums.ChatType.SUPERGROUP, title="Test Group")
        message = SimpleNamespace(
            from_user=SimpleNamespace(id=owner_id),
            text=str(target_id),
            reply_text=AsyncMock(),
        )

        try:
            with (
                patch.object(account.app, "get_chat", new=AsyncMock(return_value=target)),
                patch.object(account.db, "add_music_only_chat", new=AsyncMock()) as save,
                patch.object(account, "_delete", new=AsyncMock()),
                patch(
                    "management.command_menu.set_music_only_chat_commands",
                    new=AsyncMock(),
                ),
            ):
                await capture_music_only_chat_id_input(None, message)
        finally:
            _pending_music_only_chat_inputs.pop(owner_id, None)

        save.assert_awaited_once_with(target_id)
        message.reply_text.assert_awaited_once()
        self.assertIn("Music-only mode enabled", message.reply_text.await_args.args[0])

    def test_music_only_group_id_parser_requires_negative_numeric_ids(self):
        self.assertEqual(parse_music_only_chat_id("-1001234567890"), -1001234567890)
        for invalid in ("123456789", "0", "-1x", "abc", "١٢٣", "-" + "1" * 16):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                parse_music_only_chat_id(invalid)

    async def test_group_play_access_still_uses_existing_group_auth(self):
        user_id = 123456789
        with (
            patch("music.helpers._play.db.is_auth", new=AsyncMock(return_value=True)),
            patch("music.helpers._play.app.sudoers", []),
        ):
            self.assertTrue(await _music_access_allowed(-100123, user_id))

    async def test_music_only_gate_allows_music_and_blocks_other_commands(self):
        message = SimpleNamespace(
            chat=SimpleNamespace(id=-100123),
            text="/ban @member",
            reply_text=AsyncMock(),
        )
        with patch(
            "music.plugins.music_only_mode.db.is_music_only_chat",
            new=AsyncMock(return_value=True),
        ):
            with self.assertRaises(StopPropagation):
                await enforce_music_only_commands(None, message)
        message.reply_text.assert_not_awaited()
        message.text = "/play song"
        with patch(
            "music.plugins.music_only_mode.db.is_music_only_chat",
            new=AsyncMock(return_value=True),
        ):
            self.assertIsNone(await enforce_music_only_commands(None, message))

    async def test_music_only_gate_blocks_old_management_buttons_but_keeps_player_controls(self):
        callback = SimpleNamespace(
            message=SimpleNamespace(
                chat=SimpleNamespace(id=-100123, type=enums.ChatType.SUPERGROUP)
            ),
            data="groupdash:section:-100123:welcome",
            answer=AsyncMock(),
        )
        with patch(
            "music.plugins.music_only_mode.db.is_music_only_chat",
            new=AsyncMock(return_value=True),
        ):
            with self.assertRaises(StopPropagation):
                await enforce_music_only_callbacks(None, callback)
        callback.answer.assert_awaited_once()

        callback.data = "controls pause -100123"
        with patch(
            "music.plugins.music_only_mode.db.is_music_only_chat",
            new=AsyncMock(return_value=True),
        ):
            self.assertIsNone(await enforce_music_only_callbacks(None, callback))

    async def test_music_only_chat_menu_contains_music_commands_not_management(self):
        client = SimpleNamespace(
            set_bot_commands=AsyncMock(),
            delete_bot_commands=AsyncMock(),
        )
        await command_menu.set_music_only_chat_commands(client, -100123)
        commands, kwargs = client.set_bot_commands.await_args.args[0], client.set_bot_commands.await_args.kwargs
        names = {command.command for command in commands}
        self.assertIn("play", names)
        self.assertIn("queue", names)
        self.assertIn("auth", names)
        self.assertIn("unauth", names)
        self.assertNotIn("ban", names)
        self.assertEqual(kwargs["scope"].chat_id, -100123)
        await command_menu.restore_chat_commands(client, -100123)
        client.delete_bot_commands.assert_awaited_once()

    async def test_music_only_group_ids_are_loaded_and_changed_in_persistent_config(self):
        config = SimpleNamespace(
            find_one=AsyncMock(return_value={"chat_ids": [-1001234567890, "bad", 123]}),
            update_one=AsyncMock(),
        )
        store = MongoDB.__new__(MongoDB)
        store.bot_configdb = config
        store._music_only_chat_ids = None

        self.assertEqual(await store.get_music_only_chat_ids(), {-1001234567890})
        self.assertTrue(await store.is_music_only_chat(-1001234567890))
        await store.add_music_only_chat(-1009876543210)
        await store.remove_music_only_chat(-1001234567890)

        self.assertEqual(store._music_only_chat_ids, {-1009876543210})
        self.assertEqual(config.update_one.await_count, 2)

    async def test_music_only_mode_does_not_pass_group_admin_auth_check(self):
        message = SimpleNamespace(
            from_user=SimpleNamespace(id=123456789),
            chat=SimpleNamespace(id=-100123),
            command=["auth", "456789"],
            lang={},
            reply_text=AsyncMock(),
        )
        member = SimpleNamespace(status=enums.ChatMemberStatus.MEMBER)
        with (
            patch("music.core.lang.db.get_lang", new=AsyncMock(return_value="en")),
            patch("music.plugins.auth.app.get_chat_member", new=AsyncMock(return_value=member)),
            patch("music.plugins.auth.db.add_auth", new=AsyncMock()) as add_auth,
        ):
            await _auth(None, message)
        add_auth.assert_not_awaited()
        self.assertIn("Only this group's owner", message.reply_text.await_args.args[0])

    async def test_unauthorized_reply_offers_current_owner_and_admin_contacts(self):
        owner = SimpleNamespace(
            user=SimpleNamespace(id=10, username="groupowner", is_bot=False),
            status=enums.ChatMemberStatus.OWNER,
        )
        admin = SimpleNamespace(
            user=SimpleNamespace(id=11, username="activeadmin", is_bot=False),
            status=enums.ChatMemberStatus.ADMINISTRATOR,
        )

        async def iter_admins(*_args, **_kwargs):
            yield owner
            yield admin

        message = SimpleNamespace(
            chat=SimpleNamespace(id=-100123),
            reply_text=AsyncMock(),
        )
        with patch("music.helpers._play.app.get_chat_members", side_effect=iter_admins):
            await _unauthorized_reply(message)

        sent_text = message.reply_text.await_args.args[0]
        kwargs = message.reply_text.await_args.kwargs
        self.assertIn("not authorized", sent_text)
        buttons = kwargs["reply_markup"].inline_keyboard[0]
        self.assertEqual(
            [button.url for button in buttons],
            ["https://t.me/groupowner", "https://t.me/activeadmin"],
        )

    def test_group_command_menu_includes_admin_reload(self):
        self.assertIn("reload", command_menu._GROUP_NAMES)


if __name__ == "__main__":
    unittest.main()
