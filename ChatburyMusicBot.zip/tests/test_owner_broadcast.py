import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from pyrogram.enums import ButtonStyle, ChatMemberStatus, ChatType

from management.command_menu import build_owner_admin_keyboard
from management.plugins import broadcast


class FakeClient:
    def __init__(self):
        self.sent_messages = []
        self.copied = []

    async def send_message(self, chat_id, text, **kwargs):
        self.sent_messages.append((chat_id, text, kwargs))
        return SimpleNamespace(id=71)

    async def copy_message(self, **kwargs):
        self.copied.append(kwargs)
        return SimpleNamespace(message_id=72)

    async def get_me(self):
        return SimpleNamespace(id=900)

    async def get_chat(self, chat_id):
        return SimpleNamespace(
            type=ChatType.CHANNEL if chat_id == -1003 else ChatType.SUPERGROUP
        )

    async def get_chat_member(self, chat_id, user_id):
        if chat_id in (-1001, -1003):
            return SimpleNamespace(
                status=ChatMemberStatus.ADMINISTRATOR,
                privileges=SimpleNamespace(can_post_messages=True),
            )
        return SimpleNamespace(status=ChatMemberStatus.MEMBER)


class OwnerBroadcastTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        if not broadcast.OWNER_ID:
            self.skipTest("Owner ID is not configured in this test environment.")
        broadcast._FLOWS.clear()

    def test_only_https_links_are_accepted(self):
        self.assertTrue(broadcast._valid_https_url("https://t.me/NocturnalGC"))
        self.assertFalse(broadcast._valid_https_url("http://example.com"))
        self.assertFalse(broadcast._valid_https_url("https://"))
        self.assertFalse(broadcast._valid_https_url("https://example.com/a b"))

    def test_two_or_three_url_buttons_use_requested_styles(self):
        keyboard = broadcast._button_keyboard(
            [
                {"text": "One", "url": "https://example.com/1", "style": "primary"},
                {"text": "Two", "url": "https://example.com/2", "style": "success"},
                {"text": "Three", "url": "https://example.com/3", "style": "danger"},
            ]
        )
        self.assertEqual([len(row) for row in keyboard.inline_keyboard], [2, 1])
        self.assertEqual(
            [button.style for row in keyboard.inline_keyboard for button in row],
            [ButtonStyle.PRIMARY, ButtonStyle.SUCCESS, ButtonStyle.DANGER],
        )

    def test_one_button_is_supported(self):
        keyboard = broadcast._button_keyboard(
            [{"text": "Join", "url": "https://example.com", "style": "success"}]
        )
        self.assertEqual(len(keyboard.inline_keyboard), 1)
        self.assertEqual(len(keyboard.inline_keyboard[0]), 1)

    def test_owner_panel_exposes_broadcast_only_as_an_owner_callback(self):
        keyboard = build_owner_admin_keyboard()
        buttons = [button for row in keyboard.inline_keyboard for button in row]
        self.assertIn("owner_admin:broadcast", [button.callback_data for button in buttons])
        broadcast_button = next(
            button for button in buttons if button.callback_data == "owner_admin:broadcast"
        )
        self.assertEqual(broadcast_button.style, ButtonStyle.SUCCESS)

    async def test_owner_start_only_prompts_and_does_not_send_broadcast(self):
        client = FakeClient()
        await broadcast.begin_owner_broadcast(client, broadcast.OWNER_ID, mode="all")
        self.assertEqual(broadcast._FLOWS[broadcast.OWNER_ID]["step"], "message")
        self.assertEqual(len(client.sent_messages), 1)
        self.assertEqual(client.copied, [])

    async def test_preview_copy_preserves_the_original_message_entities(self):
        client = FakeClient()
        flow = {
            "source_chat_id": broadcast.OWNER_ID,
            "source_message_id": 55,
            "source_text": "Premium emoji sample",
            "source_caption": None,
        }
        await broadcast._copy_to_chat(client, broadcast.OWNER_ID, flow, "buttons")
        self.assertEqual(client.sent_messages, [])
        self.assertEqual(
            client.copied,
            [{
                "chat_id": broadcast.OWNER_ID,
                "from_chat_id": broadcast.OWNER_ID,
                "message_id": 55,
                "reply_markup": "buttons",
            }],
        )

    async def test_other_user_cannot_start_owner_flow(self):
        client = FakeClient()
        await broadcast.begin_owner_broadcast(client, broadcast.OWNER_ID + 1, mode="all")
        self.assertEqual(client.sent_messages, [])
        self.assertEqual(broadcast._FLOWS, {})

    async def test_recipients_include_users_and_verified_postable_chats(self):
        client = FakeClient()
        active_users = [broadcast.OWNER_ID, 101, 102]
        tracked_chats = [-1001, -1002, -1003]
        with (
            patch.object(
                broadcast, "get_all_active_users", new=AsyncMock(return_value=active_users)
            ),
            patch.object(
                broadcast, "get_all_chats", new=AsyncMock(return_value=tracked_chats)
            ),
        ):
            targets, uncertain = await broadcast._get_targets(client, "all")
        self.assertEqual(
            set(targets),
            {(101, "user"), (102, "user"), (-1001, "chat"), (-1003, "chat")},
        )
        self.assertEqual(uncertain, 0)

    async def test_button_count_prompt_offers_one_to_three(self):
        client = FakeClient()
        flow = broadcast._new_flow("all")
        await broadcast._prompt_button_count(client, broadcast.OWNER_ID, flow)
        markup = client.sent_messages[-1][2]["reply_markup"]
        values = {
            button.callback_data
            for row in markup.inline_keyboard
            for button in row
        }
        self.assertEqual(
            values,
            {
                "owner_broadcast:count_1",
                "owner_broadcast:count_2",
                "owner_broadcast:count_3",
            },
        )

    async def test_existing_channel_is_registered_when_a_post_arrives(self):
        message = SimpleNamespace(
            chat=SimpleNamespace(id=-1005, username="sample_channel")
        )
        with patch.object(broadcast, "add_chat", new=AsyncMock()) as add_chat:
            await broadcast.track_existing_broadcast_channel(None, message)
        add_chat.assert_awaited_once_with(-1005, "sample_channel")

    async def test_stop_request_is_owner_only_and_requires_active_broadcast(self):
        self.assertFalse(broadcast.request_stop_broadcast(broadcast.OWNER_ID))
        async with broadcast._BROADCAST_LOCK:
            self.assertTrue(broadcast.request_stop_broadcast(broadcast.OWNER_ID))
            self.assertFalse(
                broadcast.request_stop_broadcast(broadcast.OWNER_ID + 1)
            )
            self.assertTrue(broadcast._ACTIVE_CANCEL)
        broadcast._ACTIVE_CANCEL = False


if __name__ == "__main__":
    unittest.main()
