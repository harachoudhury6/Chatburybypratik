from io import BytesIO
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image

from music.helpers._queue_cards import queue_cards


class QueuedTrackCardTests(unittest.IsolatedAsyncioTestCase):
    def _items(self, thumbnail=None):
        current = SimpleNamespace(
            title="Current song",
            artist="Current artist",
            duration="03:15",
            user="DJ",
            thumbnail=None,
        )
        queued = SimpleNamespace(
            id="queued-track",
            title="Next song",
            artist="Next artist",
            duration="04:20",
            user="Listener",
            thumbnail=thumbnail,
        )
        return current, queued

    async def test_queued_track_card_falls_back_when_artwork_is_missing(self):
        current, queued = self._items()
        card = await queue_cards.render_queued(
            queued, position=1, current_item=current
        )

        self.assertEqual(card.name, "nocturnal-queued-1.jpg")
        with Image.open(card) as image:
            self.assertEqual(image.size, (1280, 720))
            self.assertEqual(image.format, "JPEG")

    async def test_queued_track_card_uses_downloaded_thumbnail(self):
        thumbnail = BytesIO()
        Image.new("RGB", (640, 360), (112, 45, 182)).save(
            thumbnail, format="JPEG"
        )
        image_data = thumbnail.getvalue()

        class FakeResponse:
            content_length = len(image_data)

            async def __aenter__(self):
                return self

            async def __aexit__(self, *_):
                return False

            def raise_for_status(self):
                return None

            async def read(self):
                return image_data

        class FakeSession:
            def __init__(self, **_):
                pass

            async def __aenter__(self):
                return self

            async def __aexit__(self, *_):
                return False

            def get(self, _url):
                return FakeResponse()

        current, queued = self._items("https://example.test/thumbnail.jpg")
        with patch(
            "music.helpers._queue_cards.aiohttp.ClientSession", FakeSession
        ):
            card = await queue_cards.render_queued(
                queued, position=2, current_item=current
            )

        self.assertEqual(card.name, "nocturnal-queued-2.jpg")
        with Image.open(card) as image:
            self.assertEqual(image.size, (1280, 720))
