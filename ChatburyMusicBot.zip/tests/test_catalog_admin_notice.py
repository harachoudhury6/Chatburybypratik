import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from management.catalog_notice import send_bot_admin_catalog_notice


class CatalogAdminNoticeTests(unittest.TestCase):
    def make_update(
        self, *, new_status="administrator", old_status="member", date=12345, chat_id=-100555
    ):
        old = SimpleNamespace(status=old_status, user=SimpleNamespace(id=900))
        new = SimpleNamespace(
            status=new_status,
            user=SimpleNamespace(id=900),
            can_delete_messages=True,
            can_invite_users=True,
            can_promote_members=False,
        )
        membership = SimpleNamespace(
            old_chat_member=old,
            new_chat_member=new,
            date=date,
        )
        return SimpleNamespace(
            my_chat_member=membership,
            effective_chat=SimpleNamespace(
                id=chat_id, type="supergroup", title="Live <group>"
            ),
            effective_user=SimpleNamespace(full_name="Group owner"),
        )

    def make_bot(self):
        bot = SimpleNamespace()
        bot.get_chat = AsyncMock(
            return_value=SimpleNamespace(
                title="Live <group>",
                photo=SimpleNamespace(big_file_id="group-photo-file"),
            )
        )
        bot.get_me = AsyncMock(return_value=SimpleNamespace(username="IllusionMusicBot"))
        bot.send_photo = AsyncMock()
        bot.send_message = AsyncMock()
        return bot

    def test_promotion_posts_group_photo_name_link_and_granted_rights(self):
        bot = self.make_bot()
        sent = asyncio.run(send_bot_admin_catalog_notice(bot, self.make_update()))

        self.assertTrue(sent)
        bot.send_photo.assert_awaited_once()
        args = bot.send_photo.await_args.kwargs
        self.assertEqual(args["photo"], "group-photo-file")
        self.assertEqual(args["chat_id"], -1003705704898)
        self.assertIn("Live &lt;group&gt;", args["caption"])
        self.assertIn("https://t.me/IllusionMusicBot", args["caption"])
        self.assertIn("Delete messages", args["caption"])
        self.assertIn("Invite users", args["caption"])
        self.assertNotIn("Promote members", args["caption"])

    def test_existing_admin_and_demotion_do_not_post(self):
        bot = self.make_bot()
        existing_admin = self.make_update(old_status="administrator", date=12346)
        demotion = self.make_update(new_status="member", date=12347)

        self.assertFalse(asyncio.run(send_bot_admin_catalog_notice(bot, existing_admin)))
        self.assertFalse(asyncio.run(send_bot_admin_catalog_notice(bot, demotion)))
        bot.send_photo.assert_not_awaited()
        bot.send_message.assert_not_awaited()

    def test_missing_group_avatar_sends_text_card(self):
        bot = self.make_bot()
        bot.get_chat.return_value = SimpleNamespace(title="Group", photo=None)

        self.assertTrue(
            asyncio.run(
                send_bot_admin_catalog_notice(
                    bot, self.make_update(date=12348, chat_id=-100556)
                )
            )
        )
        bot.send_message.assert_awaited_once()
        self.assertIn("Group ID", bot.send_message.await_args.kwargs["text"])
