import asyncio
import inspect
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

import music.plugins.callbacks as callbacks


class QueuePlayNowTests(unittest.TestCase):
    def test_play_now_starts_existing_stream_then_deletes_queue_and_old_player_posts(self):
        async def run():
            events = []
            current = SimpleNamespace(message_id=88)
            queued = SimpleNamespace(
                id="track-2",
                file_path=None,
                stream_url="https://audio.example/track",
                video=False,
                url="https://soundcloud.com/artist/track",
                message_id=0,
            )
            sent_status = SimpleNamespace(id=99)
            query = SimpleNamespace(
                data="controls force -100555 track-2",
                from_user=SimpleNamespace(id=7, mention="DJ"),
                lang={
                    "processing": "Processing",
                    "play_expired": "Expired",
                    "play_next": "Starting",
                },
                message=SimpleNamespace(id=22),
                answer=AsyncMock(),
                edit_message_text=AsyncMock(),
            )
            play_media = AsyncMock(
                side_effect=lambda *args, **kwargs: events.append("play") or True
            )
            delete_messages = AsyncMock(
                side_effect=lambda **kwargs: events.append("delete")
            )
            send_message = AsyncMock(return_value=sent_status)

            with (
                patch.object(callbacks.app, "sudoers", {7}),
                patch.object(callbacks.db, "get_call", new=AsyncMock(return_value=True)),
                patch.object(
                    callbacks.queue, "check_item", return_value=(1, queued)
                ),
                patch.object(
                    callbacks.queue, "get_queue", return_value=[current, queued]
                ),
                patch.object(callbacks.queue, "get_current", return_value=current),
                patch.object(callbacks.queue, "force_add") as force_add,
                patch.object(
                    callbacks.anon, "_persist_queue", new=AsyncMock()
                ),
                patch.object(callbacks.anon, "play_media", new=play_media),
                patch.object(callbacks.app, "send_message", new=send_message),
                patch.object(callbacks.app, "delete_messages", new=delete_messages),
                patch.object(callbacks.yt, "download", new=AsyncMock()) as download,
            ):
                handler = inspect.unwrap(callbacks._controls)
                await handler(None, query)

            force_add.assert_called_once_with(-100555, queued, remove=1)
            download.assert_not_awaited()
            self.assertEqual(events, ["play", "delete"])
            self.assertEqual(
                set(delete_messages.await_args.kwargs["message_ids"]), {22, 88}
            )
            query.answer.assert_awaited_once_with("Playing now.")

        asyncio.run(run())
