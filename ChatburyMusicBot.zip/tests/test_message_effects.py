import unittest
from types import SimpleNamespace

from management.helpers.message_effects import (
    START_EFFECT_IDS,
    random_message_effect,
    send_with_message_effect,
)
from music.helpers._premium_emoji import premium_emoji_markup_from_entities


class MessageEffectTests(unittest.IsolatedAsyncioTestCase):
    async def test_uses_shared_effect_and_falls_back_for_unsupported_client(self):
        calls = []

        async def sender(**kwargs):
            calls.append(kwargs)
            if "message_effect_id" in kwargs:
                raise TypeError("unsupported keyword")
            return kwargs

        result = await send_with_message_effect(
            sender, chat_id=-100, photo="card.jpg", effect_id=123
        )
        self.assertEqual(result["effect_id"], 123)
        self.assertIn(random_message_effect(), START_EFFECT_IDS)
        self.assertEqual(len(calls), 2)

    def test_custom_emoji_id_is_preserved(self):
        entity = SimpleNamespace(
            type="custom_emoji",
            offset=0,
            length=2,
            custom_emoji_id="123456789",
        )
        rendered = premium_emoji_markup_from_entities("💜 go", [entity])
        self.assertEqual(rendered, "<emoji id=123456789>💜</emoji> go")

    def test_plain_text_is_unchanged(self):
        self.assertEqual(
            premium_emoji_markup_from_entities("Looking...", []), "Looking..."
        )
