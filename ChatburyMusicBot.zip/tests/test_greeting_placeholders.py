import unittest
from types import SimpleNamespace

from management.helpers.message_helper import MessageHelper


class GreetingPlaceholderTests(unittest.IsolatedAsyncioTestCase):
    async def test_common_first_name_and_chat_aliases_are_rendered(self):
        user = SimpleNamespace(
            id=42,
            first_name="Riya",
            last_name="Sharma",
            full_name="Riya Sharma",
            username="riya",
        )
        chat = SimpleNamespace(id=-100123, title="Nocturnal")

        rendered, _ = await MessageHelper.convert_fillings(
            "{firstname}|{First_Name}|{first}|{fullname}|{chatname}|{chat}",
            user,
            chat,
        )

        self.assertEqual(
            rendered,
            "Riya|Riya|Riya|Riya Sharma|Nocturnal|Nocturnal",
        )

    async def test_unknown_template_variable_is_left_unchanged(self):
        user = SimpleNamespace(
            id=42,
            first_name="Riya",
            last_name=None,
            full_name="Riya",
            username=None,
        )
        chat = SimpleNamespace(id=-100123, title="Nocturnal")

        rendered, _ = await MessageHelper.convert_fillings(
            "Hi {firstname}; {unknown}", user, chat
        )

        self.assertEqual(rendered, "Hi Riya; {unknown}")


if __name__ == "__main__":
    unittest.main()
