import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

import music.core.calls as calls_module
from music.core.calls import TgCall
from music.helpers._dataclass import Track


class DirectStreamPlaybackTests(unittest.IsolatedAsyncioTestCase):
    async def test_public_stream_starts_before_player_artwork_and_skips_download(self):
        events = []

        async def play(**_kwargs):
            events.append("audio_started")

        async def render_card(*_args, **_kwargs):
            events.append("artwork_rendered")

        client = SimpleNamespace(play=AsyncMock(side_effect=play))
        message = SimpleNamespace(id=77, edit_text=AsyncMock(), edit_media=AsyncMock())
        media = Track(
            id="public-track",
            channel_name="Artist",
            duration="03:00",
            duration_sec=180,
            title="Sawaal",
            url="https://www.youtube.com/watch?v=public-track",
            user="Listener",
            stream_url="https://media.example/audio",
            stream_headers={"User-Agent": "yt-dlp"},
        )
        bot = object.__new__(TgCall)
        bot._persist_queue = AsyncMock()
        stream_factory = Mock(return_value=object())
        stream_factory.Flags = SimpleNamespace(
            REQUIRED="required", AUTO_DETECT="auto", IGNORE="ignore"
        )

        with (
            patch.object(calls_module.db, "get_assistant", new=AsyncMock(return_value=client)),
            patch.object(calls_module.db, "add_call", new=AsyncMock()),
            patch.object(calls_module.db, "record_history", new=AsyncMock()),
            patch.object(
                calls_module.lang,
                "get_lang",
                new=AsyncMock(
                    return_value={
                        "play_media": "Playing {} — {} ({}) requested by {}",
                    }
                ),
            ),
            patch.object(calls_module.queue, "get_queue", return_value=[media]),
            patch.object(calls_module.buttons, "controls", return_value="keyboard"),
            patch.object(calls_module.types, "MediaStream", stream_factory),
            patch.object(
                TgCall,
                "_render_player_card",
                new=AsyncMock(side_effect=render_card),
            ),
            patch.object(calls_module.yt, "download", new=AsyncMock()) as download,
        ):
            result = await bot.play_media(-100123, message, media)
            await asyncio.sleep(0)

        self.assertTrue(result)
        self.assertEqual(events, ["audio_started", "artwork_rendered"])
        self.assertEqual(
            stream_factory.call_args.kwargs["media_path"],
            "https://media.example/audio",
        )
        self.assertEqual(
            stream_factory.call_args.kwargs["headers"],
            {"User-Agent": "yt-dlp"},
        )
        download.assert_not_awaited()
        message.edit_text.assert_awaited_once()

    async def test_soundcloud_track_uses_a_local_audio_file_when_available(self):
        client = SimpleNamespace(play=AsyncMock())
        message = SimpleNamespace(id=70, edit_text=AsyncMock(), edit_media=AsyncMock())
        media = Track(
            id="sc_123456789",
            channel_name="Artist",
            duration="03:00",
            duration_sec=180,
            title="Sawaal",
            url="https://soundcloud.com/artist/sawaal",
            user="Listener",
            stream_url="https://media.example/soundcloud-audio",
        )
        bot = object.__new__(TgCall)
        bot._persist_queue = AsyncMock()
        stream_factory = Mock(return_value=object())
        stream_factory.Flags = SimpleNamespace(
            REQUIRED="required", AUTO_DETECT="auto", IGNORE="ignore"
        )

        with (
            patch.object(calls_module.db, "get_assistant", new=AsyncMock(return_value=client)),
            patch.object(calls_module.db, "add_call", new=AsyncMock()),
            patch.object(calls_module.db, "record_history", new=AsyncMock()),
            patch.object(
                calls_module.lang,
                "get_lang",
                new=AsyncMock(
                    return_value={"play_media": "Playing {} — {} ({}) requested by {}"}
                ),
            ),
            patch.object(calls_module.queue, "get_queue", return_value=[media]),
            patch.object(calls_module.buttons, "controls", return_value="keyboard"),
            patch.object(calls_module.types, "MediaStream", stream_factory),
            patch.object(TgCall, "_render_player_card", new=AsyncMock()),
            patch.object(calls_module.Path, "is_file", return_value=True),
            patch.object(
                calls_module.yt,
                "download",
                new=AsyncMock(return_value="downloads/soundcloud.mp3"),
            ) as download,
            patch.object(calls_module, "add_music_post_reaction", new=AsyncMock()),
        ):
            result = await bot.play_media(-100123, message, media)

        self.assertTrue(result)
        download.assert_awaited_once_with(
            "sc_123456789", video=False, url="https://soundcloud.com/artist/sawaal"
        )
        self.assertEqual(
            stream_factory.call_args.kwargs["media_path"],
            "downloads/soundcloud.mp3",
        )
        self.assertIsNone(media.stream_url)

    async def test_rejected_youtube_stream_retries_then_uses_public_soundcloud_match(self):
        client = SimpleNamespace(
            play=AsyncMock(
                side_effect=[
                    calls_module.exceptions.NoAudioSourceFound("youtube-expired"),
                    calls_module.exceptions.NoAudioSourceFound("youtube-fresh"),
                    None,
                ]
            )
        )
        message = SimpleNamespace(id=78, edit_text=AsyncMock(), edit_media=AsyncMock())
        media = Track(
            id="Y1234567890",
            channel_name="YouTube Artist",
            artist="Public Artist",
            duration="03:00",
            duration_sec=180,
            title="Public Song",
            url="https://www.youtube.com/watch?v=Y1234567890",
            user="Listener",
            stream_url="https://media.example/youtube-expired",
        )
        refreshed = Track(
            id="Y1234567890",
            channel_name="YouTube Artist",
            artist="Public Artist",
            duration="03:00",
            duration_sec=180,
            title="Public Song",
            url=media.url,
            stream_url="https://media.example/youtube-fresh",
        )
        alternative = Track(
            id="sc_123456789",
            channel_name="Public Artist",
            artist="Public Artist",
            duration="03:00",
            duration_sec=180,
            title="Public Song",
            url="https://soundcloud.com/public-artist/public-song",
            stream_url="https://media.example/soundcloud-audio",
        )
        stream_factory = Mock(return_value=object())
        stream_factory.Flags = SimpleNamespace(
            REQUIRED="required", AUTO_DETECT="auto", IGNORE="ignore"
        )
        bot = object.__new__(TgCall)
        bot._persist_queue = AsyncMock()

        with (
            patch.object(calls_module.db, "get_assistant", new=AsyncMock(return_value=client)),
            patch.object(calls_module.db, "add_call", new=AsyncMock()),
            patch.object(calls_module.db, "record_history", new=AsyncMock()),
            patch.object(
                calls_module.lang,
                "get_lang",
                new=AsyncMock(
                    return_value={
                        "play_media": "Playing {} — {} ({}) requested by {}",
                    }
                ),
            ),
            patch.object(calls_module.queue, "get_queue", return_value=[media]),
            patch.object(calls_module.buttons, "controls", return_value="keyboard"),
            patch.object(calls_module.types, "MediaStream", stream_factory),
            patch.object(TgCall, "_render_player_card", new=AsyncMock()),
            patch.object(
                calls_module.yt,
                "search",
                new=AsyncMock(side_effect=[refreshed, alternative]),
            ) as search,
            patch.object(
                calls_module.yt, "download", new=AsyncMock(return_value=None)
            ) as download,
        ):
            result = await bot.play_media(-100123, message, media)

        self.assertTrue(result)
        self.assertEqual(client.play.await_count, 3)
        self.assertEqual(search.await_count, 2)
        self.assertEqual(search.await_args_list[1].args[0], "scsearch5:Public Song Public Artist")
        self.assertEqual(download.await_count, 2)
        self.assertEqual(media.id, "sc_123456789")
        self.assertEqual(media.url, alternative.url)
        self.assertEqual(media.user, "Listener")
        self.assertEqual(
            stream_factory.call_args.kwargs["media_path"],
            alternative.stream_url,
        )

    async def test_soundcloud_fallback_prefers_a_downloaded_audio_file(self):
        client = SimpleNamespace(
            play=AsyncMock(
                side_effect=[
                    calls_module.exceptions.NoAudioSourceFound("youtube-expired"),
                    calls_module.exceptions.NoAudioSourceFound("youtube-fresh"),
                    None,
                ]
            )
        )
        message = SimpleNamespace(id=79, edit_text=AsyncMock(), edit_media=AsyncMock())
        media = Track(
            id="Y9876543210",
            channel_name="Artist",
            artist="Artist",
            duration="03:00",
            duration_sec=180,
            title="Public Song",
            url="https://www.youtube.com/watch?v=Y9876543210",
            user="Listener",
            stream_url="https://media.example/youtube-expired",
        )
        refreshed = Track(
            id=media.id,
            channel_name="Artist",
            artist="Artist",
            duration="03:00",
            duration_sec=180,
            title=media.title,
            url=media.url,
            stream_url="https://media.example/youtube-fresh",
        )
        alternative = Track(
            id="sc_987654321",
            channel_name="Artist",
            artist="Artist",
            duration="03:00",
            duration_sec=180,
            title=media.title,
            url="https://soundcloud.com/artist/public-song",
            stream_url="https://media.example/soundcloud-audio",
        )
        stream_factory = Mock(return_value=object())
        stream_factory.Flags = SimpleNamespace(
            REQUIRED="required", AUTO_DETECT="auto", IGNORE="ignore"
        )
        bot = object.__new__(TgCall)
        bot._persist_queue = AsyncMock()

        with (
            patch.object(calls_module.db, "get_assistant", new=AsyncMock(return_value=client)),
            patch.object(calls_module.db, "add_call", new=AsyncMock()),
            patch.object(calls_module.db, "record_history", new=AsyncMock()),
            patch.object(
                calls_module.lang,
                "get_lang",
                new=AsyncMock(
                    return_value={
                        "play_media": "Playing {} — {} ({}) requested by {}",
                    }
                ),
            ),
            patch.object(calls_module.queue, "get_queue", return_value=[media]),
            patch.object(calls_module.buttons, "controls", return_value="keyboard"),
            patch.object(calls_module.types, "MediaStream", stream_factory),
            patch.object(TgCall, "_render_player_card", new=AsyncMock()),
            patch.object(
                calls_module.yt,
                "search",
                new=AsyncMock(side_effect=[refreshed, alternative]),
            ),
            patch.object(
                calls_module.yt,
                "download",
                new=AsyncMock(side_effect=[None, "downloads/sc_987654321.mp3"]),
            ) as download,
        ):
            result = await bot.play_media(-100123, message, media)

        self.assertTrue(result)
        self.assertEqual(client.play.await_count, 3)
        self.assertEqual(download.await_count, 2)
        self.assertEqual(
            stream_factory.call_args.kwargs["media_path"],
            "downloads/sc_987654321.mp3",
        )
        self.assertEqual(media.file_path, "downloads/sc_987654321.mp3")
        self.assertIsNone(media.stream_url)

