import unittest
from pathlib import Path

from management import tbot


class ManagementSessionIsolationTests(unittest.TestCase):
    def test_management_client_uses_a_separate_session_file(self):
        session_filename = Path(tbot.session.filename)
        self.assertNotEqual(
            session_filename.name,
            "management_mtproto.session",
        )
        self.assertIn("management_mtproto", session_filename.name)

