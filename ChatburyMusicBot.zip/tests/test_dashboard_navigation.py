import re
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from management.command_menu import build_group_admin_keyboard
from management.plugins import dashboard


def _buttons(markup):
    return [button for row in markup.inline_keyboard for button in row]


class DashboardNavigationTests(unittest.TestCase):
    def test_main_menu_has_requested_routes(self):
        buttons = _buttons(dashboard._home_keyboard(7123))
        callbacks = {button.callback_data for button in buttons}
        labels = {button.text for button in buttons}
        self.assertIn("music_help_home_7123", callbacks)
        self.assertIn("help_7123", callbacks)
        self.assertIn("illusion:groups:7123", callbacks)
        self.assertTrue(any(button.url and button.url.endswith("tgnxt") for button in buttons))
        self.assertTrue(any("ꜱᴛᴀᴛɪꜱᴛɪᴄꜱ" in label for label in labels))

    def test_group_dashboard_routes_are_scoped_to_chat_id(self):
        chat_id = -1009876
        callbacks = {button.callback_data for button in _buttons(build_group_admin_keyboard(chat_id, "IllusionMusicBot"))}
        self.assertIn(f"groupdash:section:{chat_id}:protection", callbacks)
        self.assertIn(f"groupdash:section:{chat_id}:welcome", callbacks)
        self.assertIn(f"adminpanel:music:{chat_id}", callbacks)


class DashboardPermissionTests(unittest.IsolatedAsyncioTestCase):
    async def test_personal_menu_rejects_a_different_user(self):
        query = SimpleNamespace(
            matches=[re.match(dashboard._HOME_RE, "illusion:groups:7123")],
            from_user=SimpleNamespace(id=9999),
            answer=AsyncMock(),
            edit_message_text=AsyncMock(),
        )
        await dashboard.user_dashboard_callback(None, query)
        query.answer.assert_awaited_once()
        self.assertTrue(query.answer.await_args.kwargs["show_alert"])
        query.edit_message_text.assert_not_awaited()

    async def test_group_dashboard_rejects_non_admin(self):
        chat_id = -1009876
        query = SimpleNamespace(
            matches=[re.match(dashboard._GROUP_RE, f"groupdash:home:{chat_id}")],
            from_user=SimpleNamespace(id=99),
            message=SimpleNamespace(chat=SimpleNamespace(type="private", id=99)),
            answer=AsyncMock(),
            edit_message_text=AsyncMock(),
        )
        with patch.object(dashboard, "_is_group_admin", new=AsyncMock(return_value=False)):
            await dashboard.group_dashboard_callback(None, query)
        query.answer.assert_awaited_once()
        self.assertTrue(query.answer.await_args.kwargs["show_alert"])
        query.edit_message_text.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
