import unittest
from types import SimpleNamespace

from management.helpers.message_helper import MessageHelper


class PremiumWelcomeEntityTests(unittest.TestCase):
    def test_custom_emoji_id_survives_welcome_text_formatting(self):
        text = "Hi 🌙!"
        entity = SimpleNamespace(
            type="custom_emoji",
            offset=3,
            length=2,
            custom_emoji_id="6005928962163742139",
        )

        stored_text = MessageHelper.entities_to_markdown(text, [entity])
        rendered_text = MessageHelper.convert_markdown_to_html(stored_text)

        self.assertIn(
            '<tg-emoji emoji-id="6005928962163742139">🌙</tg-emoji>',
            rendered_text,
        )

    def test_custom_emoji_after_non_bmp_text_uses_telegram_utf16_offsets(self):
        text = "😀 Hi 🌙!"
        entity = SimpleNamespace(
            type="custom_emoji",
            offset=6,
            length=2,
            custom_emoji_id="6005928962163742139",
        )

        stored_text = MessageHelper.entities_to_markdown(text, [entity])

        self.assertEqual(
            stored_text,
            '😀 Hi <tg-emoji emoji-id="6005928962163742139">🌙</tg-emoji>!',
        )


if __name__ == "__main__":
    unittest.main()
