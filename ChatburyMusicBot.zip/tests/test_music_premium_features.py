import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from PIL import Image, ImageDraw
from pyrogram.enums import ButtonStyle

from music import anon, db, queue, yt
from music.core.features import MusicFeatureService
from music.core.mongo import MongoDB
from music.helpers import Track, buttons
from music.helpers._queue import Queue
from music.helpers._thumbnails import Thumbnail


def track(track_id, title, artist="Artist", url=None):
    return Track(
        id=str(track_id),
        channel_name=artist,
        artist=artist,
        duration="03:00",
        duration_sec=180,
        title=title,
        url=url or f"https://www.youtube.com/watch?v={track_id}",
    )


class _Cursor:
    def __init__(self, docs):
        self.docs = list(docs)

    def sort(self, field, direction):
        self.docs.sort(key=lambda doc: doc.get(field), reverse=direction < 0)
        return self

    def limit(self, count):
        self.docs = self.docs[:count]
        return self

    def __aiter__(self):
        async def iterate():
            for doc in self.docs:
                yield doc

        return iterate()


class _Collection:
    def __init__(self):
        self.docs = {}

    async def update_one(self, selector, update, upsert=False):
        key = selector["_id"]
        doc = self.docs.setdefault(key, {"_id": key}) if upsert or key in self.docs else None
        if doc is None:
            return
        if "$set" in update:
            doc.update(update["$set"])
        if "$push" in update:
            for field, spec in update["$push"].items():
                values = list(doc.get(field, []))
                values[spec.get("$position", len(values)):spec.get("$position", len(values))] = spec["$each"]
                if "$slice" in spec:
                    values = values[:spec["$slice"]]
                doc[field] = values

    async def delete_one(self, selector):
        removed = self.docs.pop(selector["_id"], None)
        return SimpleNamespace(deleted_count=bool(removed))

    def find(self, selector):
        return _Cursor(
            doc for doc in self.docs.values()
            if all(doc.get(key) == value for key, value in selector.items())
        )

    async def find_one(self, selector):
        return self.docs.get(selector["_id"])


class QueuePremiumStateTests(unittest.TestCase):
    def test_previous_and_shuffle_are_isolated_by_group(self):
        state = Queue()
        first, second, third, fourth = (
            track("a", "A"), track("b", "B"), track("c", "C"), track("d", "D")
        )
        state.add(-100, second)
        state.add(-100, third)
        state.add(-100, fourth)
        state.add(-200, first)
        state.remember(-100, first)

        with patch("music.helpers._queue.random.shuffle", side_effect=lambda values: values.reverse()):
            self.assertTrue(state.shuffle_upcoming(-100))
        self.assertEqual([item.id for item in state.get_queue(-100)], ["b", "d", "c"])
        self.assertEqual([item.id for item in state.get_queue(-200)], ["a"])
        self.assertEqual(state.previous(-100).id, "a")
        self.assertEqual(state.get_current(-100).id, "a")
        self.assertEqual(state.get_next(-100).id, "b")

    def test_cycle_loop_has_three_real_modes_per_group(self):
        chat_id = -990123
        original = anon.loop_mode(chat_id)
        try:
            self.assertEqual(anon.cycle_loop(chat_id), "track")
            self.assertEqual(anon.cycle_loop(chat_id), "queue")
            self.assertEqual(anon.loop_mode(chat_id), "queue")
            self.assertEqual(anon.cycle_loop(chat_id), "off")
            self.assertEqual(anon.loop_mode(-990124), "off")
        finally:
            anon._loop_modes.pop(chat_id, None)
            if original != "off":
                anon._loop_modes[chat_id] = original

    def test_player_keyboard_uses_compact_legacy_controls(self):
        chat_id = -990125
        keyboard = buttons.controls(chat_id)
        rows = [[button.text for button in row] for row in keyboard.inline_keyboard]
        self.assertEqual(
            rows,
            [
                ["00:00 " + "▱" * 10 + " 00:00"],
                ["▶ ᴘʟᴀʏ", "Ⅱ ᴘᴀᴜꜱᴇ", "↻ ʟᴏᴏᴘ", "▸▸ɪ ɴᴇxᴛ", "□ ꜱᴛᴏᴘ"],
                ["« 30ꜱ", "« 10ꜱ", "10ꜱ »", "30ꜱ »"],
                ["↻ ᴀᴜᴛᴏᴘʟᴀʏ ᴏꜰꜰ", "• ʀᴇᴄ"],
                ["ᴄʟᴏꜱᴇ"],
            ],
        )
        self.assertEqual(
            [button.style for button in keyboard.inline_keyboard[0]],
            [ButtonStyle.SUCCESS],
        )
        self.assertEqual(
            [button.style for button in keyboard.inline_keyboard[1]],
            [
                ButtonStyle.SUCCESS,
                ButtonStyle.PRIMARY,
                ButtonStyle.SUCCESS,
                ButtonStyle.PRIMARY,
                ButtonStyle.DANGER,
            ],
        )
        self.assertEqual(
            [button.style for button in keyboard.inline_keyboard[3]],
            [ButtonStyle.PRIMARY, ButtonStyle.SUCCESS],
        )
        self.assertEqual(
            [button.style for button in keyboard.inline_keyboard[4]],
            [ButtonStyle.DANGER],
        )
        self.assertEqual(
            [button.callback_data.split()[1] for row in keyboard.inline_keyboard for button in row],
            [
                "status", "resume", "pause", "loop", "next", "stop",
                "seek", "seek", "seek", "seek", "autoplay", "rec", "close",
            ],
        )
        self.assertEqual(
            keyboard.inline_keyboard[0][0].callback_data,
            f"controls status {chat_id}",
        )
        self.assertFalse(any("Lyrics" in text for row in rows for text in row))

        was_enabled = anon.is_autoplay_enabled(chat_id)
        try:
            anon._autoplay_chats.add(chat_id)
            enabled_rows = [
                [button.text for button in row]
                for row in buttons.controls(chat_id).inline_keyboard
            ]
            self.assertEqual(enabled_rows[3][0], "↻ ᴀᴜᴛᴏᴘʟᴀʏ ᴏɴ")
        finally:
            if not was_enabled:
                anon._autoplay_chats.discard(chat_id)

    def test_progress_button_fills_by_half_steps_and_finishes_full(self):
        start = buttons.progress_bar(4, 214)
        halfway = buttons.progress_bar(107, 214)
        almost_done = buttons.progress_bar(213, 214)
        finished = buttons.progress_bar(214, 214)

        self.assertEqual(start, f"00:04 {'◧' + '▱' * 9} 03:34")
        self.assertEqual(halfway, f"01:47 {'▰' * 5 + '▱' * 5} 03:34")
        self.assertEqual(almost_done, f"03:33 {'▰' * 9 + '◧'} 03:34")
        self.assertEqual(finished, f"03:34 {'▰' * 10} 03:34")

    def test_player_thumbnail_uses_track_position_and_uploaded_avatar(self):
        item = track("thumbnail-test", "A Song")
        item.time = 65
        card = Thumbnail()
        self.assertEqual(card._duration_seconds(item), 180)
        self.assertEqual(card._format_time(item.time), "01:05")

        avatar = card._avatar((128, 128))
        self.assertIsNotNone(avatar)
        self.assertEqual(avatar.size, (128, 128))
        cover = Image.new("RGB", (320, 180), (70, 18, 135))
        rendered = card._compose(item, cover, (1280, 720))
        self.assertEqual(rendered.size, (1280, 720))
        self.assertEqual(rendered.mode, "RGB")
        self.assertNotEqual(rendered.getpixel((820, 230)), (0, 0, 0))
        later = card._compose(item, cover, (1280, 720), position=90)
        self.assertNotEqual(rendered.tobytes(), later.tobytes())
        reference_size = card._compose(item, cover, (1024, 576))
        self.assertEqual(reference_size.size, (1024, 576))
        square = card._compose(item, cover, (800, 800))
        self.assertEqual(square.size, (800, 800))
        self.assertEqual(square.getpixel((400, 5)), (7, 5, 16))
        self.assertNotEqual(
            card._accent(Image.new("RGB", (80, 80), (20, 180, 80))),
            (164, 74, 255),
        )

    def test_player_card_fits_the_full_16_by_9_thumbnail(self):
        cover = Image.new("RGB", (320, 180), (20, 20, 24))
        draw = ImageDraw.Draw(cover)
        draw.rectangle((0, 0, 55, 55), fill=(240, 25, 30))
        draw.rectangle((265, 0, 319, 55), fill=(20, 220, 70))
        draw.rectangle((0, 125, 55, 179), fill=(245, 210, 25))
        draw.rectangle((265, 125, 319, 179), fill=(30, 80, 240))
        rendered = Thumbnail()._compose(
            track("fit-test", "Fit test"), cover, (1280, 720)
        )

        self.assertEqual(rendered.getpixel((488, 180)), (240, 25, 30))
        self.assertEqual(rendered.getpixel((1160, 180)), (20, 220, 70))
        self.assertEqual(rendered.getpixel((488, 454)), (245, 210, 25))
        self.assertEqual(rendered.getpixel((1160, 454)), (30, 80, 240))


class MusicFeatureServiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_related_tracks_remove_duplicate_ids_titles_and_recent_ids(self):
        class FakeYouTube:
            async def search_many(self, query, limit):
                return [
                    track("seed", "Seed"),
                    track("a", "A"),
                    track("b", "B"),
                    track("different-id", "A"),
                    track("c", "C"),
                ]

        service = MusicFeatureService(FakeYouTube())
        found = await service.related_tracks(
            track("seed", "Seed"), limit=5, exclude_ids={"b"}
        )
        self.assertEqual([item.id for item in found], ["a", "c"])

    async def test_radio_verifies_candidates_and_caps_each_refill_at_three(self):
        chat_id = -990126
        candidates = [track(str(index), f"Song {index}") for index in range(8)]

        class FakeRecommendations:
            async def related_tracks(self, seed, limit, exclude_ids=None):
                return candidates

        original_features = anon.features
        queue.clear(chat_id)
        verified = {
            item.url: track(item.id, item.title, url=item.url) for item in candidates
        }

        async def search(url, _message_id):
            return verified.get(url)

        try:
            anon.features = FakeRecommendations()
            with (
                patch.object(yt, "search", new=AsyncMock(side_effect=search)) as search_mock,
                patch.object(yt, "download", new=AsyncMock(return_value="/tmp/public-track.mp3")),
                patch.object(db, "save_queue", new=AsyncMock()),
            ):
                count = await anon._fill_radio(chat_id, track("seed", "Seed"))
            self.assertEqual(count, 3)
            self.assertEqual(len(queue.get_queue(chat_id)), 3)
            self.assertLessEqual(search_mock.await_count, 3)
            self.assertTrue(all(item.user == "Radio" for item in queue.get_queue(chat_id)))
        finally:
            queue.clear(chat_id)
            anon.features = original_features


class MusicMongoPersistenceTests(unittest.IsolatedAsyncioTestCase):
    async def test_music_account_id_override_persists_and_can_be_cleared(self):
        store = object.__new__(MongoDB)
        store.bot_configdb = _Collection()

        self.assertIsNone(await store.get_music_account_id_override())
        await store.set_music_account_id_override(987654321)
        self.assertEqual(await store.get_music_account_id_override(), 987654321)
        with self.assertRaises(ValueError):
            await store.set_music_account_id_override(0)

        await store.clear_music_account_id_override()
        self.assertIsNone(await store.get_music_account_id_override())

    async def test_favorites_history_and_radio_are_scoped_to_user_and_chat(self):
        store = object.__new__(MongoDB)
        store.favoritesdb = _Collection()
        store.historydb = _Collection()
        store.radiodb = _Collection()
        song = track("favorite-1", "Favorite song")

        await store.save_favorite(1001, song)
        await store.save_favorite(1002, song)
        self.assertEqual(len(await store.get_favorites(1001)), 1)
        self.assertEqual(len(await store.get_favorites(1002)), 1)
        self.assertTrue(await store.remove_favorite(1001, song.id))
        self.assertEqual(await store.get_favorites(1001), [])
        self.assertEqual(len(await store.get_favorites(1002)), 1)

        await store.record_history(-1001, song)
        self.assertEqual((await store.get_history(-1001))[0]["track_id"], song.id)
        self.assertEqual(await store.get_history(-1002), [])
        await store.set_radio(-1001, True)
        self.assertTrue(await store.get_radio(-1001))
        self.assertFalse(await store.get_radio(-1002))

    async def test_queue_metadata_restores_without_stale_local_file_paths(self):
        store = object.__new__(MongoDB)
        store.queuedb = _Collection()
        chat_id = -990127
        queue.clear(chat_id)
        song = track("restore-1", "Restored song")
        song.file_path = "/tmp/old-host/expired.mp3"
        await store.save_queue(chat_id, [song])
        queue.clear(chat_id)

        await store.restore_queues()
        restored = queue.get_current(chat_id)
        try:
            self.assertIsNotNone(restored)
            self.assertEqual(restored.id, song.id)
            self.assertIsNone(restored.file_path)
        finally:
            queue.clear(chat_id)


if __name__ == "__main__":
    unittest.main()
