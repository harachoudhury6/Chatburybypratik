import unittest

from pyrogram import types

from management import command_menu


class _CommandMenuClient:
    def __init__(self):
        self.calls = []
        self.menu_button = None

    async def set_bot_commands(self, commands, *, scope):
        self.calls.append((commands, scope))

    async def set_chat_menu_button(self, *, menu_button):
        self.menu_button = menu_button
        return True


class CommandMenuTests(unittest.IsolatedAsyncioTestCase):
    async def test_native_commands_menu_is_enabled(self):
        client = _CommandMenuClient()
        await command_menu.install_command_menus(client)

        self.assertIsInstance(client.menu_button, types.MenuButtonCommands)

    async def test_group_admin_commands_are_separate_from_public_commands(self):
        client = _CommandMenuClient()
        await command_menu.install_command_menus(client)

        by_scope = {type(scope): commands for commands, scope in client.calls}
        public = {
            entry.command
            for entry in by_scope[types.BotCommandScopeAllGroupChats]
        }
        administrators = {
            entry.command
            for entry in by_scope[types.BotCommandScopeAllChatAdministrators]
        }

        self.assertIn("play", public)
        self.assertNotIn("ban", public)
        self.assertNotIn("admin", public)
        self.assertIn("ban", administrators)
        self.assertIn("admin", administrators)

    async def test_private_owner_login_commands_are_scoped(self):
        client = _CommandMenuClient()
        await command_menu.install_command_menus(client)

        all_private = next(
            commands
            for commands, scope in client.calls
            if isinstance(scope, types.BotCommandScopeAllPrivateChats)
        )
        self.assertNotIn("login", {entry.command for entry in all_private})
        self.assertNotIn("logout", {entry.command for entry in all_private})

        owner_private = next(
            commands
            for commands, scope in client.calls
            if isinstance(scope, types.BotCommandScopeChat)
        )
        owner_names = {entry.command for entry in owner_private}
        self.assertIn("admin", owner_names)
        self.assertIn("setmusicaccount", owner_names)
        self.assertIn("broadcast", owner_names)
        self.assertIn("stop_broadcast", owner_names)
        self.assertNotIn("setmusicaccount", {entry.command for entry in all_private})

    def test_admin_panel_lists_admin_commands_without_exposing_them_in_mcommands(self):
        self.assertNotIn("/ban", command_menu.format_command_names())
        self.assertIn("<code>/ban</code>", command_menu.format_admin_commands())
        self.assertNotIn("setmusicaccount", command_menu.format_admin_commands())
        self.assertIn("<code>/setmusicaccount</code>", command_menu.format_owner_commands())


if __name__ == "__main__":
    unittest.main()
