import unittest
from unittest.mock import AsyncMock

from music.helpers._reactions import add_music_post_reaction


class MusicPostReactionTests(unittest.IsolatedAsyncioTestCase):
    async def test_adds_a_heart_reaction_to_the_music_post(self):
        client = AsyncMock()
        client.send_reaction.return_value = True

        result = await add_music_post_reaction(client, -100123, 45)

        self.assertTrue(result)
        client.send_reaction.assert_awaited_once_with(
            chat_id=-100123,
            message_id=45,
            emoji="❤",
        )

    async def test_reaction_failure_does_not_break_playback(self):
        client = AsyncMock()
        client.send_reaction.side_effect = RuntimeError("reactions disabled")

        result = await add_music_post_reaction(client, -100123, 45)

        self.assertFalse(result)
