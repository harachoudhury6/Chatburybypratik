import unittest

from management.command_menu import (
    build_group_admin_keyboard,
    build_owner_admin_keyboard,
    build_private_group_admin_keyboard,
    format_admin_commands,
    format_owner_commands,
)


def _buttons(markup):
    return [button for row in markup.inline_keyboard for button in row]


class AdminPanelTests(unittest.TestCase):
    def test_group_admin_menu_opens_scoped_dashboard(self):
        chat_id = -1001234567890
        markup = build_group_admin_keyboard(chat_id, "@PrikshaMusicBot")
        buttons = _buttons(markup)

        callback_data = {button.callback_data for button in buttons}
        self.assertIn(f"groupdash:section:{chat_id}:protection", callback_data)
        self.assertIn(f"groupdash:section:{chat_id}:welcome", callback_data)
        self.assertIn(f"adminpanel:music:{chat_id}", callback_data)

    def test_private_group_admin_panel_is_scoped_to_group(self):
        chat_id = -1001234567890
        markup = build_private_group_admin_keyboard(chat_id)
        callback_data = {button.callback_data for button in _buttons(markup)}

        self.assertIn(f"groupdash:home:{chat_id}", callback_data)
        self.assertIn(f"adminpanel:commands:{chat_id}", callback_data)
        self.assertNotIn("/setmusicaccount", format_admin_commands())

    def test_owner_panel_has_music_id_and_music_only_group_controls(self):
        callback_data = {
            button.callback_data
            for button in _buttons(build_owner_admin_keyboard())
        }

        self.assertIn("owner_admin:music_id", callback_data)
        self.assertIn("owner_admin:remove_music_id", callback_data)
        self.assertIn("owner_admin:music_only_chat_add", callback_data)
        self.assertIn("owner_admin:music_only_chat_remove", callback_data)
        self.assertIn("owner_admin:login_help", callback_data)
        self.assertIn("owner_admin:commands", callback_data)
        self.assertIn("owner_admin:owner_username", callback_data)
        self.assertIn("owner_admin:support_username", callback_data)
        self.assertIn("owner_admin:clear_owner_username", callback_data)
        self.assertIn("owner_admin:reset_support_username", callback_data)
        self.assertIn("owner_admin:search_indicator", callback_data)
        self.assertIn("owner_admin:reset_search_indicator", callback_data)
        self.assertIn("/setmusicaccount", format_owner_commands())
        self.assertIn("/removemusicaccount", format_owner_commands())
        self.assertNotIn("/removemusicaccount", format_admin_commands())

    def test_start_buttons_link_owner_and_support_to_private_profiles(self):
        from unittest.mock import patch

        from management.db import owner_profile
        from management.plugins.base import _gsb

        profile = {
            "owner_username": "ownername",
            "support_username": "tgnxt",
        }
        with patch.object(owner_profile, "_profile", profile):
            buttons = [
                button
                for row in _gsb(12345).inline_keyboard
                for button in row
            ]

        linked_buttons = {button.url: button.text for button in buttons if button.url}
        self.assertEqual(
            linked_buttons["https://t.me/ownername"], "ᴏᴡɴᴇʀ @ᴏᴡɴᴇʀɴᴀᴍᴇ"
        )
        self.assertEqual(linked_buttons["https://t.me/tgnxt"], "ꜱᴜᴘᴘᴏʀᴛ @ᴛɢɴxᴛ")
        self.assertIn(
            "help_12345", [button.callback_data for button in buttons]
        )
