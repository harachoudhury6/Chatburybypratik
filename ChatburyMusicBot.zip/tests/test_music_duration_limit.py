import unittest
from unittest.mock import patch

from config import Config


class MusicDurationLimitTests(unittest.TestCase):
    def test_duration_limit_defaults_to_unlimited(self):
        env = {
            "BOT_TOKEN": "123456:abcdefghijklmnopqrstuvwxyzABC",
            "API_ID": "12345",
            "API_HASH": "test-hash",
            "MONGO_DB_URI": "mongodb://localhost/test",
            "OWNER_ID": "12345",
        }
        with patch.dict("os.environ", env, clear=True):
            settings = Config()
            settings.validate()

        self.assertEqual(settings.DURATION_LIMIT, 0)

    def test_positive_duration_limit_remains_an_optional_admin_cap(self):
        with patch.dict("os.environ", {"DURATION_LIMIT": "10800"}, clear=False):
            settings = Config()

        self.assertEqual(settings.DURATION_LIMIT, 10800)

