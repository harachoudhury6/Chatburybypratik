"""Branded queue and completed-track cards for the music bot."""

from __future__ import annotations

import logging
from io import BytesIO
from pathlib import Path
from typing import Iterable

import aiohttp
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

from music.helpers._dataclass import Media, Track

MediaItem = Media | Track
SIZE = (1280, 720)
PURPLE = (169, 91, 255)
WHITE = (248, 246, 255)
MUTED = (190, 188, 211)
logger = logging.getLogger("eiko.music.queue_cards")


class QueueCards:
    def __init__(self) -> None:
        self.asset_dir = Path(__file__).resolve().parent / "images"
        self.bold_font = Path(__file__).resolve().parent / "Raleway-Bold.ttf"
        self.light_font = Path(__file__).resolve().parent / "Inter-Light.ttf"

    def _font(self, size: int, *, bold: bool = False):
        font_path = self.bold_font if bold else self.light_font
        try:
            return ImageFont.truetype(font_path, size)
        except OSError:
            return ImageFont.load_default()

    def _background(self, filename: str) -> Image.Image:
        with Image.open(self.asset_dir / filename) as source:
            background = ImageOps.fit(
                source.convert("RGB"),
                SIZE,
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.5),
            )
        return Image.alpha_composite(
            background.convert("RGBA"),
            Image.new("RGBA", SIZE, (5, 5, 18, 106)),
        )

    @staticmethod
    def _fit(draw: ImageDraw.ImageDraw, text: object, font, width: int) -> str:
        value = " ".join(str(text or "").split())
        try:
            if draw.textlength(value, font=font) <= width:
                return value
            while value and draw.textlength(value + "…", font=font) > width:
                value = value[:-1]
        except UnicodeEncodeError:
            value = value.encode("ascii", "ignore").decode("ascii")
            while value and draw.textlength(value + "...", font=font) > width:
                value = value[:-1]
            return value.rstrip() + "..."
        return value.rstrip() + "…"

    @staticmethod
    def _wrap(draw: ImageDraw.ImageDraw, text: object, font, width: int, limit: int = 3):
        words = " ".join(str(text or "").split()).split()
        lines: list[str] = []
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip()
            try:
                fits = draw.textlength(candidate, font=font) <= width
            except UnicodeEncodeError:
                word = word.encode("ascii", "ignore").decode("ascii")
                candidate = f"{current} {word}".strip()
                fits = draw.textlength(candidate, font=font) <= width
            if not fits and current:
                lines.append(current)
                current = word
                if len(lines) == limit:
                    break
            else:
                current = candidate
        if current and len(lines) < limit:
            lines.append(current)
        if len(lines) == limit and words and len(" ".join(lines).split()) < len(words):
            lines[-1] = QueueCards._fit(draw, lines[-1], font, width - 24)
        return lines

    @staticmethod
    def _title(item: MediaItem) -> str:
        return str(getattr(item, "title", "") or "Untitled track")

    @staticmethod
    def _artist(item: MediaItem) -> str:
        return str(
            getattr(item, "artist", None)
            or getattr(item, "channel_name", None)
            or "YouTube"
        )

    @staticmethod
    def _duration(item: MediaItem) -> str:
        return str(getattr(item, "duration", None) or "Duration unavailable")

    @staticmethod
    def _write_image(image: Image.Image, name: str) -> BytesIO:
        output = BytesIO()
        image.convert("RGB").save(output, format="JPEG", quality=91, optimize=True)
        output.seek(0)
        output.name = name
        return output

    def render_queue(self, items: Iterable[MediaItem], chat_title: str = "") -> BytesIO:
        tracks = list(items)
        if not tracks:
            raise ValueError("Cannot render an empty music queue.")

        canvas = self._background("queue-background.png")
        draw = ImageDraw.Draw(canvas)
        draw.rounded_rectangle(
            (34, 32, 1246, 688),
            radius=34,
            fill=(7, 8, 25, 178),
            outline=(*PURPLE, 185),
            width=2,
        )
        draw.text((76, 61), "ILLUSION MUSIC BOT", font=self._font(23, bold=True), fill=WHITE)
        draw.text((76, 94), "PLAY QUEUE", font=self._font(18, bold=True), fill=(*PURPLE, 255))
        heading = self._fit(draw, chat_title or "Voice chat", self._font(17), 390)
        draw.text((825, 77), heading, font=self._font(17), fill=MUTED)

        current = tracks[0]
        upcoming = tracks[1:]
        draw.rounded_rectangle(
            (58, 158, 474, 660),
            radius=26,
            fill=(15, 13, 35, 226),
            outline=(126, 76, 210, 155),
            width=2,
        )
        draw.text((88, 190), "NOW PLAYING", font=self._font(21, bold=True), fill=(*PURPLE, 255))
        title_font = self._font(34, bold=True)
        for index, line in enumerate(self._wrap(draw, self._title(current), title_font, 342, 3)):
            draw.text((88, 242 + index * 47), line, font=title_font, fill=WHITE)
        artist_y = 398
        artist = self._fit(draw, self._artist(current), self._font(22), 340)
        draw.text((88, artist_y), artist, font=self._font(22), fill=MUTED)
        draw.rounded_rectangle((88, 460, 444, 462), radius=1, fill=(85, 66, 121, 255))
        draw.rounded_rectangle((88, 460, 250, 462), radius=1, fill=(*PURPLE, 255))
        draw.text(
            (88, 490),
            f"DURATION  •  {self._duration(current)}",
            font=self._font(19),
            fill=WHITE,
        )
        draw.text((88, 550), f"{len(upcoming)} track(s) waiting", font=self._font(20, bold=True), fill=MUTED)
        draw.text(
            (88, 612),
            self._fit(draw, f"Requested by {getattr(current, 'user', None) or 'listener'}", self._font(17), 340),
            font=self._font(17),
            fill=MUTED,
        )

        draw.rounded_rectangle(
            (498, 158, 1222, 660),
            radius=26,
            fill=(10, 10, 28, 202),
            outline=(101, 82, 166, 120),
            width=2,
        )
        draw.text((532, 188), "UP NEXT", font=self._font(23, bold=True), fill=WHITE)
        draw.text(
            (1015, 192),
            f"{len(upcoming)} TRACKS",
            font=self._font(16, bold=True),
            fill=(*PURPLE, 255),
        )

        visible = upcoming[:5]
        if not visible:
            draw.text((552, 362), "No more tracks in the queue", font=self._font(28, bold=True), fill=WHITE)
            draw.text((552, 407), "Add a song with /play", font=self._font(21), fill=MUTED)
        for index, item in enumerate(visible, start=1):
            y = 232 + (index - 1) * 78
            draw.rounded_rectangle(
                (526, y, 1194, y + 66),
                radius=16,
                fill=(22, 19, 47, 217),
                outline=(101, 82, 166, 95),
                width=1,
            )
            draw.ellipse((544, y + 14, 582, y + 52), fill=(*PURPLE, 245))
            number = str(index)
            number_width = draw.textlength(number, font=self._font(19, bold=True))
            draw.text(
                (563 - number_width / 2, y + 21),
                number,
                font=self._font(19, bold=True),
                fill=(255, 255, 255, 255),
            )
            draw.text(
                (600, y + 10),
                self._fit(draw, self._title(item), self._font(21, bold=True), 442),
                font=self._font(21, bold=True),
                fill=WHITE,
            )
            meta = f"{self._duration(item)}  •  {getattr(item, 'user', None) or 'Queued'}"
            draw.text(
                (600, y + 39),
                self._fit(draw, meta, self._font(15), 530),
                font=self._font(15),
                fill=MUTED,
            )
        if len(upcoming) > len(visible):
            draw.text(
                (544, 632),
                f"+ {len(upcoming) - len(visible)} more queued",
                font=self._font(17, bold=True),
                fill=(*PURPLE, 255),
            )
        return self._write_image(canvas, "nocturnal-queue.jpg")

    async def render_queued(
        self,
        item: MediaItem,
        position: int,
        current_item: MediaItem | None = None,
    ) -> BytesIO:
        artwork = None
        thumbnail_url = getattr(item, "thumbnail", None)
        if thumbnail_url:
            try:
                timeout = aiohttp.ClientTimeout(total=8)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get(thumbnail_url) as response:
                        response.raise_for_status()
                        if response.content_length and response.content_length > 8_000_000:
                            raise ValueError("Artwork exceeds size limit.")
                        content = await response.read()
                if len(content) <= 8_000_000:
                    with Image.open(BytesIO(content)) as source:
                        artwork = source.convert("RGB")
            except Exception as exc:
                logger.info("Queued track artwork unavailable (%s).", type(exc).__name__)

        if artwork is not None:
            background = ImageOps.fit(
                artwork, SIZE, method=Image.Resampling.LANCZOS
            ).filter(ImageFilter.GaussianBlur(34))
            canvas = Image.alpha_composite(
                background.convert("RGBA"),
                Image.new("RGBA", SIZE, (5, 5, 18, 174)),
            )
        else:
            canvas = self._background("queue-background.png")

        draw = ImageDraw.Draw(canvas)
        draw.rounded_rectangle(
            (30, 28, 1250, 692),
            radius=34,
            fill=(7, 8, 25, 155),
            outline=(*PURPLE, 195),
            width=3,
        )
        draw.text((76, 67), "ILLUSION MUSIC BOT", font=self._font(23, bold=True), fill=WHITE)
        draw.text(
            (158, 101),
            f"QUEUED TRACK  •  POSITION #{max(1, int(position))}",
            font=self._font(17, bold=True),
            fill=(*PURPLE, 255),
        )

        art_box = (72, 158, 522, 608)
        if artwork is not None:
            art = ImageOps.fit(
                artwork, (450, 450), method=Image.Resampling.LANCZOS
            ).convert("RGBA")
            mask = Image.new("L", (450, 450), 0)
            ImageDraw.Draw(mask).rounded_rectangle(
                (0, 0, 449, 449), radius=30, fill=255
            )
            canvas.paste(art, (72, 158), mask)
        else:
            draw.rounded_rectangle(art_box, radius=30, fill=(30, 18, 61, 255))
            cx, cy = 297, 383
            draw.ellipse(
                (cx - 118, cy - 118, cx + 118, cy + 118),
                fill=(11, 10, 28, 255),
                outline=(*PURPLE, 230),
                width=5,
            )
            for radius in (98, 78, 58):
                draw.ellipse(
                    (cx - radius, cy - radius, cx + radius, cy + radius),
                    outline=(*PURPLE, 105),
                    width=3,
                )
            draw.ellipse(
                (cx - 22, cy - 22, cx + 22, cy + 22),
                fill=(*PURPLE, 245),
            )
        draw = ImageDraw.Draw(canvas)
        draw.rounded_rectangle(art_box, radius=30, outline=(*PURPLE, 235), width=4)

        draw.rounded_rectangle(
            (570, 158, 1208, 608),
            radius=28,
            fill=(8, 8, 24, 218),
            outline=(126, 76, 210, 165),
            width=2,
        )
        draw.text(
            (612, 192), "WAITING TO PLAY", font=self._font(18, bold=True), fill=(*PURPLE, 255)
        )
        title_font = self._font(36, bold=True)
        title_lines = self._wrap(draw, self._title(item), title_font, 550, 3)
        for index, line in enumerate(title_lines):
            draw.text((612, 244 + index * 48), line, font=title_font, fill=WHITE)

        detail_y = 405 if len(title_lines) >= 3 else 380
        draw.text(
            (612, detail_y),
            self._fit(draw, self._artist(item), self._font(22), 550),
            font=self._font(22),
            fill=MUTED,
        )
        draw.rounded_rectangle(
            (612, detail_y + 54, 1162, detail_y + 57), radius=2, fill=(91, 73, 127, 255)
        )
        draw.text(
            (612, detail_y + 82),
            f"DURATION  •  {self._duration(item)}",
            font=self._font(18, bold=True),
            fill=WHITE,
        )
        requester = self._fit(
            draw,
            f"REQUESTED BY  •  {getattr(item, 'user', None) or 'listener'}",
            self._font(16),
            550,
        )
        draw.text((612, detail_y + 124), requester, font=self._font(16), fill=MUTED)
        if current_item:
            current_title = self._fit(
                draw, self._title(current_item), self._font(15, bold=True), 550
            )
            draw.text(
                (612, 562),
                f"NOW PLAYING  •  {current_title}",
                font=self._font(15, bold=True),
                fill=(*PURPLE, 255),
            )
        return self._write_image(
            canvas, f"nocturnal-queued-{max(1, int(position))}.jpg"
        )

    def render_ended(self, item: MediaItem, next_item: MediaItem | None = None) -> BytesIO:
        canvas = self._background("track-ended-background.png")
        draw = ImageDraw.Draw(canvas)
        draw.rounded_rectangle(
            (38, 38, 1242, 682),
            radius=36,
            fill=(7, 7, 23, 140),
            outline=(*PURPLE, 150),
            width=2,
        )
        draw.text((80, 82), "ILLUSION MUSIC BOT", font=self._font(24, bold=True), fill=WHITE)
        draw.text((80, 119), "PLAYBACK UPDATE", font=self._font(17, bold=True), fill=(*PURPLE, 255))
        draw.text((80, 212), "TRACK FINISHED", font=self._font(43, bold=True), fill=WHITE)

        title_font = self._font(36, bold=True)
        for index, line in enumerate(self._wrap(draw, self._title(item), title_font, 690, 2)):
            draw.text((84, 296 + index * 50), line, font=title_font, fill=WHITE)
        draw.text(
            (86, 414),
            self._fit(draw, self._artist(item), self._font(23), 680),
            font=self._font(23),
            fill=MUTED,
        )
        draw.rounded_rectangle((86, 476, 548, 478), radius=1, fill=(*PURPLE, 235))
        if next_item:
            draw.text((86, 518), "UP NEXT", font=self._font(17, bold=True), fill=(*PURPLE, 255))
            draw.text(
                (86, 554),
                self._fit(draw, self._title(next_item), self._font(25, bold=True), 690),
                font=self._font(25, bold=True),
                fill=WHITE,
            )
        else:
            draw.text((86, 530), "Thanks for listening", font=self._font(24), fill=WHITE)
        return self._write_image(canvas, "nocturnal-track-finished.jpg")


queue_cards = QueueCards()
