"""Inline keyboard builders used by the music controls and menus."""

from pyrogram import types
from pyrogram.enums import ButtonStyle

from music import app, config, lang

_SMALL_CAPS = str.maketrans(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ" * 2,
)


def _label(text: str) -> str:
    return text.translate(_SMALL_CAPS)


def _support_url() -> str:
    try:
        from management.db.owner_profile import get_public_profile, username_url

        profile = get_public_profile()
        return username_url(profile.get("support_username")) or "https://t.me/tgnxt"
    except Exception:
        value = (getattr(config, "SUPPORT_USERNAME", "") or "tgnxt").strip()
        return f"https://t.me/{value.lstrip('@')}"


def _owner_url() -> str | None:
    try:
        from management.db.owner_profile import get_public_profile, username_url

        return username_url(get_public_profile().get("owner_username"))
    except Exception:
        value = (getattr(config, "OWNER_USERNAME", "") or "").strip()
        return f"https://t.me/{value.lstrip('@')}" if value else None


def _official_group_url() -> str:
    value = (
        getattr(config, "SUPPORT_GROUP", "")
        or getattr(config, "SUPPORT_CHAT", "")
        or "https://t.me/NocturnalGC"
    ).strip()
    if value.startswith(("http://", "https://")):
        return value
    return f"https://t.me/{value.lstrip('@')}"


def _updates_url() -> str:
    value = config.UPDATE_CHANNEL.strip()
    if value.startswith(("http://", "https://")):
        return value
    return f"https://t.me/{value.lstrip('@')}"


class Inline:
    def __init__(self) -> None:
        self.ikm = types.InlineKeyboardMarkup
        self.ikb = types.InlineKeyboardButton

    def cancel_dl(self, text: str) -> types.InlineKeyboardMarkup:
        return self.ikm([[self.ikb(text=text, callback_data="cancel_dl")]])

    def controls(
        self,
        chat_id: int,
        user_id: int = 0,
        status: str | None = None,
        timer: str | None = None,
        remove: bool = False,
        _lang: dict | None = None,
        autoplay: bool | None = None,
        progress_seconds: int | None = None,
    ) -> types.InlineKeyboardMarkup:
        del user_id, status, timer, _lang
        if remove:
            return self.ikm([])

        from music import anon, queue

        media = queue.get_current(chat_id)
        autoplay_enabled = (
            anon.is_autoplay_enabled(chat_id) if autoplay is None else autoplay
        )
        autoplay_text = (
            "↻ Autoplay ON" if autoplay_enabled else "↻ Autoplay OFF"
        )
        elapsed = (
            progress_seconds
            if progress_seconds is not None
            else int(getattr(media, "time", 0) or 0)
        )
        duration = int(getattr(media, "duration_sec", 0) or 0)
        return self.ikm(
            [
                [
                    self.ikb(
                        text=self.progress_bar(elapsed, duration),
                        callback_data=f"controls status {chat_id}",
                        style=ButtonStyle.SUCCESS,
                    )
                ],
                [
                    self.ikb(
                        text=_label("▶ Play"),
                        callback_data=f"controls resume {chat_id}",
                        style=ButtonStyle.SUCCESS,
                    ),
                    self.ikb(
                        text=_label("Ⅱ Pause"),
                        callback_data=f"controls pause {chat_id}",
                        style=ButtonStyle.PRIMARY,
                    ),
                    self.ikb(
                        text=_label("↻ Loop"),
                        callback_data=f"controls loop {chat_id}",
                        style=ButtonStyle.SUCCESS,
                    ),
                    self.ikb(
                        text=_label("▸▸I Next"),
                        callback_data=f"controls next {chat_id}",
                        style=ButtonStyle.PRIMARY,
                    ),
                    self.ikb(
                        text=_label("□ Stop"),
                        callback_data=f"controls stop {chat_id}",
                        style=ButtonStyle.DANGER,
                    ),
                ],
                [
                    self.ikb(
                        text=_label("« 30s"),
                        callback_data=f"controls seek {chat_id} -30",
                        style=ButtonStyle.PRIMARY,
                    ),
                    self.ikb(
                        text=_label("« 10s"),
                        callback_data=f"controls seek {chat_id} -10",
                        style=ButtonStyle.PRIMARY,
                    ),
                    self.ikb(
                        text=_label("10s »"),
                        callback_data=f"controls seek {chat_id} 10",
                        style=ButtonStyle.PRIMARY,
                    ),
                    self.ikb(
                        text=_label("30s »"),
                        callback_data=f"controls seek {chat_id} 30",
                        style=ButtonStyle.PRIMARY,
                    ),
                ],
                [
                    self.ikb(
                        text=_label(autoplay_text),
                        callback_data=f"controls autoplay {chat_id}",
                        style=ButtonStyle.SUCCESS if autoplay_enabled else ButtonStyle.PRIMARY,
                    ),
                    self.ikb(
                        text=_label("• Rec"),
                        callback_data=f"controls rec {chat_id}",
                        style=ButtonStyle.SUCCESS,
                    ),
                ],
                [
                    self.ikb(
                        text=_label("Close"),
                        callback_data=f"controls close {chat_id}",
                        style=ButtonStyle.DANGER,
                    ),
                ],
            ]
        )

    def help_markup(
        self, _lang: dict, back: bool = False, user_id: int = 0
    ) -> types.InlineKeyboardMarkup:
        del user_id
        if back:
            rows = [
                [
                    self.ikb(
                        text=_lang.get("back", "Back"),
                        callback_data="help back",
                        style=ButtonStyle.PRIMARY,
                    )
                ]
            ]
        else:
            commands = ("admins", "auth", "blist", "lang", "ping", "play", "queue", "stats", "sudo")
            buttons = [
                self.ikb(
                    text=_lang.get(f"help_{index}", command.capitalize()),
                    callback_data=f"help {command}",
                    style=ButtonStyle.PRIMARY,
                )
                for index, command in enumerate(commands)
            ]
            rows = [buttons[index : index + 3] for index in range(0, len(buttons), 3)]
            rows.append(
                [
                    self.ikb(
                        text=_lang.get("back", "Back"),
                        callback_data="settings_back_helper",
                        style=ButtonStyle.PRIMARY,
                    )
                ]
            )
        return self.ikm(rows)

    def lang_markup(self, current: str) -> types.InlineKeyboardMarkup:
        available = lang.get_languages()
        buttons = [
            self.ikb(
                text=f"{name} ({code}) {'✓' if code == current else ''}",
                callback_data=f"lang_change {code}",
            )
            for code, name in available.items()
        ]
        rows = [buttons[index : index + 2] for index in range(0, len(buttons), 2)]
        return self.ikm(rows)

    def ping_markup(self, text: str) -> types.InlineKeyboardMarkup:
        return self.ikm([[self.ikb(text=text, url=_support_url())]])

    def play_queued(
        self, chat_id: int, item_id: str, text: str
    ) -> types.InlineKeyboardMarkup:
        return self.ikm(
            [
                [
                    self.ikb(
                        text=text,
                        callback_data=f"controls force {chat_id} {item_id}",
                        style=ButtonStyle.SUCCESS,
                    )
                ]
            ]
        )

    @staticmethod
    def _progress_clock(seconds: int) -> str:
        seconds = max(0, int(seconds))
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        if hours:
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        return f"{minutes:02d}:{seconds:02d}"

    @classmethod
    def progress_bar(
        cls, elapsed_seconds: int, duration_seconds: int, segments: int = 10
    ) -> str:
        """Render a bounded half-step progress indicator for the player button."""
        segments = max(4, min(16, int(segments)))
        duration = max(0, int(duration_seconds or 0))
        elapsed = max(0, int(elapsed_seconds or 0))
        if duration:
            elapsed = min(elapsed, duration)
            units = elapsed / duration * segments
            full = min(segments, int(units))
            fraction = units - full
            if elapsed >= duration:
                full, partial = segments, False
            elif full == segments - 1:
                # Keep the last cell visibly half-filled until playback ends.
                partial = elapsed > 0
            elif fraction >= 0.5:
                full += 1
                partial = False
            else:
                partial = fraction > 0 or (full == 0 and elapsed > 0)
        else:
            elapsed, full, partial = 0, 0, False

        bar = "▰" * full
        if partial and full < segments:
            bar += "◧"
        bar += "▱" * (segments - full - int(partial))
        return (
            f"{cls._progress_clock(elapsed)} {bar} "
            f"{cls._progress_clock(duration)}"
        )

    def queue_markup(
        self, chat_id: int, text: str, playing: bool
    ) -> types.InlineKeyboardMarkup:
        action = "pause" if playing else "resume"
        return self.ikm(
            [
                [
                    self.ikb(
                        text=text,
                        callback_data=f"controls {action} {chat_id} q",
                        style=ButtonStyle.SUCCESS,
                    )
                ]
            ]
        )

    def settings_markup(
        self,
        language: dict,
        admin_only: bool,
        cmd_delete: bool,
        selected_language: str,
        chat_id: int,
    ) -> types.InlineKeyboardMarkup:
        play_mode_status = (
            language.get("enabled", "Enabled")
            if admin_only
            else language.get("disabled", "Disabled")
        )
        delete_status = (
            language.get("enabled", "Enabled")
            if cmd_delete
            else language.get("disabled", "Disabled")
        )
        return self.ikm(
            [
                [
                    self.ikb(
                        text=language["play_mode"] + " ›",
                        callback_data="settings",
                    ),
                    self.ikb(text=play_mode_status, callback_data="settings play"),
                ],
                [
                    self.ikb(
                        text=language["cmd_delete"] + " ›",
                        callback_data="settings",
                    ),
                    self.ikb(text=delete_status, callback_data="settings delete"),
                ],
                [
                    self.ikb(
                        text=language["language"] + " ›",
                        callback_data="settings",
                    ),
                    self.ikb(
                        text=lang.lang_codes.get(selected_language, selected_language),
                        callback_data="language",
                    ),
                ],
            ]
        )

    def start_key(
        self, language: dict, private: bool = False
    ) -> types.InlineKeyboardMarkup:
        rows = [
            [
                self.ikb(
                    text="Official Group",
                    url=_official_group_url(),
                    style=ButtonStyle.SUCCESS,
                )
            ],
            [
                self.ikb(
                    text=f"Support @{_support_url().rsplit('/', 1)[-1]}",
                    url=_support_url(),
                    style=ButtonStyle.SUCCESS,
                )
            ],
        ]
        owner_url = _owner_url()
        if owner_url:
            rows.append(
                [
                    self.ikb(
                        text=f"Owner @{owner_url.rsplit('/', 1)[-1]}",
                        url=owner_url,
                        style=ButtonStyle.PRIMARY,
                    )
                ]
            )
        rows.append(
            [
                self.ikb(
                    text="Updates Channel",
                    url=_updates_url(),
                    style=ButtonStyle.SUCCESS,
                )
            ]
        )
        if not private:
            rows.append(
                [
                    self.ikb(
                        text=language.get("language", "Language"),
                        callback_data="language",
                    )
                ]
            )
        return self.ikm(rows)

    def yt_key(self, link: str) -> types.InlineKeyboardMarkup:
        return self.ikm(
            [
                [
                    self.ikb(text="Copy link", copy_text=link),
                    self.ikb(text="Open on YouTube", url=link),
                ]
            ]
        )
