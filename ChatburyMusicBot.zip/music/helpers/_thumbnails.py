# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
#ALONE-CODER

import asyncio
import colorsys
import hashlib
import html
import logging
import math
import re
from io import BytesIO
from pathlib import Path

import aiohttp
from PIL import (
    Image,
    ImageChops,
    ImageDraw,
    ImageEnhance,
    ImageFilter,
    ImageFont,
    ImageOps,
)

from music import config
from music.helpers import Track

LOGGER = logging.getLogger("eiko.music.thumbnail")
DESIGN_SIZE = (1280, 720)
DEFAULT_OUTPUT_SIZE = (1024, 576)


class Thumbnail:
    def __init__(self):
        helper_dir = Path(__file__).resolve().parent
        self.bold_font = helper_dir / "Raleway-Bold.ttf"
        self.light_font = helper_dir / "Inter-Light.ttf"

    async def save_thumb(self, output_path: str, url: str) -> str:
        timeout = aiohttp.ClientTimeout(total=20)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as response:
                response.raise_for_status()
                Path(output_path).write_bytes(await response.read())
        return output_path

    @staticmethod
    def _accent(cover: Image.Image) -> tuple[int, int, int]:
        """Pick a saturated color from the artwork for the card's highlights."""
        sample = cover.convert("RGB").resize((96, 96), Image.Resampling.LANCZOS)
        quantized = sample.quantize(colors=12, method=Image.Quantize.MEDIANCUT)
        palette = quantized.getpalette()
        colors = sorted(quantized.getcolors(96 * 96) or [], reverse=True)
        selected = None
        for _, index in colors:
            start = index * 3
            rgb = tuple(palette[start : start + 3])
            _, saturation, value = colorsys.rgb_to_hsv(
                *(component / 255 for component in rgb)
            )
            if saturation >= 0.28 and value >= 0.18:
                selected = rgb
                break
        if selected is None and colors:
            _, index = colors[0]
            start = index * 3
            selected = tuple(palette[start : start + 3])
        if selected is None:
            selected = (164, 74, 255)

        hue, saturation, value = colorsys.rgb_to_hsv(
            *(component / 255 for component in selected)
        )
        return tuple(
            round(component * 255)
            for component in colorsys.hsv_to_rgb(
                hue, max(0.55, saturation), max(0.88, value)
            )
        )

    def _font(self, *, bold: bool, size: int) -> ImageFont.FreeTypeFont:
        return ImageFont.truetype(self.bold_font if bold else self.light_font, size)

    @staticmethod
    def _fit_text(draw: ImageDraw.ImageDraw, text: str, font, width: int) -> str:
        text = str(text or "")
        if draw.textlength(text, font=font) <= width:
            return text
        while text and draw.textlength(text + "…", font=font) > width:
            text = text[:-1]
        return text.rstrip() + "…"

    @staticmethod
    def _raised_text(
        draw: ImageDraw.ImageDraw,
        position: tuple[float, float],
        text: str,
        font: ImageFont.FreeTypeFont,
        fill: tuple[int, int, int, int],
    ) -> None:
        """Give player-card labels a small raised-metal edge and soft depth."""
        x, y = position
        draw.text(
            (x + 2, y + 2),
            text,
            font=font,
            fill=(0, 0, 0, 165),
        )
        draw.text(
            (x, y),
            text,
            font=font,
            fill=fill,
        )

    @staticmethod
    def _glass_button(
        canvas: Image.Image,
        box: tuple[int, int, int, int],
        accent: tuple[int, int, int],
        radius: int = 15,
    ) -> None:
        """Paint a softly beveled glass control with a thumbnail-matched glow."""
        x1, y1, x2, y2 = box
        width, height = x2 - x1, y2 - y1
        glow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
        ImageDraw.Draw(glow).rounded_rectangle(
            (x1 - 3, y1 + 2, x2 + 3, y2 + 7),
            radius=radius + 4,
            fill=(*accent, 112),
        )
        canvas.alpha_composite(glow.filter(ImageFilter.GaussianBlur(13)))

        face = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        pixels = face.load()
        for row in range(height):
            amount = 0.12 + 0.10 * (1 - row / max(1, height - 1))
            alpha = 224 - int(22 * row / max(1, height - 1))
            color = tuple(
                round(base * (1 - amount) + component * amount)
                for base, component in zip((9, 7, 20), accent)
            )
            for column in range(width):
                pixels[column, row] = (*color, alpha)
        mask = Image.new("L", (width, height), 0)
        ImageDraw.Draw(mask).rounded_rectangle(
            (0, 0, width - 1, height - 1), radius=radius, fill=255
        )
        canvas.paste(face, (x1, y1), mask)

        draw = ImageDraw.Draw(canvas, "RGBA")
        draw.rounded_rectangle(
            box, radius=radius, outline=(*accent, 235), width=2
        )
        draw.line(
            (x1 + radius, y1 + 3, x2 - radius, y1 + 3),
            fill=(255, 255, 255, 95),
            width=2,
        )

    @staticmethod
    def _clean_text(value: object, limit: int = 100) -> str:
        text = html.unescape(re.sub(r"<[^>]*>", "", str(value or "")))
        return " ".join(text.split())[:limit]

    @staticmethod
    def _avatar(size: tuple[int, int] = (258, 258)) -> Image.Image | None:
        """Load the owner's supplied profile image for the player identity panel."""
        avatar_path = Path(str(getattr(config, "START_IMG", "")))
        if not avatar_path.is_file():
            return None
        try:
            with Image.open(avatar_path) as source:
                return ImageOps.fit(
                    source.convert("RGB"),
                    size,
                    method=Image.Resampling.LANCZOS,
                    centering=(0.66, 0.42),
                )
        except Exception as exc:
            LOGGER.warning("Could not load the player avatar (%s).", type(exc).__name__)
            return None

    @staticmethod
    def _duration_seconds(song: Track) -> int:
        try:
            seconds = int(getattr(song, "duration_sec", 0) or 0)
            if seconds > 0:
                return seconds
        except (TypeError, ValueError):
            pass

        value = str(getattr(song, "duration", "") or "")
        try:
            parts = [int(part) for part in value.split(":")]
        except ValueError:
            return 0
        if not parts or len(parts) > 3 or any(part < 0 for part in parts):
            return 0
        seconds = 0
        for part in parts:
            seconds = seconds * 60 + part
        return seconds

    @staticmethod
    def _format_time(seconds: int) -> str:
        seconds = max(0, int(seconds))
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        if hours:
            return f"{hours}:{minutes:02d}:{seconds:02d}"
        return f"{minutes:02d}:{seconds:02d}"

    def _compose(
        self,
        song: Track,
        cover: Image.Image,
        size: tuple[int, int],
        position: int | None = None,
    ) -> Image.Image:
        requested_size = tuple(int(value) for value in size)
        if len(requested_size) != 2 or any(value <= 0 for value in requested_size):
            raise ValueError("Player card dimensions must be positive.")
        if requested_size != DESIGN_SIZE:
            design = self._compose(song, cover, DESIGN_SIZE, position)
            fitted = ImageOps.contain(
                design,
                requested_size,
                method=Image.Resampling.LANCZOS,
            )
            output = Image.new("RGB", requested_size, (7, 5, 16))
            output.paste(
                fitted,
                (
                    (requested_size[0] - fitted.width) // 2,
                    (requested_size[1] - fitted.height) // 2,
                ),
            )
            return output

        width, height = DESIGN_SIZE
        cover = cover.convert("RGB")
        accent = self._accent(cover)
        accent_light = tuple(min(255, int(channel * 0.60 + 102)) for channel in accent)

        # Blur the same artwork into a dark, full-bleed background.
        backdrop = ImageOps.fit(
            cover, size, method=Image.Resampling.LANCZOS, centering=(0.5, 0.5)
        )
        backdrop = ImageEnhance.Brightness(
            backdrop.filter(ImageFilter.GaussianBlur(38))
        ).enhance(0.48)
        canvas = backdrop.convert("RGBA")

        glow = Image.new("RGBA", size, (0, 0, 0, 0))
        glow_draw = ImageDraw.Draw(glow)
        glow_draw.ellipse(
            (-width // 3, -height // 2, width // 2, height + height // 2),
            fill=(*accent, 72),
        )
        glow_draw.ellipse(
            (width // 2, -height // 3, width + width // 3, height),
            fill=(*accent_light, 45),
        )
        canvas.alpha_composite(glow.filter(ImageFilter.GaussianBlur(90)))

        panel_shadow = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(panel_shadow).rounded_rectangle(
            (19, 18, width - 19, height - 18),
            radius=42,
            fill=(0, 0, 0, 170),
        )
        canvas.alpha_composite(panel_shadow.filter(ImageFilter.GaussianBlur(18)))

        panel = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(panel).rounded_rectangle(
            (26, 26, width - 26, height - 26),
            radius=38,
            fill=(6, 5, 16, 154),
            outline=(*accent, 205),
            width=3,
        )
        ImageDraw.Draw(panel).line(
            (72, 29, width - 72, 29), fill=(255, 255, 255, 58), width=2
        )
        canvas.alpha_composite(panel)

        draw = ImageDraw.Draw(canvas, "RGBA")
        left = 390
        draw.line((left, 72, left, height - 72), fill=(*accent, 110), width=2)

        # The supplied portrait replaces the former center logo in the player identity.
        shadow = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(shadow).ellipse((62, 74, 354, 374), fill=(0, 0, 0, 150))
        canvas.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(22)))
        draw = ImageDraw.Draw(canvas, "RGBA")
        cx, cy = 208, 222
        draw.ellipse(
            (cx - 134, cy - 134, cx + 134, cy + 134),
            fill=(8, 8, 18, 242),
            outline=(*accent_light, 225),
            width=4,
        )
        for radius in (120, 112, 101):
            draw.ellipse(
                (cx - radius, cy - radius, cx + radius, cy + radius),
                outline=(*accent, 115),
                width=2,
            )
        avatar_size = 248
        avatar = self._avatar((avatar_size, avatar_size))
        if avatar is not None:
            avatar = avatar.convert("RGBA")
            avatar_mask = Image.new("L", (avatar_size, avatar_size), 0)
            ImageDraw.Draw(avatar_mask).ellipse(
                (1, 1, avatar_size - 2, avatar_size - 2), fill=255
            )
            canvas.paste(
                avatar,
                (cx - avatar_size // 2, cy - avatar_size // 2),
                avatar_mask,
            )
        else:
            draw.ellipse(
                (cx - 112, cy - 112, cx + 112, cy + 112),
                fill=(10, 8, 25, 245),
            )
            for radius in (88, 67, 46):
                draw.ellipse(
                    (cx - radius, cy - radius, cx + radius, cy + radius),
                    outline=(*accent, 150),
                    width=3,
                )
            draw.text(
                (cx - 18, cy - 25),
                "♫",
                font=self._font(bold=True, size=52),
                fill=(*accent_light, 255),
            )
        draw = ImageDraw.Draw(canvas, "RGBA")
        draw.ellipse(
            (cx - 128, cy - 128, cx + 128, cy + 128),
            outline=(*accent_light, 245),
            width=4,
        )

        badge_glow = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(badge_glow).ellipse(
            (278, 297, 351, 370), fill=(*accent, 205)
        )
        canvas.alpha_composite(badge_glow.filter(ImageFilter.GaussianBlur(13)))
        draw = ImageDraw.Draw(canvas, "RGBA")
        draw.ellipse(
            (284, 303, 346, 365),
            fill=(8, 6, 19, 246),
            outline=(*accent_light, 255),
            width=3,
        )
        draw.ellipse(
            (290, 309, 340, 359),
            outline=(*accent, 200),
            width=2,
        )
        # Draw the note from vector strokes so it renders even when the selected
        # font lacks a music-note glyph.
        draw.ellipse((302, 337, 313, 348), fill=(*accent_light, 255))
        draw.ellipse((318, 332, 329, 343), fill=(*accent_light, 255))
        draw.line((310, 340, 310, 317), fill=(*accent_light, 255), width=4)
        draw.line((326, 335, 326, 312), fill=(*accent_light, 255), width=4)
        draw.line((310, 317, 326, 312), fill=(*accent_light, 255), width=4)

        label_font = self._font(bold=True, size=17)
        label = self._fit_text(
            draw,
            str(getattr(config, "BOT_USERNAME", "@IllusionMusicBot") or "@IllusionMusicBot"),
            label_font,
            left - 60,
        )
        label_box = draw.textbbox((0, 0), label, font=label_font)
        draw.text(
            ((left - (label_box[2] - label_box[0])) / 2, 389),
            label,
            font=label_font,
            fill=(248, 245, 255, 255),
        )
        tagline_font = self._font(bold=False, size=14)
        tagline = self._fit_text(
            draw, "PLAY  •  VIBE  •  REPEAT", tagline_font, left - 60
        )
        tagline_box = draw.textbbox((0, 0), tagline, font=tagline_font)
        draw.text(
            ((left - (tagline_box[2] - tagline_box[0])) / 2, 422),
            tagline,
            font=tagline_font,
            fill=(*accent_light, 235),
        )
        draw.line((78, 455, 338, 455), fill=(*accent, 130), width=2)
        for index, (label, symbol) in enumerate(
            (("HD", "HI-FI"), ("♫", "PLAY"), ("⚡", "FAST"), ("∞", "24/7"))
        ):
            x = 68 + index * 78
            draw.rounded_rectangle(
                (x, 470, x + 68, 526),
                radius=13,
                fill=(7, 5, 20, 186),
                outline=(*accent, 172),
                width=2,
            )
            symbol_font = self._font(bold=True, size=19)
            symbol_box = draw.textbbox((0, 0), symbol, font=symbol_font)
            draw.text(
                (x + (68 - (symbol_box[2] - symbol_box[0])) / 2, 475),
                symbol,
                font=symbol_font,
                fill=(*accent_light, 255),
            )
            small = self._fit_text(draw, label, self._font(bold=True, size=8), 60)
            small_box = draw.textbbox(
                (0, 0), small, font=self._font(bold=True, size=8)
            )
            draw.text(
                (x + (68 - (small_box[2] - small_box[0])) / 2, 507),
                small,
                font=self._font(bold=True, size=8),
                fill=(238, 232, 248, 245),
            )
        # Flowing equalizer motif; its neon colors come from this track's artwork.
        wave_points = [
            (
                76 + step,
                637
                + 7 * math.sin(step * 0.037)
                + 3 * math.sin(step * 0.091 + 1.2),
            )
            for step in range(264)
        ]
        wave_glow = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(wave_glow).line(
            wave_points, fill=(*accent, 205), width=12, joint="curve"
        )
        canvas.alpha_composite(wave_glow.filter(ImageFilter.GaussianBlur(11)))
        draw = ImageDraw.Draw(canvas, "RGBA")
        for start, end in zip(wave_points, wave_points[1:]):
            mix = max(0.0, min(1.0, (start[0] - 76) / 264))
            color = tuple(
                round(first * (1 - mix) + second * mix)
                for first, second in zip(accent, accent_light)
            )
            draw.line((start, end), fill=(*color, 250), width=3)

        for index in range(34):
            x = 73 + index * 8
            energy = (
                0.42
                + 0.31 * abs(math.sin(index * 0.43 + 0.6))
                + 0.25 * abs(math.sin(index * 0.17 + 2.1))
            )
            bar_height = 8 + int(42 * min(1.0, energy))
            mix = index / 33
            color = tuple(
                round(first * (1 - mix) + second * mix)
                for first, second in zip(accent, accent_light)
            )
            draw.rounded_rectangle(
                (x, 644 - bar_height, x + 5, 644),
                radius=3,
                fill=(*color, 242),
            )
            draw.line(
                (x + 1, 646 - bar_height, x + 1, 640),
                fill=(255, 255, 255, 92),
                width=1,
            )

        # Right-side artwork tile, title, artist/requester, and seek line.
        # A 16:9 viewport lets standard YouTube thumbnails fit without the
        # severe vertical crop caused by the former ultra-wide tile.
        art_box = (438, 70, width - 70, 504)
        art_size = (art_box[2] - art_box[0], art_box[3] - art_box[1])
        art_shadow = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(art_shadow).rounded_rectangle(
            (art_box[0] - 5, art_box[1] + 5, art_box[2] + 7, art_box[3] + 12),
            radius=28,
            fill=(0, 0, 0, 170),
        )
        canvas.alpha_composite(art_shadow.filter(ImageFilter.GaussianBlur(16)))
        draw = ImageDraw.Draw(canvas, "RGBA")
        draw.rounded_rectangle(
            (
                art_box[0] + 3,
                art_box[1] + 6,
                art_box[2] + 6,
                art_box[3] + 9,
            ),
            radius=27,
            fill=(7, 5, 18, 255),
            outline=(*accent, 210),
            width=3,
        )
        # Keep the complete source artwork visible. For non-16:9 images, softly
        # blurred edge fill replaces cropping while the sharp cover stays centered.
        art_background = ImageOps.fit(
            cover,
            art_size,
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )
        art_background = ImageEnhance.Brightness(
            art_background.filter(ImageFilter.GaussianBlur(20))
        ).enhance(0.42)
        art = art_background.convert("RGBA")
        fitted_cover = ImageOps.contain(
            cover, art_size, method=Image.Resampling.LANCZOS
        )
        art.paste(
            fitted_cover,
            (
                (art_size[0] - fitted_cover.width) // 2,
                (art_size[1] - fitted_cover.height) // 2,
            ),
        )
        art_mask = Image.new("L", art_size, 0)
        ImageDraw.Draw(art_mask).rounded_rectangle(
            (0, 0, art_size[0] - 1, art_size[1] - 1), radius=24, fill=255
        )
        canvas.paste(art, (art_box[0], art_box[1]), art_mask)
        glass_sheen = Image.new("RGBA", art_size, (0, 0, 0, 0))
        sheen_draw = ImageDraw.Draw(glass_sheen, "RGBA")
        sheen_draw.polygon(
            (
                (0, 0),
                (art_size[0], 0),
                (art_size[0], 34),
                (0, 86),
            ),
            fill=(255, 255, 255, 16),
        )
        sheen_mask = Image.new("L", art_size, 0)
        ImageDraw.Draw(sheen_mask).rounded_rectangle(
            (0, 0, art_size[0] - 1, art_size[1] - 1), radius=24, fill=255
        )
        glass_sheen.putalpha(
            ImageChops.multiply(glass_sheen.getchannel("A"), sheen_mask)
        )
        canvas.alpha_composite(glass_sheen, dest=(art_box[0], art_box[1]))
        draw = ImageDraw.Draw(canvas, "RGBA")
        draw.rounded_rectangle(
            art_box, radius=24, outline=(*accent_light, 235), width=3
        )
        draw.rounded_rectangle(
            (art_box[0] + 5, art_box[1] + 5, art_box[2] - 5, art_box[3] - 5),
            radius=20,
            outline=(255, 255, 255, 34),
            width=1,
        )
        draw.line(
            (art_box[0] + 34, art_box[1] + 3, art_box[2] - 34, art_box[1] + 3),
            fill=(255, 255, 255, 105),
            width=2,
        )
        draw.line(
            (art_box[0] + 34, art_box[3] - 3, art_box[2] - 34, art_box[3] - 3),
            fill=(0, 0, 0, 170),
            width=3,
        )

        badge_font = self._font(bold=True, size=16)
        badge_text = "NOW PLAYING"
        badge_box = draw.textbbox((0, 0), badge_text, font=badge_font)
        badge_width = badge_box[2] - badge_box[0] + 38
        badge_x = art_box[2] - badge_width - 20
        draw.rounded_rectangle(
            (badge_x, art_box[1] + 18, badge_x + badge_width, art_box[1] + 54),
            radius=18,
            fill=(5, 5, 12, 220),
            outline=(*accent_light, 240),
            width=2,
        )
        draw.text(
            (badge_x + 19, art_box[1] + 27),
            badge_text,
            font=badge_font,
            fill=(255, 255, 255, 255),
        )

        title_font = self._font(bold=True, size=31)
        meta_font = self._font(bold=False, size=19)
        label_font = self._font(bold=True, size=13)
        title = self._clean_text(getattr(song, "title", "Unknown track"), 140)
        title = self._fit_text(draw, title, title_font, art_box[2] - art_box[0])
        self._raised_text(draw, (442, 513), title, title_font, (255, 255, 255, 255))

        artist = self._fit_text(
            draw,
            self._clean_text(
                getattr(song, "artist", None)
                or getattr(song, "channel_name", None)
                or "YouTube",
                90,
            ),
            meta_font,
            art_box[2] - 442,
        )
        requester = self._clean_text(getattr(song, "user", None) or "Listener", 70)
        duration = self._clean_text(getattr(song, "duration", None) or "00:00", 20)
        self._raised_text(draw, (444, 551), artist, meta_font, (*accent_light, 255))
        self._raised_text(
            draw,
            (444, 579),
            self._fit_text(
                draw,
                f"REQUESTED BY  {requester}",
                label_font,
                art_box[2] - 442,
            ),
            label_font,
            (235, 232, 244, 255),
        )

        duration_seconds = self._duration_seconds(song)
        elapsed = max(
            0,
            int(position if position is not None else getattr(song, "time", 0) or 0),
        )
        if duration_seconds:
            elapsed = min(elapsed, duration_seconds)
            progress_fraction = elapsed / duration_seconds
        else:
            progress_fraction = 0.0

        progress_y = 598
        track_end = width - 102
        progress_width = track_end - 455
        progress_x = 455 + int(progress_width * progress_fraction)
        draw.rounded_rectangle(
            (455, progress_y, track_end, progress_y + 7),
            radius=4,
            fill=(132, 127, 149, 185),
        )
        draw.rounded_rectangle(
            (455, progress_y, progress_x, progress_y + 7),
            radius=4,
            fill=(*accent, 255),
        )
        draw.ellipse(
            (progress_x - 8, progress_y - 5, progress_x + 8, progress_y + 11),
            fill=(*accent_light, 255),
        )
        draw.text(
            (455, 612),
            self._format_time(elapsed),
            font=label_font,
            fill=(235, 232, 242, 255),
        )
        draw.text(
            (width - 151, 612),
            self._format_time(duration_seconds) if duration_seconds else duration,
            font=label_font,
            fill=(235, 232, 242, 255),
        )

        # Decorative glass controls echo the functional Telegram buttons below the photo.
        center_x = (art_box[0] + art_box[2]) // 2
        icon_y = 628
        control_centers = (
            center_x - 280,
            center_x - 140,
            center_x,
            center_x + 140,
            center_x + 280,
        )
        control_specs = (
            ("pause", "PAUSE"),
            ("loop", "LOOP"),
            ("play", "PLAY"),
            ("next", "NEXT"),
            ("stop", "STOP"),
        )
        for x, (shape, label) in zip(control_centers, control_specs):
            if shape == "play":
                halo = Image.new("RGBA", size, (0, 0, 0, 0))
                ImageDraw.Draw(halo).ellipse(
                    (x - 40, icon_y - 6, x + 40, icon_y + 52),
                    fill=(*accent, 180),
                )
                canvas.alpha_composite(halo.filter(ImageFilter.GaussianBlur(15)))
                draw = ImageDraw.Draw(canvas, "RGBA")
                draw.ellipse(
                    (x - 29, icon_y - 2, x + 29, icon_y + 46),
                    fill=(*accent, 230),
                    outline=(*accent_light, 255),
                    width=3,
                )
                draw.ellipse(
                    (x - 23, icon_y + 4, x + 23, icon_y + 40),
                    fill=(10, 5, 23, 248),
                    outline=(*accent_light, 180),
                    width=2,
                )
                draw.polygon(
                    ((x - 7, icon_y + 11), (x - 7, icon_y + 33), (x + 12, icon_y + 22)),
                    fill=(255, 255, 255, 255),
                )
            else:
                self._glass_button(
                    canvas,
                    (x - 36, icon_y, x + 36, icon_y + 44),
                    accent,
                    radius=14,
                )
                draw = ImageDraw.Draw(canvas, "RGBA")
                icon_color = (*accent_light, 255)
                cy = icon_y + 22
                if shape == "pause":
                    draw.rounded_rectangle(
                        (x - 11, cy - 12, x - 4, cy + 12),
                        radius=3,
                        fill=icon_color,
                    )
                    draw.rounded_rectangle(
                        (x + 4, cy - 12, x + 11, cy + 12),
                        radius=3,
                        fill=icon_color,
                    )
                elif shape == "shuffle":
                    draw.line((x - 15, cy - 8, x + 14, cy - 8), fill=icon_color, width=3)
                    draw.line((x - 15, cy + 8, x + 14, cy + 8), fill=icon_color, width=3)
                    draw.line((x - 7, cy - 8, x + 5, cy + 8), fill=icon_color, width=3)
                    draw.polygon(
                        ((x + 16, cy - 8), (x + 7, cy - 15), (x + 7, cy - 1)),
                        fill=icon_color,
                    )
                    draw.polygon(
                        ((x + 16, cy + 8), (x + 7, cy + 1), (x + 7, cy + 15)),
                        fill=icon_color,
                    )
                elif shape == "previous":
                    draw.line((x + 11, cy - 12, x + 11, cy + 12), fill=icon_color, width=3)
                    draw.polygon(
                        ((x - 13, cy), (x + 5, cy - 12), (x + 5, cy + 12)),
                        fill=icon_color,
                    )
                elif shape == "next":
                    draw.polygon(
                        ((x - 13, cy - 12), (x - 1, cy), (x - 13, cy + 12)),
                        fill=icon_color,
                    )
                    draw.polygon(
                        ((x - 1, cy - 12), (x + 11, cy), (x - 1, cy + 12)),
                        fill=icon_color,
                    )
                    draw.line((x + 15, cy - 12, x + 15, cy + 12), fill=icon_color, width=3)
                elif shape == "stop":
                    draw.rounded_rectangle(
                        (x - 10, cy - 10, x + 10, cy + 10),
                        radius=3,
                        fill=icon_color,
                    )
                elif shape == "loop":
                    draw.arc(
                        (x - 16, cy - 12, x + 16, cy + 12),
                        start=35,
                        end=320,
                        fill=icon_color,
                        width=3,
                    )
                    draw.polygon(
                        ((x + 13, cy - 10), (x + 2, cy - 11), (x + 11, cy - 2)),
                        fill=icon_color,
                    )

            small_font = self._font(bold=True, size=9)
            small_box = draw.textbbox((0, 0), label, font=small_font)
            self._raised_text(
                draw,
                (x - (small_box[2] - small_box[0]) / 2, 675),
                label,
                small_font,
                (238, 235, 245, 255),
            )
        return canvas.convert("RGB")

    async def generate(
        self,
        song: Track,
        size: tuple[int, int] = DEFAULT_OUTPUT_SIZE,
        position: int | None = None,
    ) -> str:
        cache_dir = Path("cache")
        cache_dir.mkdir(parents=True, exist_ok=True)
        safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(song.id))[:100] or "track"
        output_size = tuple(int(value) for value in size)
        if len(output_size) != 2 or any(value <= 0 for value in output_size):
            raise ValueError("Player card dimensions must be positive.")
        current_position = max(
            0,
            int(position if position is not None else getattr(song, "time", 0) or 0),
        )
        cache_identity = "|".join(
            (
                safe_id,
                str(current_position),
                str(getattr(song, "title", "") or ""),
                str(getattr(song, "artist", "") or ""),
                str(getattr(song, "channel_name", "") or ""),
                str(getattr(song, "user", "") or ""),
                f"{output_size[0]}x{output_size[1]}",
            )
        )
        output_key = hashlib.sha256(cache_identity.encode("utf-8")).hexdigest()[:16]
        output = cache_dir / f"priksha_player_v7_{safe_id}_{output_key}.png"
        if output.exists():
            return str(output)

        try:
            if not song.thumbnail:
                return config.DEFAULT_THUMB
            thumbnail_url = str(song.thumbnail)
            source_hash = hashlib.sha256(thumbnail_url.encode("utf-8")).hexdigest()[:24]
            source_path = cache_dir / f"priksha_cover_{source_hash}.img"
            if source_path.is_file() and source_path.stat().st_size <= 8_000_000:
                content = source_path.read_bytes()
            else:
                timeout = aiohttp.ClientTimeout(total=20)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get(thumbnail_url) as response:
                        response.raise_for_status()
                        if response.content_length and response.content_length > 8_000_000:
                            raise ValueError("Artwork exceeds size limit.")
                        content = await response.read()
                if len(content) > 8_000_000:
                    raise ValueError("Artwork exceeds size limit.")
            with Image.open(BytesIO(content)) as source:
                rendered = await asyncio.to_thread(
                    self._compose, song, source, output_size, current_position
                )
            if not source_path.exists():
                source_path.write_bytes(content)
            await asyncio.to_thread(
                rendered.save,
                output,
                format="PNG",
                optimize=False,
                compress_level=2,
            )
            return str(output)
        except Exception as exc:
            LOGGER.warning(
                "Could not render the now-playing card (%s).", type(exc).__name__
            )
            return config.DEFAULT_THUMB
