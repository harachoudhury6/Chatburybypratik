# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
#ALONE-CODER

import asyncio
import random
import re

from pyrogram import enums, errors, types
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from music import anon, app, config, db, logger, queue, userbot, yt
from music.helpers import utils


async def _unauthorized_reply(message: types.Message) -> None:
    owner = None
    admins = []
    try:
        members = [
            member
            async for member in app.get_chat_members(
                message.chat.id, filter=enums.ChatMembersFilter.ADMINISTRATORS
            )
            if not member.user.is_bot
        ]
        owner_member = next(
            (member for member in members if member.status == enums.ChatMemberStatus.OWNER),
            None,
        )
        if owner_member and owner_member.user.username:
            owner = owner_member.user.username
        admins = [
            member.user.username
            for member in members
            if member.status == enums.ChatMemberStatus.ADMINISTRATOR
            and member.user.username
            and re.fullmatch(r"[A-Za-z0-9_]{5,32}", member.user.username)
        ]
    except Exception as exc:
        logger.warning("Could not fetch group contacts for music authorization (%s).", type(exc).__name__)

    buttons = []
    if owner and re.fullmatch(r"[A-Za-z0-9_]{5,32}", owner):
        buttons.append(
            InlineKeyboardButton("Contact group owner", url=f"https://t.me/{owner}")
        )
    if admins:
        username = random.choice(admins)
        buttons.append(
            InlineKeyboardButton("Contact a group admin", url=f"https://t.me/{username}")
        )
    if not buttons:
        buttons.append(
            InlineKeyboardButton("Contact support", url="https://t.me/tgnxt")
        )

    await message.reply_text(
        "You are not authorized by this group’s owner/admin to use music. "
        "Ask a group admin to reply to your message with /auth.",
        reply_markup=InlineKeyboardMarkup([buttons]),
    )


async def _music_access_allowed(
    chat_id: int, user_id: int, *, is_group_admin: bool = False
) -> bool:
    if is_group_admin or user_id in app.sudoers:
        return True
    return await db.is_auth(chat_id, user_id)


def checkUB(play):
    async def wrapper(_, m: types.Message):
        if not m.from_user:
            return await m.reply_text(m.lang["play_user_invalid"])
        if not userbot.clients or not anon.clients or len(userbot.clients) != len(anon.clients):
            return await m.reply_text(
                "Music playback is not ready. The owner must connect the music account with /login."
            )

        chat_id = m.chat.id
        if m.chat.type != enums.ChatType.SUPERGROUP:
            await m.reply_text(m.lang["play_chat_invalid"])
            return await app.leave_chat(chat_id)

        if not m.reply_to_message and (
            len(m.command) < 2 or (len(m.command) == 2 and m.command[1] == "-f")
        ):
            return await m.reply_text(m.lang["play_usage"])

        if len(queue.get_queue(chat_id)) >= config.QUEUE_LIMIT:
            return await m.reply_text(m.lang["play_queue_full"].format(config.QUEUE_LIMIT))

        force = m.command[0].endswith("force") or (
            len(m.command) > 1 and "-f" in m.command[1]
        )
        video = m.command[0][0] == "v" and config.VIDEO_PLAY
        url = utils.get_url(m)
        m3u8 = url and not yt.valid(url)

        try:
            # Re-fetch current admins for every play request so a demoted admin
            # cannot keep access through a stale cache. /reload also refreshes
            # the shared cache used by player controls.
            adminlist = await db.get_admins(chat_id, reload=True)
            is_group_admin = m.from_user.id in adminlist
            if not is_group_admin:
                current_member = await app.get_chat_member(chat_id, m.from_user.id)
                is_group_admin = current_member.status in (
                    enums.ChatMemberStatus.ADMINISTRATOR,
                    enums.ChatMemberStatus.OWNER,
                )
            if not await _music_access_allowed(
                chat_id, m.from_user.id, is_group_admin=is_group_admin
            ):
                return await _unauthorized_reply(m)
        except errors.FloodWait as exc:
            return await m.reply_text(
                f"Telegram is rate-limiting this check. Please retry in {exc.value} seconds."
            )
        except Exception as exc:
            logger.warning("Could not check music permissions (%s).", type(exc).__name__)
            return await m.reply_text(
                "Music permissions could not be checked because the database or Telegram is temporarily unavailable."
            )

        if chat_id not in db.active_calls:
            try:
                client = await db.get_client(chat_id)
            except Exception as exc:
                logger.warning("Could not select the music assistant (%s).", type(exc).__name__)
                return await m.reply_text(
                    "Music playback is not ready. Reconnect the owner's music account with /login and try again."
                )
            needs_join = False
            try:
                # Check the playback account with its own MTProto client. The Bot API
                # client may not have the user account in its peer cache.
                member = await client.get_chat_member(chat_id, client.id)
                if member.status in [
                    enums.ChatMemberStatus.BANNED,
                    enums.ChatMemberStatus.RESTRICTED,
                ]:
                    try:
                        await app.unban_chat_member(
                            chat_id=chat_id, user_id=client.id
                        )
                    except:
                        return await m.reply_text(
                            m.lang["play_banned"].format(
                                app.name,
                                client.id,
                                client.mention,
                                f"@{client.username}" if client.username else None,
                            )
                        )
                    needs_join = True
            except (
                errors.UserNotParticipant,
                errors.exceptions.bad_request_400.UserNotParticipant,
                errors.PeerIdInvalid,
                errors.ChannelInvalid,
                errors.ChatIdInvalid,
            ):
                needs_join = True
            except errors.ChatAdminRequired:
                return await m.reply_text(m.lang["admin_required"])

            if needs_join:
                if m.chat.username:
                    invite_link = m.chat.username
                else:
                    try:
                        invite_link = (await app.get_chat(chat_id)).invite_link
                        if not invite_link:
                            invite_link = await app.export_chat_invite_link(chat_id)
                    except errors.ChatAdminRequired:
                        return await m.reply_text(m.lang["admin_required"])
                    except Exception as ex:
                        return await m.reply_text(
                            m.lang["play_invite_error"].format(type(ex).__name__)
                        )

                umm = await m.reply_text(m.lang["play_invite"].format(app.name))
                try:
                    await client.join_chat(invite_link)
                except errors.UserAlreadyParticipant:
                    pass
                except errors.InviteRequestSent:
                    await asyncio.sleep(2)
                    try:
                        await client.approve_chat_join_request(chat_id, client.id)
                    except errors.HideRequesterMissing:
                        pass
                    except Exception as ex:
                        return await umm.edit_text(
                            m.lang["play_invite_error"].format(type(ex).__name__)
                        )
                except (errors.ChannelInvalid, errors.ChatIdInvalid):
                    return await umm.edit_text(
                        "Telegram could not open this group for the music account. "
                        "Confirm this is a supergroup and that the music account can join it."
                    )
                except Exception as ex:
                    logger.warning(
                        "Music account could not join the playback group (%s).",
                        type(ex).__name__,
                    )
                    return await umm.edit_text(
                        m.lang["play_invite_error"].format(type(ex).__name__)
                    )

                await umm.delete()
                try:
                    if m.chat.username:
                        await client.resolve_peer(m.chat.username)
                    await client.resolve_peer(chat_id)
                except (
                    errors.PeerIdInvalid,
                    errors.ChannelInvalid,
                    errors.ChatIdInvalid,
                ):
                    return await m.reply_text(
                        "The music account could not resolve this group after joining. "
                        "Confirm it is a member of this supergroup, then try /play again."
                    )

        try:
            delete_command = await db.get_cmd_delete(chat_id)
        except Exception as exc:
            logger.warning("Could not read music command settings (%s).", type(exc).__name__)
            return await m.reply_text(
                "Music settings are temporarily unavailable. Please try again shortly."
            )
        if delete_command:
            try:
                await m.delete()
            except:
                pass

        return await play(_, m, force, m3u8, video, url)

    return wrapper
