import logging
from typing import Any

logger = logging.getLogger("eiko.music.reactions")


async def add_music_post_reaction(
    client: Any, chat_id: int, message_id: int
) -> bool:
    """Add a heart reaction to a bot-generated music post when Telegram permits it."""
    try:
        return bool(
            await client.send_reaction(
                chat_id=chat_id,
                message_id=message_id,
                emoji="❤",
            )
        )
    except Exception as exc:
        logger.info("Could not add a reaction to the music post (%s).", type(exc).__name__)
        return False
