# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic


from dataclasses import dataclass, field


@dataclass
class Media:
    id: str
    duration: str
    duration_sec: int
    file_path: str
    message_id: int
    title: str
    url: str
    time: int = 0
    user: str = None
    video: bool = False


@dataclass
class Track:
    id: str
    channel_name: str
    duration: str
    duration_sec: int
    title: str
    url: str
    file_path: str = None
    message_id: int = 0
    time: int = 0
    thumbnail: str = None
    user: str = None
    view_count: str = None
    video: bool = False
    artist: str = None
    # Short-lived yt-dlp URL kept in memory only for faster first playback.
    # Stream URLs/headers are intentionally excluded from persisted queue data.
    stream_url: str = None
    stream_headers: dict = field(default_factory=dict)
