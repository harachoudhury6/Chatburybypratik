"""Render the supplied custom emoji IDs in Telegram message text and captions."""

from __future__ import annotations

import html
import re
from functools import wraps


PREMIUM_EMOJI_IDS = {
    "✅": "5823396554345549784",
    "🎵": "5891249688933305846",
    "🎤": "5897554554894946515",
    "➡️": "5877468380125990242",
    "🎶": "5915480455603295660",
    "⏱️": "5936170807716745162",
    "🔥": "5859539275372040586",
    "🎙️": "5909015791088439934",
    "🌙": "6005928962163742139",
    "✨": "5765071340847501478",
    "🎥": "6005986106703613755",
    "⏳": "6010111371251815589",
    "⚠️": "5881702736843511327",
    "❌": "5260342697075416641",
    "🔴": "5411225014148014586",
    "🗑️": "5258130763148172425",
    "✔️": "6255593645848660539",
}

PREMIUM_BUTTON_EMOJI_IDS = {
    **PREMIUM_EMOJI_IDS,
    "🗑": "5258130763148172425",
}

_CUSTOM_EMOJI_BLOCK = re.compile(r"<emoji\s+id=\d+>.*?</emoji>", re.DOTALL)


def premium_emoji_markup(text: str) -> str:
    """Convert mapped Unicode emojis to Telegram custom-emoji HTML tags.

    Existing custom-emoji tags are left untouched so callers may safely run
    this on captions that already contain premium emoji markup.
    """
    if not text:
        return text

    pieces = _CUSTOM_EMOJI_BLOCK.split(text)
    blocks = _CUSTOM_EMOJI_BLOCK.findall(text)
    converted: list[str] = []
    for index, piece in enumerate(pieces):
        for emoji in sorted(PREMIUM_EMOJI_IDS, key=len, reverse=True):
            emoji_id = PREMIUM_EMOJI_IDS[emoji]
            piece = piece.replace(
                emoji, f"<emoji id={emoji_id}>{emoji}</emoji>"
            )
        converted.append(piece)
        if index < len(blocks):
            converted.append(blocks[index])
    return "".join(converted)


def premium_emoji_markup_from_entities(text: str, entities) -> str:
    """Preserve Telegram's custom-emoji IDs when the owner sends a status sample."""
    custom = [
        entity for entity in (entities or [])
        if str(
            getattr(
                getattr(entity, "type", None),
                "value",
                getattr(entity, "type", ""),
            )
        ).casefold().endswith("custom_emoji")
        and getattr(entity, "custom_emoji_id", None)
    ]
    if not custom:
        return html.escape(text)

    def index_at_utf16_offset(offset: int) -> int:
        units = 0
        for index, character in enumerate(text):
            if units >= offset:
                return index
            units += 2 if ord(character) > 0xFFFF else 1
        return len(text)

    output = []
    cursor = 0
    for entity in sorted(custom, key=lambda item: item.offset):
        start = index_at_utf16_offset(entity.offset)
        end = index_at_utf16_offset(entity.offset + entity.length)
        if start < cursor or end <= start:
            continue
        output.append(html.escape(text[cursor:start]))
        output.append(
            f'<emoji id={entity.custom_emoji_id}>'
            f'{html.escape(text[start:end])}</emoji>'
        )
        cursor = end
    output.append(html.escape(text[cursor:]))
    return "".join(output)


def _premium_button_arguments(args, kwargs):
    """Move the first mapped label emoji into Telegram's native button icon."""
    kwargs = dict(kwargs)
    if kwargs.get("icon_custom_emoji_id"):
        return args, kwargs
    label = args[0] if args else kwargs.get("text")
    if not isinstance(label, str) or not label:
        return args, kwargs

    # Keep the plain bullet in the Rec label; other mapped button emojis
    # continue using Telegram's custom-emoji icon behavior.
    if label.strip().casefold() == "• rec":
        return args, kwargs

    for emoji in sorted(PREMIUM_BUTTON_EMOJI_IDS, key=len, reverse=True):
        emoji_id = PREMIUM_BUTTON_EMOJI_IDS[emoji]
        if emoji not in label:
            continue
        remaining = label.replace(emoji, "", 1).strip()
        if remaining:
            if args:
                args = (remaining, *args[1:])
            else:
                kwargs["text"] = remaining
        kwargs["icon_custom_emoji_id"] = emoji_id
        return args, kwargs
    return args, kwargs


def activate_premium_keyboard_emojis() -> None:
    """Apply supplied emoji IDs to Pyrogram and PTB inline-button constructors."""
    from pyrogram.types import InlineKeyboardButton as PyrogramButton
    from telegram import InlineKeyboardButton as TelegramButton

    for button_class in (PyrogramButton, TelegramButton):
        if getattr(button_class, "_premium_emoji_constructor_active", False):
            continue
        original_init = button_class.__init__

        @wraps(original_init)
        def patched_init(self, *args, __original=original_init, **kwargs):
            args, kwargs = _premium_button_arguments(args, kwargs)
            __original(self, *args, **kwargs)

        button_class.__init__ = patched_init
        button_class._premium_emoji_constructor_active = True
