# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic


from collections import defaultdict, deque
import random
from typing import Union

from ._dataclass import Media, Track

MediaItem = Union[Media, Track]


class Queue:
    def __init__(self):
        self.queues: dict[int, deque[MediaItem]] = defaultdict(deque)
        self.history: dict[int, deque[MediaItem]] = defaultdict(
            lambda: deque(maxlen=50)
        )

    def add(self, chat_id: int, item: MediaItem) -> int:
        """Add an item to the queue and return its position (1-based)."""
        self.queues[chat_id].append(item)
        return len(self.queues[chat_id]) - 1

    def check_item(self, chat_id: int, item_id: str) -> tuple[int, MediaItem | None]:
        """Check if an item with the given ID exists in the queue."""
        pos, track = next(
            (
                (i, track)
                for i, track in enumerate(list(self.queues[chat_id]))
                if track.id == item_id
            ),
            (-1, None),
        )
        return pos, track

    def force_add(
        self, chat_id: int, item: MediaItem, remove: int | bool = False
    ) -> None:
        """Replace the currently playing item with a new one."""
        self.remove_current(chat_id)
        self.queues[chat_id].appendleft(item)
        if remove:
            self.queues[chat_id].rotate(-remove)
            self.queues[chat_id].popleft()
            self.queues[chat_id].rotate(remove)

    def get_current(self, chat_id: int) -> MediaItem | None:
        """Return the currently playing item (first in queue), if any."""
        return self.queues[chat_id][0] if self.queues[chat_id] else None

    def get_next(self, chat_id: int, check: bool = False) -> MediaItem | None:
        """Remove current item and return the next one, or None if empty."""
        if not self.queues[chat_id]:
            return None
        if check:
            return self.queues[chat_id][1] if len(self.queues[chat_id]) > 1 else None

        self.queues[chat_id].popleft()
        return self.queues[chat_id][0] if self.queues[chat_id] else None

    def get_queue(self, chat_id: int) -> list[MediaItem]:
        """Return the full queue including the currently playing item."""
        return list(self.queues[chat_id])

    def remember(self, chat_id: int, item: MediaItem | None) -> None:
        """Remember a completed/replaced track for the Previous control."""
        if not item:
            return
        history = self.history[chat_id]
        if not history or history[-1].id != item.id:
            history.append(item)

    def previous(self, chat_id: int) -> MediaItem | None:
        """Put the most recently heard track before the current queue item."""
        current = self.get_current(chat_id)
        history = self.history[chat_id]
        while history:
            item = history.pop()
            if current and item.id == current.id:
                continue
            self.queues[chat_id].appendleft(item)
            return item
        return None

    def shuffle_upcoming(self, chat_id: int) -> bool:
        """Shuffle upcoming tracks without moving or replacing the current track."""
        items = self.queues[chat_id]
        if len(items) < 3:
            return False
        current = items.popleft()
        upcoming = list(items)
        random.shuffle(upcoming)
        items.clear()
        items.append(current)
        items.extend(upcoming)
        return True

    def restore(self, chat_id: int, items: list[MediaItem]) -> None:
        """Restore persisted track metadata as a pending queue after a restart."""
        self.queues[chat_id].clear()
        self.queues[chat_id].extend(items)

    def remove_current(self, chat_id: int) -> None:
        """Remove the currently playing item only (if exists)."""
        if self.queues[chat_id]:
            self.queues[chat_id].popleft()

    def clear(self, chat_id: int) -> None:
        """Clear the entire queue."""
        self.queues[chat_id].clear()
