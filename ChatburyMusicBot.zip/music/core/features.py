"""Related-track recommendations for the existing music player."""

from __future__ import annotations

import logging
import time
from typing import Any

from music.helpers import Track

logger = logging.getLogger("eiko.music.features")

class MusicFeatureService:
    def __init__(self, youtube: Any) -> None:
        self.youtube = youtube
        self._recommendations: dict[str, tuple[float, list[Track]]] = {}

    async def related_tracks(
        self,
        seed: Track,
        limit: int = 10,
        exclude_ids: set[str] | None = None,
    ) -> list[Track]:
        """Use yt-dlp's public search metadata to find related playable candidates."""
        limit = max(1, min(int(limit), 10))
        key = str(seed.id)
        cached = self._recommendations.get(key)
        now = time.monotonic()
        if cached and cached[0] > now:
            candidates = list(cached[1])
        else:
            artist = (seed.artist or seed.channel_name or "").strip()
            title = (seed.title or "").strip()
            queries = []
            if artist and title:
                queries.append(f"songs like {title} by {artist}")
            if artist:
                queries.append(f"{artist} popular songs")
            if title:
                queries.append(f"similar songs to {title}")

            candidates = []
            seen_ids: set[str] = {str(seed.id)}
            seen_titles: set[str] = set()
            for query in queries:
                try:
                    results = await self.youtube.search_many(query, limit=20)
                except Exception as exc:
                    logger.warning(
                        "Related-track search failed (%s).", type(exc).__name__
                    )
                    results = []
                for track in results:
                    if not track or not track.id or track.id in seen_ids:
                        continue
                    if track.video or int(track.duration_sec or 0) <= 0:
                        continue
                    normalized_title = " ".join(
                        (track.title or "").casefold().split()
                    )
                    if normalized_title and normalized_title in seen_titles:
                        continue
                    seen_ids.add(str(track.id))
                    seen_titles.add(normalized_title)
                    candidates.append(track)
                if len(candidates) >= limit:
                    break

            # SoundCloud is the existing public fallback, not a new download service.
            if not candidates and artist:
                try:
                    candidates = await self.youtube.search_many(
                        f"scsearch10:{artist}", limit=10
                    )
                except Exception as exc:
                    logger.warning(
                        "Related SoundCloud search failed (%s).", type(exc).__name__
                    )
                    candidates = []
                candidates = [
                    track
                    for track in candidates
                    if track and track.id != seed.id and not track.video
                ]
            self._recommendations[key] = (now + 300, candidates[:20])

        excluded = {str(value) for value in (exclude_ids or set())}
        excluded.add(str(seed.id))
        filtered = [track for track in candidates if str(track.id) not in excluded]
        return filtered[:limit]
