# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
# ALONE-CODER

import asyncio
import html
import random
from collections import defaultdict
from pathlib import Path

from ntgcalls import (ConnectionNotFound, TelegramServerError,
                      RTMPStreamingUnsupported)
from pyrogram.errors import MessageIdInvalid
from pyrogram.types import InputMediaPhoto, Message
from pytgcalls import PyTgCalls, exceptions, types
from pytgcalls.pytgcalls_session import PyTgCallsSession

from music import app, config, db, lang, logger, queue, tasks, userbot, yt
from music.helpers import Media, Track, buttons, thumb
from music.helpers._inline import _support_url
from music.helpers._premium_emoji import premium_emoji_markup
from music.helpers._reactions import add_music_post_reaction
from music.helpers._queue_cards import queue_cards
from music.core.features import MusicFeatureService
from management.helpers.message_effects import (
    random_message_effect,
    send_with_message_effect,
)


class TgCall(PyTgCalls):
    def __init__(self):
        self.clients = []
        self._autoplay_chats: set[int] = set()
        self._radio_chats: set[int] = set()
        self._loop_modes: dict[int, str] = {}
        self._group_locks = defaultdict(asyncio.Lock)
        self._group_owners: dict[int, asyncio.Task] = {}
        self._transitions: set[int] = set()
        self.features = MusicFeatureService(yt)

    def is_autoplay_enabled(self, chat_id: int) -> bool:
        return chat_id in self._autoplay_chats

    def toggle_autoplay(self, chat_id: int) -> bool:
        if chat_id in self._autoplay_chats:
            self._autoplay_chats.remove(chat_id)
            return False
        self._autoplay_chats.add(chat_id)
        return True

    def is_radio_enabled(self, chat_id: int) -> bool:
        return chat_id in self._radio_chats

    async def set_radio(self, chat_id: int, enabled: bool) -> bool:
        if enabled:
            self._radio_chats.add(chat_id)
        else:
            self._radio_chats.discard(chat_id)
        try:
            await db.set_radio(chat_id, enabled)
        except Exception as exc:
            logger.warning("Could not persist radio setting (%s).", type(exc).__name__)
        return enabled

    def loop_mode(self, chat_id: int) -> str:
        return self._loop_modes.get(chat_id, "off")

    def cycle_loop(self, chat_id: int) -> str:
        next_mode = {"off": "track", "track": "queue", "queue": "off"}[
            self.loop_mode(chat_id)
        ]
        if next_mode == "off":
            self._loop_modes.pop(chat_id, None)
        else:
            self._loop_modes[chat_id] = next_mode
        return next_mode

    async def _persist_queue(self, chat_id: int) -> None:
        try:
            await db.save_queue(chat_id, queue.get_queue(chat_id))
        except Exception as exc:
            logger.warning("Could not persist music queue (%s).", type(exc).__name__)

    async def _stop_after_playback_error(self, chat_id: int) -> None:
        if self._group_owners.get(chat_id) is asyncio.current_task():
            await self._stop_locked(chat_id)
        else:
            await self.stop(chat_id)

    async def pause(self, chat_id: int) -> bool:
        client = await db.get_assistant(chat_id)
        result = await client.pause(chat_id)
        await db.playing(chat_id, paused=True)
        return result

    async def resume(self, chat_id: int) -> bool:
        client = await db.get_assistant(chat_id)
        result = await client.resume(chat_id)
        await db.playing(chat_id, paused=False)
        return result

    async def stop(self, chat_id: int) -> None:
        async with self._group_locks[chat_id]:
            self._group_owners[chat_id] = asyncio.current_task()
            try:
                await self._stop_locked(chat_id)
            finally:
                self._group_owners.pop(chat_id, None)

    async def _stop_locked(self, chat_id: int) -> None:
        try:
            client = await db.get_assistant(chat_id)
        except Exception:
            client = None
        stopped_items = queue.get_queue(chat_id)
        queue.clear(chat_id)
        try:
            await db.remove_call(chat_id)
        except Exception as exc:
            logger.warning("Could not clear active-call state (%s).", type(exc).__name__)
        await self._persist_queue(chat_id)
        self._autoplay_chats.discard(chat_id)
        self._loop_modes.pop(chat_id, None)
        await self.set_radio(chat_id, False)

        left_call = False
        if client is not None:
            try:
                await client.leave_call(chat_id, close=False)
                left_call = True
            except Exception as exc:
                logger.warning("Could not leave voice chat (%s).", type(exc).__name__)
        if left_call:
            for item in stopped_items:
                yt.cleanup_download(getattr(item, "file_path", None), queue)

    @staticmethod
    def _has_media_source(media: Media | Track) -> bool:
        path = getattr(media, "file_path", None)
        if path and Path(path).is_file():
            return True
        return bool(getattr(media, "stream_url", None))

    async def start_current(self, chat_id: int, message: Message) -> bool:
        """Start a pending queue after a restart, once a user starts a voice chat."""
        media = queue.get_current(chat_id)
        if not media:
            return False
        if not self._has_media_source(media):
            media.file_path = await yt.download(
                media.id, video=media.video, url=getattr(media, "url", None)
            )
        if not self._has_media_source(media):
            return False
        return await self.play_media(chat_id, message, media)

    async def play_now(
        self, chat_id: int, message: Message, media: Track
    ) -> bool:
        """Replace the current song from an inline result without creating a client."""
        async with self._group_locks[chat_id]:
            self._group_owners[chat_id] = asyncio.current_task()
            try:
                if not await db.get_call(chat_id):
                    return False
                current = queue.get_current(chat_id)
                if not self._has_media_source(media):
                    media.file_path = await yt.download(
                        media.id, video=media.video, url=getattr(media, "url", None)
                    )
                if not self._has_media_source(media):
                    return False
                queue.remember(chat_id, current)
                queue.force_add(chat_id, media)
                await self._persist_queue(chat_id)
                started = await self.play_media(chat_id, message, media)
                if current and current.file_path != media.file_path:
                    yt.cleanup_download(current.file_path, queue)
                return started
            finally:
                self._group_owners.pop(chat_id, None)

    async def play_previous(self, chat_id: int) -> bool:
        async with self._group_locks[chat_id]:
            self._group_owners[chat_id] = asyncio.current_task()
            try:
                media = queue.previous(chat_id)
                if not media:
                    history = await db.get_history(chat_id, limit=10)
                    current = queue.get_current(chat_id)
                    record = next(
                        (
                            entry
                            for entry in history[1:]
                            if not current or entry.get("track_id") != current.id
                        ),
                        None,
                    )
                    if not record:
                        return False
                    media = Track(
                        id=record["track_id"],
                        channel_name=record.get("artist") or "Unknown",
                        artist=record.get("artist") or None,
                        title=record.get("title") or "Unknown title",
                        duration=record.get("duration") or "0:00:00",
                        duration_sec=int(record.get("duration_sec") or 0),
                        url=record.get("url") or "",
                        thumbnail=record.get("thumbnail") or None,
                        video=bool(record.get("video")),
                    )
                    if current:
                        queue.queues[chat_id].appendleft(media)
                    else:
                        queue.queues[chat_id].append(media)
                if not self._has_media_source(media):
                    media.file_path = await yt.download(
                        media.id, video=media.video, url=getattr(media, "url", None)
                    )
                if not self._has_media_source(media):
                    return False
                message = await app.send_message(chat_id, "Playing the previous track…")
                await self._persist_queue(chat_id)
                return await self.play_media(chat_id, message, media)
            finally:
                self._group_owners.pop(chat_id, None)

    async def update_player(self, chat_id: int) -> None:
        media = queue.get_current(chat_id)
        if not media or not media.message_id:
            return
        try:
            _lang = await lang.get_lang(chat_id)
            text = _lang["play_media"].format(
                media.url, media.title, media.duration, media.user
            )
            upcoming = max(0, len(queue.get_queue(chat_id)) - 1)
            if upcoming:
                text += (
                    "\n\n<emoji id=5891249688933305846>🎵</emoji> "
                    f"Queue: {upcoming} upcoming track(s)"
                )
            text = premium_emoji_markup(text)
            try:
                await app.edit_message_caption(
                    chat_id=chat_id,
                    message_id=media.message_id,
                    caption=text,
                    reply_markup=buttons.controls(chat_id),
                )
            except Exception:
                # Before the first artwork upload the player is still text.
                await app.edit_message_text(
                    chat_id=chat_id,
                    message_id=media.message_id,
                    text=text,
                    reply_markup=buttons.controls(chat_id),
                )
        except Exception as exc:
            logger.debug("Player card refresh skipped (%s).", type(exc).__name__)


    async def _recover_youtube_audio(self, media: Track, start_stream, message) -> bool:
        """Refresh an expired public stream, then try a public SoundCloud match."""
        try:
            refreshed = await yt.search(media.url, message.id, video=False)
            if (
                refreshed
                and str(refreshed.id) == str(media.id)
                and refreshed.stream_url
            ):
                media.stream_url = refreshed.stream_url
                media.stream_headers = refreshed.stream_headers or {}
                try:
                    await start_stream(media.stream_url, media.stream_headers)
                    return True
                except exceptions.NoAudioSourceFound:
                    logger.info("Refreshed public YouTube stream was rejected.")
        except Exception as exc:
            logger.info("Could not refresh public YouTube stream (%s).", type(exc).__name__)

        try:
            path = await yt.download(
                media.id, video=False, url=getattr(media, "url", None)
            )
            if path:
                media.file_path = path
                media.stream_url = None
                media.stream_headers = {}
                try:
                    await start_stream(path)
                    return True
                except exceptions.NoAudioSourceFound:
                    logger.info("Downloaded public YouTube audio was rejected.")
        except Exception as exc:
            logger.info("Public YouTube download retry failed (%s).", type(exc).__name__)

        query = " ".join(
            part
            for part in (
                str(getattr(media, "title", "") or "").strip(),
                str(
                    getattr(media, "artist", None)
                    or getattr(media, "channel_name", "")
                    or ""
                ).strip(),
            )
            if part
        )
        if not query:
            return False
        try:
            alternative = await yt.search(
                f"scsearch5:{query}", message.id, video=False
            )
            if not alternative or not (
                alternative.stream_url or alternative.file_path
            ):
                return False

            # Prefer a verified local audio file for fallback tracks. Some
            # public stream URLs are accepted by PyTgCalls but later fail inside
            # FFmpeg without producing audible audio.
            if not alternative.file_path:
                alternative.file_path = await yt.download(
                    alternative.id,
                    video=False,
                    url=alternative.url,
                )
            if alternative.file_path:
                alternative.stream_url = None
                alternative.stream_headers = {}

            old_path = media.file_path
            yt.adopt_alternative_track(media, alternative)
            if media.file_path:
                await start_stream(media.file_path)
            elif alternative.stream_url:
                await start_stream(
                    alternative.stream_url, alternative.stream_headers or {}
                )
            else:
                return False
            if old_path and old_path != media.file_path:
                yt.cleanup_download(old_path, queue)
            logger.info(
                "Started a public SoundCloud alternative after YouTube failed (%s).",
                "downloaded audio" if media.file_path else "direct stream",
            )
            return True
        except exceptions.NoAudioSourceFound:
            logger.info("Public SoundCloud alternative had no playable audio.")
        except Exception as exc:
            logger.info("Public audio fallback failed (%s).", type(exc).__name__)
        return False


    async def play_media(
        self,
        chat_id: int,
        message: Message,
        media: Media | Track,
        seek_time: int = 0,
    ) -> bool:
        try:
            client = await db.get_assistant(chat_id)
            _lang = await lang.get_lang(chat_id)
        except Exception as exc:
            logger.warning("Could not prepare music playback (%s).", type(exc).__name__)
            try:
                await message.edit_text(
                    "Music playback is temporarily unavailable. Check the owner account and database, then try again."
                )
            except Exception:
                pass
            return False

        local_path = (
            media.file_path
            if media.file_path and Path(media.file_path).is_file()
            else None
        )
        soundcloud_url = (
            not media.video
            and "soundcloud.com/" in (getattr(media, "url", "") or "").lower()
        )
        if soundcloud_url and not local_path:
            try:
                downloaded_path = await yt.download(
                    media.id,
                    video=False,
                    url=getattr(media, "url", None),
                )
                if downloaded_path and Path(downloaded_path).is_file():
                    media.file_path = downloaded_path
                    media.stream_url = None
                    media.stream_headers = {}
                    local_path = downloaded_path
                    logger.info("Using downloaded SoundCloud audio for voice playback.")
            except Exception as exc:
                logger.warning(
                    "Could not prepare local SoundCloud audio (%s); trying its public stream.",
                    type(exc).__name__,
                )
        stream_url = None if local_path else getattr(media, "stream_url", None)
        source_path = local_path or stream_url
        source_headers = (
            getattr(media, "stream_headers", None) or {}
            if stream_url
            else None
        )
        if not source_path:
            await message.edit_text(_lang["error_no_file"].format(_support_url()))
            return False

        def build_stream(path: str, headers: dict | None = None):
            return types.MediaStream(
                media_path=path,
                audio_parameters=types.AudioQuality.HIGH,
                video_parameters=types.VideoQuality.HD_720p,
                audio_flags=types.MediaStream.Flags.REQUIRED,
                video_flags=(
                    types.MediaStream.Flags.AUTO_DETECT
                    if media.video
                    else types.MediaStream.Flags.IGNORE
                ),
                headers=headers,
                ffmpeg_parameters=f"-ss {seek_time}" if seek_time > 1 else None,
            )

        async def start_stream(path: str, headers: dict | None = None):
            await client.play(
                chat_id=chat_id,
                stream=build_stream(path, headers),
                # Create the group call when the group hasn't started one yet.
                config=types.GroupCallConfig(auto_start=True),
            )

        try:
            try:
                await start_stream(source_path, source_headers)
            except exceptions.NoAudioSourceFound:
                recovered = False
                if (
                    isinstance(media, Track)
                    and not media.video
                    and yt.is_youtube_url(media.url)
                ):
                    recovered = await self._recover_youtube_audio(
                        media, start_stream, message
                    )
                elif stream_url:
                    # For other public streaming sources, retain the managed
                    # download fallback when their signed URL expires.
                    fallback_path = await yt.download(
                        media.id, video=media.video, url=getattr(media, "url", None)
                    )
                    if fallback_path:
                        media.file_path = fallback_path
                        await start_stream(fallback_path)
                        recovered = True
                if not recovered:
                    raise

            media.time = max(1, int(seek_time or 1))
            media.message_id = message.id
            if not seek_time:
                await db.add_call(chat_id)
                try:
                    await db.record_history(chat_id, media)
                except Exception as exc:
                    logger.warning(
                        "Could not save listening history (%s).", type(exc).__name__
                    )
                await self._persist_queue(chat_id)
                text = _lang["play_media"].format(
                    media.url,
                    media.title,
                    media.duration,
                    media.user,
                )
                upcoming = max(0, len(queue.get_queue(chat_id)) - 1)
                if upcoming:
                    text += (
                        "\n\n<emoji id=5891249688933305846>🎵</emoji> "
                        f"Queue: {upcoming} upcoming track(s)"
                    )
                text = premium_emoji_markup(text)
                keyboard = buttons.controls(chat_id)
                try:
                    await message.edit_text(text, reply_markup=keyboard)
                except Exception as exc:
                    logger.warning(
                        "Could not send the quick player status (%s).",
                        type(exc).__name__,
                    )
                await add_music_post_reaction(app, chat_id, message.id)
                render_task = asyncio.create_task(
                    self._render_player_card(
                        chat_id, message, media, text, keyboard, seek_time
                    )
                )
                tasks.append(render_task)
                render_task.add_done_callback(self._forget_render_task)
            return True
        except FileNotFoundError:
            await message.edit_text(_lang["error_no_file"].format(_support_url()))
            return False
        except exceptions.NoActiveGroupCall:
            await self._stop_after_playback_error(chat_id)
            await message.edit_text(_lang["error_no_call"])
        except exceptions.NoAudioSourceFound:
            await message.edit_text(_lang["error_no_audio"])
            await self._stop_after_playback_error(chat_id)
        except (ConnectionNotFound, TelegramServerError):
            await self._stop_after_playback_error(chat_id)
            await message.edit_text(_lang["error_tg_server"])
        except RTMPStreamingUnsupported:
            await self._stop_after_playback_error(chat_id)
            await message.edit_text(_lang["error_rtmp"])
        except Exception as exc:
            logger.warning("Voice playback failed (%s).", type(exc).__name__)
            try:
                await self._stop_after_playback_error(chat_id)
            except Exception:
                pass
            try:
                await message.edit_text(
                    "The music assistant could not start playback. Confirm the voice chat is active and the owner account can join."
                )
            except Exception:
                pass
        return False

    @staticmethod
    def _forget_render_task(task: asyncio.Task) -> None:
        try:
            tasks.remove(task)
        except ValueError:
            pass

    async def _render_player_card(
        self,
        chat_id: int,
        message: Message,
        media: Media | Track,
        caption: str,
        keyboard,
        seek_time: int,
    ) -> None:
        try:
            photo = (
                await thumb.generate(media, position=seek_time)
                if isinstance(media, Track)
                else config.DEFAULT_THUMB
            )
            if queue.get_current(chat_id) is not media:
                return
            try:
                await message.edit_media(
                    media=InputMediaPhoto(media=photo, caption=caption),
                    reply_markup=keyboard,
                )
            except MessageIdInvalid:
                replacement = await send_with_message_effect(
                    app.send_photo,
                    chat_id=chat_id,
                    photo=photo,
                    caption=caption,
                    reply_markup=keyboard,
                    effect_id=random_message_effect(),
                )
                media.message_id = replacement.id
                await add_music_post_reaction(app, chat_id, replacement.id)
        except Exception as exc:
            logger.warning("Could not render player artwork (%s).", type(exc).__name__)


    async def replay(self, chat_id: int) -> None:
        if not await db.get_call(chat_id):
            return

        media = queue.get_current(chat_id)
        _lang = await lang.get_lang(chat_id)
        msg = await app.send_message(chat_id=chat_id, text=_lang["play_again"])
        started = await self.play_media(chat_id, msg, media)
        if not started:
            return


    async def _fill_radio(self, chat_id: int, seed: Track | Media) -> int:
        queued = queue.get_queue(chat_id)
        excluded = {str(item.id) for item in queued}
        excluded.add(str(seed.id))
        candidates = await self.features.related_tracks(
            seed, limit=15, exclude_ids=excluded
        )
        artist = (
            getattr(seed, "artist", None)
            or getattr(seed, "channel_name", None)
            or seed.title
        )
        added = 0

        async def verify_and_queue(candidates_to_try, cap: int) -> int:
            nonlocal added
            for candidate in candidates_to_try[:cap]:
                try:
                    checked = await yt.search(candidate.url or candidate.id, 0)
                    if (
                        not checked
                        or checked.video
                        or str(checked.id) in excluded
                        or int(checked.duration_sec or 0) <= 0
                    ):
                        continue
                    path = await yt.download(
                        checked.id,
                        video=False,
                        url=getattr(checked, "url", None),
                    )
                    if not path:
                        continue
                    checked.file_path = path
                    checked.user = "Radio"
                    queue.add(chat_id, checked)
                    excluded.add(str(checked.id))
                    added += 1
                    if added >= 3:
                        break
                except Exception as exc:
                    logger.info("Radio candidate skipped (%s).", type(exc).__name__)
            return added

        await verify_and_queue(candidates, 8)
        if not added and artist:
            try:
                public_fallbacks = await yt.search_many(
                    f"scsearch10:{artist}", limit=8
                )
                await verify_and_queue(public_fallbacks, 5)
            except Exception as exc:
                logger.info("Radio fallback search failed (%s).", type(exc).__name__)
        await self._persist_queue(chat_id)
        return added

    async def _fill_same_artist(self, chat_id: int, seed: Track | Media) -> int:
        artist = (
            getattr(seed, "artist", None)
            or getattr(seed, "channel_name", None)
            or ""
        ).strip()
        if not artist:
            return 0
        try:
            candidates = await yt.search_many(f"{artist} songs", limit=12)
        except Exception as exc:
            logger.info("Autoplay search failed (%s).", type(exc).__name__)
            return 0
        queued_ids = {str(item.id) for item in queue.get_queue(chat_id)}
        candidates = [
            track
            for track in candidates
            if track
            and str(track.id) != str(seed.id)
            and str(track.id) not in queued_ids
            and int(track.duration_sec or 0) > 0
            and not track.video
        ]
        exact_artist = [
            track
            for track in candidates
            if track.artist and track.artist.casefold() == artist.casefold()
        ]
        candidates = exact_artist or candidates
        for candidate in candidates[:5]:
            try:
                checked = await yt.search(candidate.url or candidate.id, 0)
                if not checked or checked.video:
                    continue
                checked.file_path = await yt.download(
                    checked.id, video=False, url=getattr(checked, "url", None)
                )
                if checked.file_path:
                    checked.user = seed.user or "Autoplay"
                    queue.add(chat_id, checked)
                    await self._persist_queue(chat_id)
                    return 1
            except Exception as exc:
                logger.info("Autoplay candidate skipped (%s).", type(exc).__name__)
        return 0

    async def play_next(self, chat_id: int) -> None:
        lock = self._group_locks[chat_id]
        if chat_id in self._transitions or lock.locked():
            return
        self._transitions.add(chat_id)
        async with lock:
            self._group_owners[chat_id] = asyncio.current_task()
            try:
                await self._play_next_locked(chat_id)
            finally:
                self._group_owners.pop(chat_id, None)
                self._transitions.discard(chat_id)

    async def _play_next_locked(self, chat_id: int) -> None:
        previous = queue.get_current(chat_id)
        mode = self.loop_mode(chat_id)
        if mode == "track" and previous:
            media = previous
        else:
            media = queue.get_next(chat_id)
            if mode == "queue" and previous:
                queue.add(chat_id, previous)
                if not media:
                    media = queue.get_current(chat_id)
            elif previous:
                queue.remember(chat_id, previous)

        if not media and previous and self.is_radio_enabled(chat_id):
            await self._fill_radio(chat_id, previous)
            media = queue.get_current(chat_id)
        if not media and previous and self.is_autoplay_enabled(chat_id):
            if await self._fill_same_artist(chat_id, previous):
                media = queue.get_current(chat_id)

        # Try a bounded number of queued candidates rather than terminating on
        # one restricted/deleted video.
        for _ in range(5):
            if not media:
                break
            if not self._has_media_source(media):
                media.file_path = await yt.download(
                    media.id, video=media.video, url=getattr(media, "url", None)
                )
            if self._has_media_source(media):
                break
            logger.info("Skipping unavailable queued audio: %s", str(media.id)[:40])
            queue.remove_current(chat_id)
            media = queue.get_current(chat_id)

        await self._persist_queue(chat_id)
        if not media or not self._has_media_source(media):
            if previous:
                await self._stop_locked(chat_id)
                yt.cleanup_download(previous.file_path, queue)
            else:
                await self._stop_locked(chat_id)
            return

        try:
            if media.message_id:
                await app.delete_messages(
                    chat_id=chat_id,
                    message_ids=media.message_id,
                    revoke=True,
                )
                media.message_id = 0
        except Exception:
            pass

        _lang = await lang.get_lang(chat_id)
        msg = await app.send_message(chat_id=chat_id, text=_lang["play_next"])
        media.message_id = msg.id
        await self.play_media(chat_id, msg, media)
        if previous and previous.file_path != media.file_path:
            yt.cleanup_download(previous.file_path, queue)


    async def ping(self) -> float:
        pings = [client.ping for client in self.clients]
        return round(sum(pings) / len(pings), 2) if pings else 0.0


    async def decorators(self, client: PyTgCalls) -> None:
        @client.on_update()
        async def update_handler(_, update: types.Update) -> None:
            if isinstance(update, types.StreamEnded):
                if update.stream_type == types.StreamEnded.Type.AUDIO:
                    current = queue.get_current(update.chat_id)
                    upcoming = queue.get_queue(update.chat_id)
                    next_track = upcoming[1] if len(upcoming) > 1 else None
                    if self._is_natural_end(current):
                        if current and current.message_id:
                            try:
                                await app.edit_message_reply_markup(
                                    chat_id=update.chat_id,
                                    message_id=current.message_id,
                                    reply_markup=buttons.controls(
                                        update.chat_id,
                                        progress_seconds=current.duration_sec,
                                    ),
                                )
                            except Exception as exc:
                                logger.debug(
                                    "Final progress button refresh skipped (%s).",
                                    type(exc).__name__,
                                )
                        try:
                            await self._send_track_ended(
                                update.chat_id, current, next_track
                            )
                        except Exception as exc:
                            logger.warning(
                                "Could not send the track-ended card (%s).",
                                type(exc).__name__,
                            )
                    await self.play_next(update.chat_id)
            elif isinstance(update, types.ChatUpdate):
                if update.status in [
                    types.ChatUpdate.Status.KICKED,
                    types.ChatUpdate.Status.LEFT_GROUP,
                    types.ChatUpdate.Status.CLOSED_VOICE_CHAT,
                ]:
                    await self.stop(update.chat_id)

    @staticmethod
    def _is_natural_end(media: Media | Track | None) -> bool:
        if not media or not getattr(media, "duration_sec", 0):
            return False
        duration = max(1, int(media.duration_sec))
        tolerance = min(12, max(3, duration // 10))
        return int(getattr(media, "time", 0) or 0) >= duration - tolerance

    async def _send_track_ended(
        self,
        chat_id: int,
        media: Media | Track,
        next_track: Media | Track | None,
    ) -> None:
        title = html.escape(str(getattr(media, "title", "Track") or "Track"))
        artist = str(
            getattr(media, "artist", None)
            or getattr(media, "channel_name", None)
            or ""
        )
        artist = html.escape(artist)
        caption = (
            f"<emoji id=5823396554345549784>✅</emoji> Track finished\n"
            f"<emoji id=5891249688933305846>🎵</emoji> {title}"
        )
        if artist:
            caption += f"\n<emoji id=5897554554894946515>🎤</emoji> {artist}"
        if next_track:
            next_title = html.escape(
                str(getattr(next_track, "title", "Next track") or "Next track")
            )
            caption += (
                f"\n<emoji id=5877468380125990242>➡️</emoji> Up next: {next_title}"
            )
        caption = premium_emoji_markup(caption)
        photo = queue_cards.render_ended(media, next_track)
        await app.send_photo(chat_id=chat_id, photo=photo, caption=caption)


    async def boot(self) -> None:
        PyTgCallsSession.notice_displayed = True
        try:
            self._radio_chats.update(await db.get_radio_chats())
        except Exception as exc:
            logger.warning("Could not restore radio settings (%s).", type(exc).__name__)
        for ub in list(userbot.clients):
            try:
                await self.add_assistant(ub)
            except Exception as exc:
                logger.warning(
                    "Voice-call assistant unavailable (%s); music playback is disabled for that session.",
                    type(exc).__name__,
                )
                if ub in userbot.clients:
                    userbot.clients.remove(ub)
                try:
                    if ub.is_connected:
                        await ub.disconnect()
                except Exception:
                    pass
        logger.info("PyTgCalls ready for %d music assistant(s).", len(self.clients))

    async def add_assistant(self, ub) -> None:
        if any(getattr(client, "_eiko_user_client", None) is ub for client in self.clients):
            return
        call = PyTgCalls(ub, cache_duration=100)
        await call.start()
        call._eiko_user_client = ub
        self.clients.append(call)
        await self.decorators(call)

    async def remove_assistant(self, index: int) -> None:
        if index < 0 or index >= len(self.clients):
            return
        call = self.clients.pop(index)
        try:
            await call.stop()
        except Exception as exc:
            logger.warning("Could not stop voice-call client (%s).", type(exc).__name__)
