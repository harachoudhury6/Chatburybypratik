# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic


from pathlib import Path

from pyrogram import Client

from music import config, logger


class Userbot(Client):
    def __init__(self):
        self.clients = []
        project_root = Path(__file__).resolve().parents[2]
        configured_session_dir = Path(config.MUSIC_SESSION_DIR).expanduser()
        if not configured_session_dir.is_absolute():
            configured_session_dir = project_root / configured_session_dir
        self.sessions_dir = configured_session_dir.resolve()
        self.sessions_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            self.sessions_dir.chmod(0o700)
        except OSError:
            pass
        clients = (
            (1, "one", config.SESSION1),
            (2, "two", config.SESSION2),
            (3, "three", config.SESSION3),
        )
        for index, key, session in clients:
            name = f"music_assistant_{index}"
            setattr(
                self,
                key,
                Client(
                    name=name,
                    workdir=str(self.sessions_dir.resolve()),
                    api_id=config.API_ID,
                    api_hash=config.API_HASH,
                    session_string=session,
                ),
            )

    def replace_client(self, num: int, session_string=None):
        if num not in (1, 2, 3):
            raise ValueError("Music assistant number must be 1, 2, or 3.")
        name = f"music_assistant_{num}"
        attribute = {1: "one", 2: "two", 3: "three"}[num]
        old = getattr(self, attribute)
        if old in self.clients:
            self.clients.remove(old)
        fresh = Client(
            name=name,
            workdir=str(self.sessions_dir.resolve()),
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            session_string=session_string,
        )
        setattr(self, attribute, fresh)
        return old, fresh

    def replace_primary(self, session_string=None):
        return self.replace_client(1, session_string=session_string)

    async def boot_client(self, num: int, ub: Client, *, announce: bool = False):
        clients = {
            1: self.one,
            2: self.two,
            3: self.three,
        }
        client = clients[num]
        try:
            await client.start()
            self._secure_session_files(num)
        except Exception as exc:
            logger.warning("Could not start assistant %s (%s).", num, type(exc).__name__)
            return False

        if client.me.id != config.MUSIC_ACCOUNT_ID:
            logger.error(
                "Assistant %s belongs to a different music account; it will not be used.",
                num,
            )
            try:
                await client.log_out()
            except Exception:
                try:
                    await client.stop()
                except Exception:
                    pass
            return False

        client.id = client.me.id
        client.first_name = client.me.first_name
        client.username = client.me.username
        client.mention = client.me.mention
        if client not in self.clients:
            self.clients.append(client)
        if announce and config.LOGGER_ID:
            try:
                await client.send_message(config.LOGGER_ID, "Music assistant connected.")
            except Exception as exc:
                logger.warning("Assistant startup notice unavailable (%s).", type(exc).__name__)
        logger.info("Assistant %s authorized.", num)
        return True

    def _secure_session_files(self, num: int) -> None:
        session_path = self.sessions_dir / f"music_assistant_{num}.session"
        for suffix in ("", "-journal", "-wal", "-shm"):
            path = Path(f"{session_path}{suffix}")
            if path.exists():
                try:
                    path.chmod(0o600)
                except OSError:
                    pass

    async def boot(self):
        sessions = (
            (1, config.SESSION1),
            (2, config.SESSION2),
            (3, config.SESSION3),
        )
        for num, session_string in sessions:
            # /login persists Pyrogram's local SQLite session database. Reuse
            # that session on restart even when no SESSIONn secret is configured.
            saved_session = self.sessions_dir / f"music_assistant_{num}.session"
            if session_string or saved_session.is_file():
                self._secure_session_files(num)
                await self.boot_client(num, getattr(self, {1: "one", 2: "two", 3: "three"}[num]))

    async def exit(self):
        for client in (self.one, self.two, self.three):
            if not client.is_connected:
                continue
            try:
                await client.stop()
            except Exception as exc:
                logger.warning("Could not stop assistant (%s).", type(exc).__name__)
        self.clients.clear()
        logger.info("Assistants stopped.")
