# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
#ALONE-CODER

from random import randint
from time import time
from datetime import datetime, timezone

from database import get_client

from music import config, logger, userbot


class MongoDB:
    def __init__(self):
        """
        Initialize the MongoDB connection.
        """
        self.mongo = get_client()
        self.db = self.mongo[config.MONGO_MUSIC_DB_NAME]

        self.admin_list = {}
        self.active_calls = {}
        self.admin_play = []
        self.blacklisted = []
        self.cmd_delete = []
        self.notified = []
        self.cache = self.db.cache
        self.logger = False

        self.assistant = {}
        self.assistantdb = self.db.assistant

        self.auth = {}
        self.authdb = self.db.auth

        self.chats = []
        self.chatsdb = self.db.chats

        self.lang = {}
        self.langdb = self.db.lang

        self.users = []
        self.usersdb = self.db.users
        self.favoritesdb = self.db.favorite_tracks
        self.historydb = self.db.music_history
        self.radiodb = self.db.radio_settings
        self.queuedb = self.db.saved_music_queues
        self.bot_configdb = self.db.bot_config
        self._music_only_chat_ids: set[int] | None = None

    async def connect(self) -> None:
        """Check if we can connect to the database.

        Raises:
            SystemExit: If the connection to the database fails.
        """
        try:
            start = time()
            await self.mongo.admin.command("ping")
            logger.info(f"Database connection successful. ({time() - start:.2f}s)")
            await self.load_cache()
            await self.restore_queues()
        except Exception as e:
            raise SystemExit(f"Database connection failed: {type(e).__name__}") from e

    async def close(self) -> None:
        """Close the connection to the database."""
        logger.info("Music database handle released; the shared client stays open.")

    async def get_music_account_id_override(self) -> int | None:
        """Return the owner-configured playback identity override, if present."""
        doc = await self.bot_configdb.find_one({"_id": "music_account_id"})
        if not doc:
            return None
        try:
            user_id = int(doc["user_id"])
        except (KeyError, TypeError, ValueError) as exc:
            raise RuntimeError("Stored music account ID is invalid.") from exc
        if user_id <= 0:
            raise RuntimeError("Stored music account ID must be positive.")
        return user_id

    async def set_music_account_id_override(self, user_id: int) -> None:
        user_id = int(user_id)
        if user_id <= 0:
            raise ValueError("Music account ID must be a positive Telegram user ID.")
        await self.bot_configdb.update_one(
            {"_id": "music_account_id"},
            {
                "$set": {
                    "user_id": user_id,
                    "updated_at": datetime.now(timezone.utc),
                }
            },
            upsert=True,
        )

    async def clear_music_account_id_override(self) -> None:
        await self.bot_configdb.delete_one({"_id": "music_account_id"})

    async def get_music_only_chat_ids(self) -> set[int]:
        if self._music_only_chat_ids is None:
            doc = await self.bot_configdb.find_one({"_id": "music_only_chat_ids"}) or {}
            self._music_only_chat_ids = {
                int(chat_id)
                for chat_id in doc.get("chat_ids", [])
                if str(chat_id).startswith("-")
                and str(chat_id)[1:].isascii()
                and str(chat_id)[1:].isdigit()
                and int(chat_id) < 0
            }
        return set(self._music_only_chat_ids)

    async def is_music_only_chat(self, chat_id: int) -> bool:
        return int(chat_id) in await self.get_music_only_chat_ids()

    async def add_music_only_chat(self, chat_id: int) -> None:
        chat_id = int(chat_id)
        if chat_id >= 0:
            raise ValueError("Group chat ID must be negative.")
        await self.bot_configdb.update_one(
            {"_id": "music_only_chat_ids"},
            {"$addToSet": {"chat_ids": chat_id}},
            upsert=True,
        )
        if self._music_only_chat_ids is not None:
            self._music_only_chat_ids.add(chat_id)

    async def remove_music_only_chat(self, chat_id: int) -> None:
        chat_id = int(chat_id)
        if chat_id >= 0:
            raise ValueError("Group chat ID must be negative.")
        await self.bot_configdb.update_one(
            {"_id": "music_only_chat_ids"},
            {"$pull": {"chat_ids": chat_id}},
        )
        if self._music_only_chat_ids is not None:
            self._music_only_chat_ids.discard(chat_id)

    # CACHE
    async def get_call(self, chat_id: int) -> bool:
        return chat_id in self.active_calls

    async def add_call(self, chat_id: int) -> None:
        self.active_calls[chat_id] = 1

    async def remove_call(self, chat_id: int) -> None:
        self.active_calls.pop(chat_id, None)

    async def playing(self, chat_id: int, paused: bool = None) -> bool | None:
        if paused is not None:
            self.active_calls[chat_id] = int(not paused)
        return bool(self.active_calls.get(chat_id, 0))

    async def get_admins(self, chat_id: int, reload: bool = False) -> list[int]:
        from music.helpers._admins import reload_admins

        if chat_id not in self.admin_list or reload:
            self.admin_list[chat_id] = await reload_admins(chat_id)
        return self.admin_list[chat_id]

    # AUTH METHODS
    async def _get_auth(self, chat_id: int) -> set[int]:
        if chat_id not in self.auth:
            doc = await self.authdb.find_one({"_id": chat_id}) or {}
            self.auth[chat_id] = set(doc.get("user_ids", []))
        return self.auth[chat_id]

    async def is_auth(self, chat_id: int, user_id: int) -> bool:
        return user_id in await self._get_auth(chat_id)

    async def add_auth(self, chat_id: int, user_id: int) -> None:
        users = await self._get_auth(chat_id)
        if user_id not in users:
            users.add(user_id)
            await self.authdb.update_one(
                {"_id": chat_id}, {"$addToSet": {"user_ids": user_id}}, upsert=True
            )

    async def rm_auth(self, chat_id: int, user_id: int) -> None:
        users = await self._get_auth(chat_id)
        if user_id in users:
            users.discard(user_id)
            await self.authdb.update_one(
                {"_id": chat_id}, {"$pull": {"user_ids": user_id}}
            )

    # ASSISTANT METHODS
    async def set_assistant(self, chat_id: int) -> int:
        if not userbot.clients:
            raise RuntimeError("No owner music account is connected. Use /login first.")
        num = randint(1, len(userbot.clients))
        await self.assistantdb.update_one(
            {"_id": chat_id},
            {"$set": {"num": num}},
            upsert=True,
        )
        self.assistant[chat_id] = num
        return num

    async def get_assistant(self, chat_id: int):
        from music import anon

        if not userbot.clients or len(anon.clients) != len(userbot.clients):
            raise RuntimeError("The music voice-call service is not ready. Use /login or retry later.")

        if chat_id not in self.assistant:
            doc = await self.assistantdb.find_one({"_id": chat_id})
            num = doc.get("num") if doc else None
            if not isinstance(num, int) or not 1 <= num <= len(anon.clients):
                num = await self.set_assistant(chat_id)
            self.assistant[chat_id] = num

        if not 1 <= self.assistant[chat_id] <= len(anon.clients):
            self.assistant[chat_id] = await self.set_assistant(chat_id)
        return anon.clients[self.assistant[chat_id] - 1]

    async def get_client(self, chat_id: int):
        if chat_id not in self.assistant:
            await self.get_assistant(chat_id)
        index = self.assistant[chat_id] - 1
        if index < 0 or index >= len(userbot.clients):
            raise RuntimeError("The assigned music account is not connected.")
        return userbot.clients[index]

    # BLACKLIST METHODS
    async def add_blacklist(self, chat_id: int) -> None:
        if str(chat_id).startswith("-"):
            self.blacklisted.append(chat_id)
            return await self.cache.update_one(
                {"_id": "bl_chats"}, {"$addToSet": {"chat_ids": chat_id}}, upsert=True
            )
        await self.cache.update_one(
            {"_id": "bl_users"}, {"$addToSet": {"user_ids": chat_id}}, upsert=True
        )

    async def del_blacklist(self, chat_id: int) -> None:
        if str(chat_id).startswith("-"):
            self.blacklisted.remove(chat_id)
            return await self.cache.update_one(
                {"_id": "bl_chats"},
                {"$pull": {"chat_ids": chat_id}},
            )
        await self.cache.update_one(
            {"_id": "bl_users"},
            {"$pull": {"user_ids": chat_id}},
        )

    async def get_blacklisted(self, chat: bool = False) -> list[int]:
        if chat:
            if not self.blacklisted:
                doc = await self.cache.find_one({"_id": "bl_chats"})
                self.blacklisted.extend(doc.get("chat_ids", []) if doc else [])
            return self.blacklisted
        doc = await self.cache.find_one({"_id": "bl_users"})
        return doc.get("user_ids", []) if doc else []

    # CHAT METHODS
    async def is_chat(self, chat_id: int) -> bool:
        return chat_id in self.chats

    async def add_chat(self, chat_id: int) -> None:
        if not await self.is_chat(chat_id):
            self.chats.append(chat_id)
            await self.chatsdb.insert_one({"_id": chat_id})

    async def rm_chat(self, chat_id: int) -> None:
        if await self.is_chat(chat_id):
            self.chats.remove(chat_id)
            await self.chatsdb.delete_one({"_id": chat_id})

    async def get_chats(self) -> list:
        if not self.chats:
            self.chats.extend([chat["_id"] async for chat in self.chatsdb.find()])
        return self.chats

    # COMMAND DELETE
    async def get_cmd_delete(self, chat_id: int) -> bool:
        if chat_id not in self.cmd_delete:
            doc = await self.chatsdb.find_one({"_id": chat_id})
            if doc and doc.get("cmd_delete"):
                self.cmd_delete.append(chat_id)
        return chat_id in self.cmd_delete

    async def set_cmd_delete(self, chat_id: int, delete: bool = False) -> None:
        if delete:
            self.cmd_delete.append(chat_id)
        else:
            self.cmd_delete.remove(chat_id)
        await self.chatsdb.update_one(
            {"_id": chat_id},
            {"$set": {"cmd_delete": delete}},
            upsert=True,
        )

    # LANGUAGE METHODS
    async def set_lang(self, chat_id: int, lang_code: str):
        await self.langdb.update_one(
            {"_id": chat_id},
            {"$set": {"lang": lang_code}},
            upsert=True,
        )
        self.lang[chat_id] = lang_code

    async def get_lang(self, chat_id: int) -> str:
        if chat_id not in self.lang:
            doc = await self.langdb.find_one({"_id": chat_id})
            self.lang[chat_id] = doc["lang"] if doc else "en"
        return self.lang[chat_id]

    # LOGGER METHODS
    async def is_logger(self) -> bool:
        return self.logger

    async def get_logger(self) -> bool:
        doc = await self.cache.find_one({"_id": "logger"})
        if doc:
            self.logger = doc["status"]
        return self.logger

    async def set_logger(self, status: bool) -> None:
        self.logger = status
        await self.cache.update_one(
            {"_id": "logger"},
            {"$set": {"status": status}},
            upsert=True,
        )

    # PLAY MODE METHODS
    async def get_play_mode(self, chat_id: int) -> bool:
        if chat_id not in self.admin_play:
            doc = await self.chatsdb.find_one({"_id": chat_id})
            if doc and doc.get("admin_play"):
                self.admin_play.append(chat_id)
        return chat_id in self.admin_play

    async def set_play_mode(self, chat_id: int, remove: bool = False) -> None:
        if remove and chat_id in self.admin_play:
            self.admin_play.remove(chat_id)
        else:
            self.admin_play.append(chat_id)
        await self.chatsdb.update_one(
            {"_id": chat_id},
            {"$set": {"admin_play": not remove}},
            upsert=True,
        )

    # SUDO METHODS
    async def add_sudo(self, user_id: int) -> None:
        await self.cache.update_one(
            {"_id": "sudoers"}, {"$addToSet": {"user_ids": user_id}}, upsert=True
        )

    async def del_sudo(self, user_id: int) -> None:
        await self.cache.update_one(
            {"_id": "sudoers"}, {"$pull": {"user_ids": user_id}}
        )

    async def get_sudoers(self) -> list[int]:
        doc = await self.cache.find_one({"_id": "sudoers"})
        return doc.get("user_ids", []) if doc else []

    # USER METHODS
    async def is_user(self, user_id: int) -> bool:
        return user_id in self.users

    async def add_user(self, user_id: int) -> None:
        if not await self.is_user(user_id):
            self.users.append(user_id)
            await self.usersdb.insert_one({"_id": user_id})

    async def rm_user(self, user_id: int) -> None:
        if await self.is_user(user_id):
            self.users.remove(user_id)
            await self.usersdb.delete_one({"_id": user_id})

    async def get_users(self) -> list:
        if not self.users:
            self.users.extend([user["_id"] async for user in self.usersdb.find()])
        return self.users

    @staticmethod
    def _track_record(track) -> dict:
        return {
            "track_id": str(track.id),
            "title": str(track.title or "Unknown title")[:300],
            "artist": str(
                getattr(track, "artist", None)
                or getattr(track, "channel_name", None)
                or ""
            )[:200],
            "url": str(track.url or "")[:2000],
            "duration": str(track.duration or ""),
            "duration_sec": int(track.duration_sec or 0),
            "thumbnail": str(getattr(track, "thumbnail", None) or "")[:2000],
            "video": bool(getattr(track, "video", False)),
        }

    async def save_favorite(self, user_id: int, track) -> None:
        record = self._track_record(track)
        record.update(
            {
                "_id": f"{int(user_id)}:{record['track_id']}",
                "user_id": int(user_id),
                "saved_at": datetime.now(timezone.utc),
            }
        )
        await self.favoritesdb.update_one(
            {"_id": record["_id"]}, {"$set": record}, upsert=True
        )

    async def remove_favorite(self, user_id: int, track_id: str) -> bool:
        result = await self.favoritesdb.delete_one(
            {"_id": f"{int(user_id)}:{str(track_id)}"}
        )
        return bool(result.deleted_count)

    async def get_favorites(self, user_id: int, limit: int = 50) -> list[dict]:
        cursor = self.favoritesdb.find({"user_id": int(user_id)}).sort(
            "saved_at", -1
        ).limit(max(1, min(int(limit), 100)))
        return [record async for record in cursor]

    async def record_history(self, chat_id: int, track) -> None:
        record = self._track_record(track)
        record["played_at"] = datetime.now(timezone.utc)
        await self.historydb.update_one(
            {"_id": int(chat_id)},
            {
                "$push": {
                    "tracks": {
                        "$each": [record],
                        "$position": 0,
                        "$slice": 100,
                    }
                }
            },
            upsert=True,
        )

    async def get_history(self, chat_id: int, limit: int = 50) -> list[dict]:
        doc = await self.historydb.find_one({"_id": int(chat_id)})
        return (doc or {}).get("tracks", [])[: max(1, min(int(limit), 100))]

    async def set_radio(self, chat_id: int, enabled: bool) -> None:
        await self.radiodb.update_one(
            {"_id": int(chat_id)},
            {"$set": {"enabled": bool(enabled)}},
            upsert=True,
        )

    async def get_radio(self, chat_id: int) -> bool:
        doc = await self.radiodb.find_one({"_id": int(chat_id)})
        return bool(doc and doc.get("enabled"))

    async def get_radio_chats(self) -> list[int]:
        return [
            int(doc["_id"])
            async for doc in self.radiodb.find({"enabled": True})
            if isinstance(doc.get("_id"), int)
        ]

    async def save_queue(self, chat_id: int, items: list) -> None:
        if not items:
            await self.queuedb.delete_one({"_id": int(chat_id)})
            return
        records = []
        for item in items[:100]:
            record = self._track_record(item)
            record["kind"] = "media" if hasattr(item, "file_path") and not hasattr(item, "artist") else "track"
            records.append(record)
        await self.queuedb.update_one(
            {"_id": int(chat_id)},
            {
                "$set": {
                    "tracks": records,
                    "updated_at": datetime.now(timezone.utc),
                }
            },
            upsert=True,
        )

    async def restore_queues(self) -> None:
        from music import queue
        from music.helpers import Media, Track

        async for doc in self.queuedb.find({}):
            items = []
            for record in (doc.get("tracks") or [])[:100]:
                try:
                    common = {
                        "id": str(record["track_id"]),
                        "duration": str(record.get("duration") or "0:00:00"),
                        "duration_sec": max(0, int(record.get("duration_sec") or 0)),
                        "title": str(record.get("title") or "Unknown title"),
                        "url": str(record.get("url") or ""),
                        "video": bool(record.get("video")),
                        "user": "Restored queue",
                    }
                    if record.get("kind") == "media":
                        item = Media(
                            **common,
                            file_path=None,
                            message_id=0,
                        )
                    else:
                        item = Track(
                            **common,
                            channel_name=str(record.get("artist") or "Unknown"),
                            artist=str(record.get("artist") or "") or None,
                            thumbnail=str(record.get("thumbnail") or "") or None,
                        )
                    items.append(item)
                except (KeyError, TypeError, ValueError):
                    continue
            try:
                chat_id = int(doc["_id"])
            except (KeyError, TypeError, ValueError):
                continue
            if items:
                queue.restore(chat_id, items)
        logger.info("Saved music queues restored as pending metadata.")


    async def migrate_coll(self) -> None:
        from bson import ObjectId
        logger.info("Migrating users and chats from old collections...")

        musers, mchats, done = [], [], []
        ulist = [user async for user in self.db.tgusersdb.find()]
        ulist.extend([user async for user in self.usersdb.find()])

        for user in ulist:
            if isinstance(user.get("_id"), ObjectId):
                user_id = int(user["user_id"])
                if user_id in done:
                    continue
                done.append(user_id)
                musers.append(user)
            else:
                user_id = int(user["_id"])
                if user_id in done:
                    continue
                done.append(user_id)
                musers.append({"_id": user_id})
        await self.usersdb.drop()
        await self.db.tgusersdb.drop()
        if musers:
            await self.usersdb.insert_many(musers)

        async for chat in self.chatsdb.find():
            if isinstance(chat.get("_id"), ObjectId):
                chat_id = int(chat["chat_id"])
                if chat_id in mchats:
                    continue
                done.append(chat_id)
                mchats.append(chat)
            else:
                chat_id = int(chat["_id"])
                if chat_id in done:
                    continue
                done.append(chat_id)
                mchats.append({"_id": chat_id})
        await self.chatsdb.drop()
        if mchats:
            await self.chatsdb.insert_many(mchats)

        await self.cache.insert_one({"_id": "migrated"})
        logger.info("Migration completed.")

    async def load_cache(self) -> None:
        doc = await self.cache.find_one({"_id": "migrated"})
        if not doc:
            await self.migrate_coll()

        await self.get_chats()
        await self.get_users()
        await self.get_blacklisted(True)
        await self.get_logger()
        logger.info("Database cache loaded.")
