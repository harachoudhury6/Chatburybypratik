"""YouTube search and extraction using yt-dlp; no Google API key is needed."""

from __future__ import annotations

import asyncio
from contextvars import ContextVar
import logging
import re
import shutil
import subprocess
from datetime import timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import yt_dlp

from music.helpers import Track

logger = logging.getLogger("eiko.music.youtube")
DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
_YOUTUBE_HOSTS = {
    "youtube.com",
    "www.youtube.com",
    "m.youtube.com",
    "music.youtube.com",
    "youtu.be",
}
_SOUNDCLOUD_HOSTS = {
    "soundcloud.com",
    "www.soundcloud.com",
    "m.soundcloud.com",
    "on.soundcloud.com",
    "snd.sc",
}


def _duration(seconds: int | float | None) -> str:
    return str(timedelta(seconds=max(0, int(seconds or 0))))


def _audio_stream(
    info: dict[str, Any], video: bool = False
) -> tuple[str | None, dict[str, str]]:
    """Return a public audio format URL and its extractor-supplied HTTP headers."""
    if video:
        return None, {}

    formats = [
        item
        for item in info.get("formats", [])
        if isinstance(item, dict)
        and item.get("url")
        and item.get("acodec") not in (None, "none")
    ]
    if info.get("url") and info.get("acodec") not in (None, "none"):
        formats.append(info)
    if not formats:
        return None, {}

    def quality(item: dict[str, Any]) -> tuple[int, float, float]:
        audio_only = int(item.get("vcodec") in (None, "none"))
        try:
            abr = float(item.get("abr") or 0)
        except (TypeError, ValueError):
            abr = 0.0
        try:
            tbr = float(item.get("tbr") or 0)
        except (TypeError, ValueError):
            tbr = 0.0
        return audio_only, abr, tbr

    selected = max(formats, key=quality)
    raw_headers = selected.get("http_headers") or info.get("http_headers") or {}
    headers = (
        {
            str(key): str(value)
            for key, value in raw_headers.items()
            if key and value is not None
        }
        if isinstance(raw_headers, dict)
        else {}
    )
    return str(selected["url"]), headers


def _track(info: dict[str, Any], user: str = "", video: bool = False) -> Track | None:
    if not info or not info.get("id"):
        return None
    length = int(info.get("duration") or 0)
    artists = info.get("artists")
    if isinstance(artists, (list, tuple)):
        artists = ", ".join(str(artist) for artist in artists if artist)
    artist = info.get("artist") or artists
    webpage_url = (
        info.get("webpage_url")
        or info.get("permalink_url")
        or info.get("original_url")
    )
    extractor = str(info.get("extractor_key") or info.get("extractor") or "").lower()
    is_soundcloud = "soundcloud" in extractor or _is_soundcloud_url(webpage_url)
    if not webpage_url and is_soundcloud:
        webpage_url = info.get("url")
    track_id = f"sc_{info['id']}" if is_soundcloud else str(info["id"])
    if not webpage_url and not is_soundcloud:
        webpage_url = f"https://www.youtube.com/watch?v={info['id']}"
    stream_url, stream_headers = _audio_stream(info, video=video)
    return Track(
        id=track_id,
        channel_name=str(info.get("uploader") or info.get("channel") or "Unknown"),
        duration=_duration(length),
        duration_sec=length,
        title=str(info.get("title") or "Untitled"),
        url=str(webpage_url or ""),
        thumbnail=info.get("thumbnail"),
        user=user or None,
        view_count=str(info.get("view_count") or "N/A"),
        video=video,
        artist=str(artist) if artist else None,
        stream_url=stream_url,
        stream_headers=stream_headers,
    )


def _has_playable_format(info: dict[str, Any] | None, video: bool) -> bool:
    if not info:
        return False
    codec = "vcodec" if video else "acodec"
    return any(
        fmt.get(codec) not in (None, "none")
        for fmt in info.get("formats", [])
        if isinstance(fmt, dict)
    )


def _extract(query: str, options: dict[str, Any]) -> dict[str, Any] | None:
    with yt_dlp.YoutubeDL(options) as downloader:
        return downloader.extract_info(query, download=False)


def _is_soundcloud_url(url: str | None) -> bool:
    try:
        host = (urlparse(url).hostname or "").lower() if url else ""
    except ValueError:
        return False
    return host in _SOUNDCLOUD_HOSTS


def _safe_output_id(value: str) -> str:
    safe_value = re.sub(r"[^A-Za-z0-9_-]", "_", str(value))
    return safe_value[:80] or "track"


def _is_valid_media_file(path: Path, video: bool = False) -> bool:
    try:
        if not path.is_file() or path.stat().st_size < 1024:
            return False
    except OSError:
        return False
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        logger.warning("Cannot verify downloaded media: ffprobe is unavailable.")
        return False
    try:
        result = subprocess.run(
            [
                ffprobe,
                "-v",
                "error",
                "-show_entries",
                "stream=codec_type",
                "-of",
                "csv=p=0",
                str(path),
            ],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    streams = {line.strip() for line in result.stdout.splitlines() if line.strip()}
    return result.returncode == 0 and (
        "video" in streams if video else "audio" in streams
    )


def _retryable_network_error(exc: Exception) -> bool:
    return _failure_category(exc) == "network_error"


class YouTube:
    def __init__(self) -> None:
        self._last_error = ContextVar(f"yt_last_error_{id(self)}", default=None)
        self._last_download_error = ContextVar(
            f"yt_last_download_error_{id(self)}", default=None
        )

    @property
    def last_error(self) -> str | None:
        return self._last_error.get()

    @last_error.setter
    def last_error(self, value: str | None) -> None:
        self._last_error.set(value)

    @property
    def last_download_error(self) -> str | None:
        return self._last_download_error.get()

    @last_download_error.setter
    def last_download_error(self, value: str | None) -> None:
        self._last_download_error.set(value)

    def _base_options(self) -> dict[str, Any]:
        options = {
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "skip_download": True,
            "socket_timeout": 20,
            "retries": 2,
            "extractor_retries": 2,
            "fragment_retries": 2,
            "ignoreerrors": True,
            "logger": _YtDlpLogger(),
        }
        node_path = shutil.which("node")
        if node_path:
            options["js_runtimes"] = {"node": {"path": node_path}}
        return options

    async def _extract_with_retry(
        self, query: str, options: dict[str, Any], attempts: int = 3
    ) -> dict[str, Any] | None:
        for attempt in range(attempts):
            try:
                return await asyncio.to_thread(_extract, query, options)
            except Exception as exc:
                if not _retryable_network_error(exc) or attempt + 1 >= attempts:
                    raise
                logger.warning(
                    "Temporary yt-dlp network error; retrying (%d/%d).",
                    attempt + 1,
                    attempts - 1,
                )
                await asyncio.sleep(0.5 * (2**attempt))
        return None

    async def search(self, query: str, m_id: int, video: bool = False) -> Track | None:
        del m_id
        query = query.strip()
        if not query:
            self.last_error = "empty_query"
            return None

        self.last_error = None
        self.last_download_error = None
        soundcloud_search = re.match(r"^scsearch\d*:", query, re.IGNORECASE)
        direct_url = self.valid(query)
        candidate_urls: list[str] = []
        failures: list[str] = []

        try:
            if direct_url:
                candidate_urls = [query]
            elif soundcloud_search:
                options = self._base_options()
                options.update(
                    {
                        "ignoreerrors": True,
                        "noplaylist": False,
                        "playlistend": 3,
                        "socket_timeout": 5,
                        "retries": 0,
                        "extractor_retries": 0,
                        "fragment_retries": 0,
                    }
                )
                results = await self._extract_with_retry(query, options, attempts=1)
                entries = (results or {}).get("entries") or [results]
                for item in entries:
                    if not isinstance(item, dict):
                        continue
                    if _has_playable_format(item, video):
                        track = _track(item, video=video)
                        if track:
                            return track
                    target = (
                        item.get("webpage_url")
                        or item.get("permalink_url")
                        or item.get("original_url")
                    )
                    if target:
                        candidate_urls.append(str(target))
            else:
                # Ask yt-dlp for one fully-extracted result first. If it exposes
                # public audio, FFmpeg can start directly without waiting for a
                # complete MP3 download/transcode.
                quick_options = self._base_options()
                quick_options.update(
                    {
                        "ignoreerrors": True,
                        "noplaylist": False,
                        "playlistend": 1,
                        "socket_timeout": 6,
                        "retries": 0,
                        "extractor_retries": 0,
                        "fragment_retries": 0,
                    }
                )
                quick_result = await self._extract_with_retry(
                    f"ytsearch1:{query}", quick_options, attempts=1
                )
                quick_entries = (quick_result or {}).get("entries") or [quick_result]
                for item in quick_entries:
                    if not isinstance(item, dict) or not _has_playable_format(item, video):
                        continue
                    track = _track(item, video=video)
                    if track:
                        return track

                # Broaden the search only if the first result is restricted,
                # incomplete, or does not expose a playable audio format.
                options = self._base_options()
                options.update(
                    {
                        "ignoreerrors": False,
                        "noplaylist": False,
                        "playlistend": 3,
                        "extract_flat": "in_playlist",
                        "socket_timeout": 6,
                        "retries": 0,
                        "extractor_retries": 0,
                        "fragment_retries": 0,
                    }
                )
                results = await self._extract_with_retry(
                    f"ytsearch3:{query}", options, attempts=1
                )
                for item in (results or {}).get("entries", []):
                    if not item:
                        continue
                    target = item.get("webpage_url")
                    if not target and item.get("id"):
                        target = f"https://www.youtube.com/watch?v={item['id']}"
                    if not target:
                        target = item.get("url")
                    if target:
                        candidate_urls.append(str(target))

            for target in candidate_urls[:5]:
                options = self._base_options()
                options["ignoreerrors"] = False
                options["socket_timeout"] = 6
                options["retries"] = 0
                options["extractor_retries"] = 0
                options["fragment_retries"] = 0
                try:
                    info = await self._extract_with_retry(target, options, attempts=1)
                except Exception as exc:
                    category = _failure_category(exc)
                    failures.append(category)
                    if category in {
                        "rate_limited",
                        "http_403",
                        "age_restricted",
                        "region_blocked",
                        "requires_signin",
                    }:
                        logger.warning("Skipping media candidate (%s).", category)
                    else:
                        logger.debug("Skipping media candidate (%s).", category)
                    if category == "rate_limited":
                        break
                    continue
                if not _has_playable_format(info, video):
                    failures.append("no_audio_format")
                    continue
                track = _track(info, video=video)
                if track:
                    return track

            if "rate_limited" in failures:
                self.last_error = "rate_limited"
            elif "requires_signin" in failures:
                self.last_error = "anonymous_access_required"
            elif "age_restricted" in failures:
                self.last_error = "age_restricted"
            elif "region_blocked" in failures:
                self.last_error = "region_blocked"
            elif "no_audio_format" in failures:
                self.last_error = "no_public_audio"
            elif candidate_urls:
                self.last_error = failures[-1] if failures else "unavailable"
            else:
                self.last_error = "no_results"
            logger.warning("yt-dlp search ended without playable audio (%s).", self.last_error)
            return None
        except Exception as exc:
            self.last_error = _failure_category(exc)
            logger.warning("yt-dlp search failed (%s).", self.last_error)
            return None

    async def search_many(self, query: str, limit: int = 15) -> list[Track]:
        try:
            options = self._base_options()
            options["noplaylist"] = False
            info = await asyncio.to_thread(
                _extract,
                f"ytsearch{max(1, min(limit, 25))}:{query}",
                options,
            )
            if not info:
                return []
            entries = info.get("entries") or [info]
            return [track for item in entries if (track := _track(item)) is not None]
        except Exception as exc:
            logger.warning("YouTube search failed: %s.", _failure_category(exc))
            return []

    async def playlist(
        self, limit: int, user: str, url: str, video: bool
    ) -> list[Track]:
        try:
            options = self._base_options()
            options.update({"noplaylist": False, "playlistend": max(1, limit)})
            info = await asyncio.to_thread(_extract, url, options)
            entries = info.get("entries", []) if info else []
            return [
                track
                for item in entries[:limit]
                if item and (track := _track(item, user=user, video=video)) is not None
            ]
        except Exception as exc:
            logger.warning(
                "YouTube playlist extraction failed: %s.", _failure_category(exc)
            )
            return []

    async def download(
        self, video_id: str, video: bool = False, url: str | None = None
    ) -> str | None:
        safe_id = _safe_output_id(video_id)
        expected_path = DOWNLOAD_DIR / f"{safe_id}.{'mp4' if video else 'mp3'}"
        self.last_download_error = None
        try:
            DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
            if _is_valid_media_file(expected_path, video=video):
                return str(expected_path)
            expected_path.unlink(missing_ok=True)

            target = url or f"https://www.youtube.com/watch?v={video_id}"
            outtmpl = str(DOWNLOAD_DIR / f"{safe_id}.%(ext)s")
            options = self._base_options()
            options.update(
                {
                    "noplaylist": True,
                    "skip_download": False,
                    "ignoreerrors": False,
                    "outtmpl": outtmpl,
                    "format": (
                        "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
                        if video
                        else "bestaudio/best"
                    ),
                    "merge_output_format": "mp4" if video else None,
                    "postprocessors": (
                        []
                        if video
                        else [
                            {
                                "key": "FFmpegExtractAudio",
                                "preferredcodec": "mp3",
                                "preferredquality": "192",
                            }
                        ]
                    ),
                }
            )
            await asyncio.to_thread(_download, target, options)
            if _is_valid_media_file(expected_path, video=video):
                return str(expected_path)
            expected_path.unlink(missing_ok=True)
            self.last_download_error = "no_valid_media_file"
            logger.warning("yt-dlp finished without a valid media file.")
            return None
        except Exception as exc:
            self.last_download_error = _failure_category(exc)
            expected_path.unlink(missing_ok=True)
            logger.warning("yt-dlp download failed (%s).", self.last_download_error)
            return None

    def valid(self, url: str) -> bool:
        try:
            host = (urlparse(url or "").hostname or "").lower()
        except ValueError:
            return False
        return host in _YOUTUBE_HOSTS or host in _SOUNDCLOUD_HOSTS

    @staticmethod
    def is_youtube_url(url: str | None) -> bool:
        try:
            host = (urlparse(url or "").hostname or "").lower()
        except ValueError:
            return False
        return host in _YOUTUBE_HOSTS

    @staticmethod
    def adopt_alternative_track(target: Track, alternative: Track) -> None:
        """Use a verified public alternative while preserving requester/message state."""
        for name in (
            "id",
            "channel_name",
            "duration",
            "duration_sec",
            "title",
            "url",
            "thumbnail",
            "view_count",
            "video",
            "artist",
            "stream_url",
            "stream_headers",
            "file_path",
        ):
            setattr(target, name, getattr(alternative, name, None))

    def cleanup_download(self, file_path: str | None, queue_state: Any = None) -> bool:
        if not file_path:
            return False
        try:
            path = Path(file_path).resolve()
            if path.parent != DOWNLOAD_DIR.resolve():
                return False
            if not re.fullmatch(r"(?:sc_[A-Za-z0-9_-]{4,32}|[A-Za-z0-9_-]{11})", path.stem):
                return False
            if queue_state:
                for items in getattr(queue_state, "queues", {}).values():
                    for item in items:
                        queued_path = getattr(item, "file_path", None)
                        if queued_path and Path(queued_path).resolve() == path:
                            return False
            path.unlink(missing_ok=True)
            return True
        except (OSError, ValueError):
            return False


def _failure_category(exc: Exception) -> str:
    message = str(exc).lower()
    if any(
        hint in message
        for hint in (
            "http error 429",
            "http 429",
            "too many requests",
            "rate limit",
            "ratelimited",
        )
    ):
        return "rate_limited"
    if any(
        hint in message
        for hint in (
            "age-restricted",
            "age restricted",
            "confirm your age",
            "age verification",
        )
    ):
        return "age_restricted"
    if any(
        hint in message
        for hint in ("sign in to confirm", "not a bot", "login required")
    ):
        return "requires_signin"
    if "http error 403" in message or "http 403" in message:
        return "http_403"
    if any(hint in message for hint in ("not available in your country", "geo-restricted", "region locked")):
        return "region_blocked"
    if "video unavailable" in message or "private video" in message:
        return "unavailable"
    if any(
        hint in message
        for hint in (
            "timed out",
            "timeout",
            "connection reset",
            "connection aborted",
            "temporary failure",
            "network is unreachable",
            "http error 500",
            "http error 502",
            "http error 503",
            "http error 504",
        )
    ):
        return "network_error"
    return type(exc).__name__


class _YtDlpLogger:
    def debug(self, message: str) -> None:
        if message.startswith("[debug]"):
            return

    def warning(self, message: str) -> None:
        logger.debug("yt-dlp warning.")

    def error(self, message: str) -> None:
        logger.debug("yt-dlp extraction reported an error.")


def _download(url: str, options: dict[str, Any]) -> None:
    with yt_dlp.YoutubeDL(options) as downloader:
        downloader.download([url])
