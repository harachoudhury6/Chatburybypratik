# Copyright (c) 2025 TheHamkerAlone 
# Licensed under the MIT License.
# This file is part of AloneXMusic


import asyncio

import pyrogram

from music import config, logger


class Bot(pyrogram.Client):
    def __init__(self):
        super().__init__(
            # Keep each BotFather bot identity in its own Pyrogram session.
            # This leaves the previous bot's session untouched when BOT_TOKEN
            # changes, rather than reusing a cached authorization.
            name=f"PrikshaMusicBot_{config.BOT_ID}",
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            bot_token=config.BOT_TOKEN,
            parse_mode=pyrogram.enums.ParseMode.HTML,
            max_concurrent_transmissions=7,
            link_preview_options=pyrogram.types.LinkPreviewOptions(is_disabled=True),
        )
        self.owner = config.OWNER_ID
        self.logger = config.LOGGER_ID
        self.bl_users = pyrogram.filters.user()
        self.sudoers = pyrogram.filters.user(self.owner)

    async def boot(self):
        await super().start()
        self.id = self.me.id
        self.name = self.me.first_name
        self.username = self.me.username
        self.mention = self.me.mention
        config.BOT_USERNAME = f"@{self.username}" if self.username else ""
        configured_name = config.BOT_NAME
        current_name = self.me.first_name
        if configured_name:
            self.name = configured_name
        if configured_name and current_name != configured_name:
            asyncio.create_task(self._sync_configured_name(configured_name))
        if self.logger:
            try:
                await self.send_message(self.logger, "Bot Started")
                member = await self.get_chat_member(self.logger, self.id)
                if member.status != pyrogram.enums.ChatMemberStatus.ADMINISTRATOR:
                    logger.warning("Bot is not an administrator in LOG_GROUP_ID.")
            except Exception as exc:
                logger.warning("Startup log unavailable (%s); continuing.", type(exc).__name__)
        logger.info(f"Bot started as @{self.username}")

    async def _sync_configured_name(self, configured_name: str) -> None:
        try:
            await asyncio.wait_for(
                self.set_bot_name(configured_name),
                timeout=5,
            )
            logger.info("Bot display name updated from configured branding.")
        except Exception as exc:
            logger.warning(
                "Could not update the Telegram bot display name (%s).",
                type(exc).__name__,
            )

    async def exit(self):
        """
        Asynchronously stops the bot.
        """
        if self.is_connected:
            await super().stop()
        logger.info("Bot stopped.")
