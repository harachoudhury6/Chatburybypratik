"""Compatibility surface for EikoMusic's playback plugins."""

from __future__ import annotations

import asyncio
import logging
import time

from config import settings as config
logger = logging.getLogger("eiko.music")
logger.setLevel(getattr(logging, config.LOG_LEVEL, logging.INFO))
for logger_name in ("httpx", "ntgcalls", "pymongo", "pyrogram", "pytgcalls"):
    logging.getLogger(logger_name).setLevel(logging.ERROR)

tasks = []
boot = time.time()

from music.core.bot import Bot

app = Bot()

from music.core.dir import ensure_dirs

ensure_dirs()

from music.core.userbot import Userbot

userbot = Userbot()

from music.core.mongo import MongoDB

db = MongoDB()

from music.core.lang import Language

lang = Language()

from music.core.telegram import Telegram
from music.core.youtube import YouTube

tg = Telegram()
yt = YouTube()

from music.helpers import Queue

queue = Queue()

from music.core.calls import TgCall

anon = TgCall()


async def stop() -> None:
    logger.info("Stopping music services.")
    for task in tasks:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        except Exception:
            pass
    for call in anon.clients:
        try:
            await call.stop()
        except Exception as exc:
            logger.warning("Could not stop a voice-call client (%s).", type(exc).__name__)
    try:
        await app.exit()
    except Exception as exc:
        logger.warning("Could not stop the bot client (%s).", type(exc).__name__)
    try:
        await userbot.exit()
    except Exception as exc:
        logger.warning("Could not stop assistant clients (%s).", type(exc).__name__)
    await db.close()
