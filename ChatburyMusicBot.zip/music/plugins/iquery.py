import asyncio
import re
from pathlib import Path

from pyrogram import types
from pyrogram.enums import ParseMode
from pyrogram.errors import FloodWait

from music import app, logger, yt
from music.helpers import buttons
from management.command_menu import is_inline_command_query


_RESULT_ID = re.compile(r"ytmp3:(\d{1,15}):([A-Za-z0-9_-]{11})")
_downloads_in_progress: set[tuple[int, str]] = set()


def _music_search_term(query: str) -> str:
    text = (query or "").strip()
    lowered = text.lower()
    if lowered in {"!yt", "!youtube"}:
        return ""
    if lowered.startswith("!yt "):
        return text[4:].strip()
    if lowered.startswith("!youtube "):
        return text[9:].strip()
    return text


async def _edit_status(message, text: str) -> None:
    if message is None:
        return
    try:
        await message.edit_text(text)
    except Exception as exc:
        logger.warning(
            "Could not update inline audio status (%s).", type(exc).__name__
        )


@app.on_inline_query(~app.bl_users, group=0)
async def inline_query_handler(_, query: types.InlineQuery):
    raw_query = (query.query or "").strip()
    if is_inline_command_query(raw_query) or _is_management_inline_query(raw_query):
        return
    text = _music_search_term(raw_query)
    if not text:
        await app.answer_inline_query(
            query.id,
            results=[
                types.InlineQueryResultArticle(
                    id="music_inline_search_help",
                    title="Search for a song",
                    description="Type a song name after !yt",
                    input_message_content=types.InputTextMessageContent(
                        "<emoji id=5891249688933305846>🎵</emoji> "
                        "Inline music search is ready. Type a song name after !yt, "
                        "for example: !yt song title.",
                        parse_mode=ParseMode.HTML,
                    ),
                )
            ],
            cache_time=0,
            is_personal=True,
        )
        return
    tracks = await yt.search_many(text, limit=15)
    results = []
    seen_video_ids = set()
    for track in tracks:
        if (
            not track.thumbnail
            or not re.fullmatch(r"[A-Za-z0-9_-]{11}", track.id)
            or track.id in seen_video_ids
        ):
            continue
        seen_video_ids.add(track.id)
        caption = (
            f"<b>Title:</b> <a href='{track.url}'>{track.title[:250]}</a>\n\n"
            f"<b>Duration:</b> {track.duration}\n"
            f"<b>Views:</b> <code>{track.view_count}</code>\n"
            f"<b>Channel:</b> {track.channel_name}\n\n"
            f"<u><i>Fetched by {app.name}</i></u>"
        )
        results.append(
            types.InlineQueryResultPhoto(
                id=f"ytmp3:{query.from_user.id}:{track.id}",
                photo_url=track.thumbnail,
                title=track.title[:64],
                description=f"{track.duration} | {track.channel_name}"[:255],
                caption=caption,
                reply_markup=buttons.yt_key(track.url),
            )
        )
    await app.answer_inline_query(
        query.id, results=results, cache_time=5, is_personal=True
    )


def _is_management_inline_query(query: str) -> bool:
    text = (query or "").strip().lower()
    return (
        text.startswith(
            (
                "#gpt",
                "!spotify",
                "!sp",
                "!apple",
                "!am",
                "!dl",
                "!reel",
                "@",
            )
        )
        or bool(text.split() and text.split()[0].lstrip("@").isdigit())
    )


@app.on_chosen_inline_result(~app.bl_users)
async def chosen_inline_result_handler(_, chosen: types.ChosenInlineResult):
    match = _RESULT_ID.fullmatch(chosen.result_id or "")
    if not match:
        return

    requester_id, video_id = int(match.group(1)), match.group(2)
    if not chosen.from_user or chosen.from_user.id != requester_id:
        return

    download_key = (requester_id, video_id)
    if download_key in _downloads_in_progress:
        return
    _downloads_in_progress.add(download_key)

    status = None
    try:
        status = await app.send_message(
            requester_id,
            "<emoji id=6010111371251815589>⏳</emoji> "
            "Downloading your selected song as an MP3…",
        )
        video_url = f"https://www.youtube.com/watch?v={video_id}"
        track = await yt.search(video_url, requester_id)
        audio_path = await yt.download(
            track.id if track else video_id,
            video=False,
            url=track.url if track else video_url,
        )
        if not audio_path or not Path(audio_path).is_file():
            await _edit_status(
                status,
                "I couldn't download that song. It may be private, unavailable, "
                "or temporarily blocked. Try another result.",
            )
            return

        send_options = {
            "chat_id": requester_id,
            "audio": audio_path,
        }
        if track:
            send_options.update(
                title=track.title[:64],
                performer=track.channel_name[:64],
            )

        try:
            await app.send_audio(**send_options)
        except FloodWait as exc:
            await _edit_status(
                status, "Telegram is rate-limiting the upload. Retrying shortly…"
            )
            await asyncio.sleep(exc.value + 1)
            await app.send_audio(**send_options)

        try:
            await status.delete()
        except Exception:
            pass
    except Exception as exc:
        logger.warning(
            "Inline MP3 delivery failed (%s).", type(exc).__name__
        )
        await _edit_status(
            status,
            "I couldn't send that MP3 to your DM. Please try another song result.",
        )
    finally:
        _downloads_in_progress.discard(download_key)
