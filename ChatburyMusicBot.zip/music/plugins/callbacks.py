# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic


import re
from pathlib import Path

from pyrogram import enums, errors, filters, types

from config import BOT_NAME
from music import anon, app, db, lang, logger, queue, tg, yt
from music.helpers import Track, admin_check, buttons


@app.on_callback_query(filters.regex("cancel_dl") & ~app.bl_users)
@lang.language()
async def cancel_dl(_, query: types.CallbackQuery):
    await query.answer()
    await tg.cancel(query)


@app.on_callback_query(filters.regex("controls") & ~app.bl_users)
@lang.language()
async def _controls(_, query: types.CallbackQuery):
    args = query.data.split()
    action, chat_id = args[1], int(args[2])
    qaction = len(args) == 4
    user = query.from_user.mention

    if action not in {"rec", "close", "save", "similar", "queue", "status"}:
        try:
            allowed = (
                query.from_user.id in app.sudoers
                or await db.is_auth(chat_id, query.from_user.id)
                or query.from_user.id in await db.get_admins(chat_id, reload=True)
            )
        except Exception:
            return await query.answer(
                "Music permissions are temporarily unavailable. Try again shortly.",
                show_alert=True,
            )
        if not allowed:
            return await query.answer(
                query.lang["user_no_perms"], show_alert=True
            )

    if action == "close":
        media = queue.get_current(chat_id)
        if media and media.message_id == query.message.id:
            media.message_id = 0
        await query.answer()
        try:
            await query.message.delete()
        except Exception:
            pass
        return

    if action == "save":
        media = queue.get_current(chat_id)
        if not media:
            return await query.answer("There is no current song to save.", show_alert=True)
        try:
            await db.save_favorite(query.from_user.id, media)
        except Exception as exc:
            logger.warning("Could not save favorite (%s).", type(exc).__name__)
            return await query.answer("Favorites are temporarily unavailable.", show_alert=True)
        return await query.answer("Saved to your favorites.")

    if action == "similar":
        from music.plugins.premium import send_current_recommendations

        await send_current_recommendations(query.message, query.from_user.id, chat_id)
        return await query.answer()

    if action == "queue":
        items = queue.get_queue(chat_id)
        if not items:
            return await query.answer("The queue is empty.", show_alert=True)
        lines = ["<b>Voice-chat queue</b>"]
        for index, item in enumerate(items[:20], 1):
            title = (item.title or "Unknown title").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            lines.append(f"{index}. {title}")
        if len(items) > 20:
            lines.append(f"…and {len(items) - 20} more")
        await query.message.reply_text("\n".join(lines))
        return await query.answer()

    if action == "status":
        return await query.answer()

    if not await db.get_call(chat_id):
        return await query.answer(query.lang["not_playing"], show_alert=True)

    if action == "radio":
        enabled = not anon.is_radio_enabled(chat_id)
        await anon.set_radio(chat_id, enabled)
        added = 0
        if enabled:
            media = queue.get_current(chat_id)
            if media:
                added = await anon._fill_radio(chat_id, media)
        else:
            items = queue.get_queue(chat_id)
            queue.restore(
                chat_id,
                items[:1]
                + [item for item in items[1:] if getattr(item, "user", "") != "Radio"],
            )
            await anon._persist_queue(chat_id)
        await anon.update_player(chat_id)
        return await query.answer(
            f"Radio {'on' if enabled else 'off'}."
            + (f" Added {added} verified public track(s)." if enabled else "")
        )

    if action == "shuffle":
        changed = queue.shuffle_upcoming(chat_id)
        if changed:
            await anon._persist_queue(chat_id)
        return await query.answer(
            "Upcoming tracks shuffled." if changed else "Add at least two upcoming tracks to shuffle.",
            show_alert=not changed,
        )

    if action == "loop":
        mode = anon.cycle_loop(chat_id)
        try:
            await query.edit_message_reply_markup(
                reply_markup=buttons.controls(chat_id)
            )
        except Exception as exc:
            logger.debug("Could not refresh loop controls (%s).", type(exc).__name__)
        return await query.answer(f"Loop mode: {mode}.")

    if action == "previous":
        if not await anon.play_previous(chat_id):
            return await query.answer("There is no previous track yet.", show_alert=True)
        return await query.answer("Playing the previous track.")

    if action == "next":
        await anon.play_next(chat_id)
        return await query.answer("Skipped to the next track.")

    if action == "autoplay":
        enabled = anon.toggle_autoplay(chat_id)
        await query.answer(f"Autoplay {'enabled' if enabled else 'disabled'}.")
        try:
            await query.edit_message_reply_markup(
                reply_markup=buttons.controls(chat_id, autoplay=enabled)
            )
        except Exception as exc:
            logger.warning("Could not update autoplay controls (%s).", type(exc).__name__)
        return

    if action == "pause":
        if not await db.playing(chat_id):
            return await query.answer(query.lang["play_already_paused"], show_alert=True)
        try:
            await anon.pause(chat_id)
        except Exception as exc:
            logger.warning("Pause failed (%s).", type(exc).__name__)
            return await query.answer("Could not pause playback. Try again.", show_alert=True)
        return await query.answer("Paused.")

    if action == "resume":
        if await db.playing(chat_id):
            return await query.answer(query.lang["play_not_paused"], show_alert=True)
        try:
            await anon.resume(chat_id)
        except Exception as exc:
            logger.warning("Resume failed (%s).", type(exc).__name__)
            return await query.answer("Could not resume playback. Try again.", show_alert=True)
        return await query.answer("Resumed.")

    if action == "skip":
        await anon.play_next(chat_id)
        return await query.answer("Skipped.")

    if action == "replay":
        await anon.replay(chat_id)
        return await query.answer("Replaying the current track.")

    if action == "stop":
        await anon.stop(chat_id)
        return await query.answer("Playback stopped and the queue was cleared.")

    if action == "rec":
        media = queue.get_current(chat_id)
        if not media:
            return await query.answer("There is no current song to send.", show_alert=True)
        try:
            status = await app.send_message(
                query.from_user.id,
                "• "
                "Preparing the current song as an MP3…",
            )
        except errors.PeerIdInvalid:
            return await query.answer(
                "Open the bot's private chat and press Start, then try Rec again.",
                show_alert=True,
            )
        except Exception as exc:
            logger.warning("Could not start MP3 DM delivery (%s).", type(exc).__name__)
            return await query.answer(
                "I couldn't open your private chat. Start the bot and try Rec again.",
                show_alert=True,
            )

        await query.answer("Sending the MP3 to your private chat.")
        try:
            path = Path(media.file_path) if media.file_path else None
            if not path or not path.is_file() or path.suffix.lower() != ".mp3":
                if not isinstance(media, Track):
                    await status.edit_text(
                        "<emoji id=5881702736843511327>⚠️</emoji> "
                        "Rec MP3 is available for audio tracks only."
                    )
                    return
                audio_path = await yt.download(
                    media.id, video=False, url=getattr(media, "url", None)
                )
                path = Path(audio_path) if audio_path else None
            if not path or not path.is_file():
                await status.edit_text(
                    "<emoji id=5881702736843511327>⚠️</emoji> "
                    "I couldn't prepare an MP3 for this song. Try another track."
                )
                return
            await app.send_audio(
                chat_id=query.from_user.id,
                audio=str(path),
                title=(media.title or "Music")[:64],
                performer=(
                    getattr(media, "artist", None)
                    or getattr(media, "channel_name", None)
                    or app.name
                )[:64],
                duration=max(1, int(getattr(media, "duration_sec", 0) or 1)),
            )
            try:
                await status.edit_text(
                    "<emoji id=5823396554345549784>✅</emoji> "
                    "The MP3 was sent to your private chat."
                )
            except Exception:
                pass
        except Exception as exc:
            logger.warning("MP3 DM delivery failed (%s).", type(exc).__name__)
            try:
                await status.edit_text(
                    "<emoji id=5881702736843511327>⚠️</emoji> "
                    "I couldn't send the MP3. Start the bot's private chat and try Rec again."
                )
            except Exception:
                pass
        return

    if action == "seek":
        media = queue.get_current(chat_id)
        if not media:
            return await query.answer(query.lang["not_playing"], show_alert=True)
        try:
            offset = int(args[3])
        except (IndexError, ValueError):
            return await query.answer("Invalid seek amount.", show_alert=True)
        duration = max(1, int(media.duration_sec or 1))
        target = max(1, min(duration - 1, int(media.time or 1) + offset))
        was_playing = await db.playing(chat_id)
        await query.answer("Seeking…")
        await anon.play_media(
            chat_id=chat_id,
            message=query.message,
            media=media,
            seek_time=target,
        )
        if not was_playing:
            await anon.pause(chat_id)
        try:
            await query.edit_message_reply_markup(
                reply_markup=buttons.controls(chat_id)
            )
        except Exception as exc:
            logger.debug("Could not refresh seek progress (%s).", type(exc).__name__)
        return

    if action != "force":
        await query.answer(query.lang["processing"])

    if action == "pause":
        if not await db.playing(chat_id):
            return await query.answer(
                query.lang["play_already_paused"], show_alert=True
            )
        await anon.pause(chat_id)
        if qaction:
            return await query.edit_message_reply_markup(
                reply_markup=buttons.queue_markup(chat_id, query.lang["paused"], False)
            )
        status = query.lang["paused"]
        reply = query.lang["play_paused"].format(user)

    elif action == "resume":
        if await db.playing(chat_id):
            return await query.answer(query.lang["play_not_paused"], show_alert=True)
        await anon.resume(chat_id)
        if qaction:
            return await query.edit_message_reply_markup(
                reply_markup=buttons.queue_markup(chat_id, query.lang["playing"], True)
            )
        reply = query.lang["play_resumed"].format(user)

    elif action == "skip":
        await anon.play_next(chat_id)
        status = query.lang["skipped"]
        reply = query.lang["play_skipped"].format(user)

    elif action == "force":
        pos, media = queue.check_item(chat_id, args[3])
        if not media or pos == -1:
            return await query.edit_message_text(query.lang["play_expired"])

        queued_before = queue.get_queue(chat_id)
        current = queue.get_current(chat_id)
        m_id = getattr(current, "message_id", None)
        if not media.file_path and not getattr(media, "stream_url", None):
            media.file_path = await yt.download(
                media.id, video=media.video, url=getattr(media, "url", None)
            )
        if not media.file_path and not getattr(media, "stream_url", None):
            return await query.answer(
                "This queued track has no playable audio source yet. The queue card is unchanged.",
                show_alert=True,
            )

        queue.force_add(chat_id, media, remove=pos)
        await anon._persist_queue(chat_id)

        msg = await app.send_message(chat_id=chat_id, text=query.lang["play_next"])
        started = await anon.play_media(chat_id, msg, media)
        if not started:
            queue.restore(chat_id, queued_before)
            await anon._persist_queue(chat_id)
            return await query.answer(
                "Playback did not start; the queue was restored.",
                show_alert=True,
            )

        # Remove the old player and the Play Now card only after audio starts.
        queued_card_id = query.message.id
        try:
            ids_to_delete = list(
                {
                    int(message_id)
                    for message_id in (m_id, queued_card_id)
                    if message_id
                }
            )
            if ids_to_delete:
                await app.delete_messages(
                    chat_id=chat_id, message_ids=ids_to_delete, revoke=True
                )
        except Exception as exc:
            logger.warning(
                "Could not remove the previous player/queue card after Play Now (%s).",
                type(exc).__name__,
            )
        return await query.answer("Playing now.")

    elif action == "replay":
        media = queue.get_current(chat_id)
        media.user = user
        await anon.replay(chat_id)
        status = query.lang["replayed"]
        reply = query.lang["play_replayed"].format(user)

    elif action == "stop":
        await anon.stop(chat_id)
        status = query.lang["stopped"]
        reply = query.lang["play_stopped"].format(user)

    try:
        if action in ["skip", "replay", "stop"]:
            await query.message.reply_text(reply, quote=False)
            await query.message.delete()
        else:
            mtext = re.sub(
                r"\n\n<blockquote>.*?</blockquote>",
                "",
                query.message.caption.html or query.message.text.html,
                flags=re.DOTALL,
            )
            keyboard = buttons.controls(
                chat_id, status=status if action != "resume" else None
            )
        await query.edit_message_text(
            f"{mtext}\n\n<blockquote>{reply}</blockquote>", reply_markup=keyboard
        )
    except:
        pass


#
MUSIC_HELP_CALLBACK_PATTERN = r"^help(?:\s|$)"


@app.on_callback_query(filters.regex(MUSIC_HELP_CALLBACK_PATTERN) & ~app.bl_users)
@lang.language()
async def _help(_, query: types.CallbackQuery):
    await query.answer()
    data = query.data.split()
    if len(data) == 1:
        try:
            return await query.edit_message_text(
                text=f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\n{query.lang['help_menu']}",
                reply_markup=buttons.help_markup(query.lang),
            )
        except:
            return await query.edit_message_caption(
                caption=f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\n{query.lang['help_menu']}",
                reply_markup=buttons.help_markup(query.lang),
            )

    if data[1] == "back":
        try:
            return await query.edit_message_text(
                text=f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\n{query.lang['help_menu']}",
                reply_markup=buttons.help_markup(query.lang),
            )
        except:
            return await query.edit_message_caption(
                caption=f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\n{query.lang['help_menu']}",
                reply_markup=buttons.help_markup(query.lang),
            )
    elif data[1] == "close":
        try:
            await query.message.delete()
            await query.message.reply_to_message.delete()
        except:
            pass
        return

    try:
        await query.edit_message_text(
            text=query.lang[f"help_{data[1]}"],
            reply_markup=buttons.help_markup(query.lang, True),
        )
    except:
        await query.edit_message_caption(
            caption=query.lang[f"help_{data[1]}"],
            reply_markup=buttons.help_markup(query.lang, True),
        )


@app.on_callback_query(filters.regex(r"^music_help_home_\d+$") & ~app.bl_users)
@lang.language()
async def _music_help_home(_, query: types.CallbackQuery):
    try:
        target_user_id = int(query.data.rsplit("_", 1)[-1])
    except (AttributeError, ValueError):
        return await query.answer("This menu button is invalid.", show_alert=True)
    if not query.from_user or query.from_user.id != target_user_id:
        return await query.answer("This menu belongs to another user.", show_alert=True)
    await query.answer()
    text = f"<blockquote><b>{BOT_NAME} Board</b></blockquote>\n\n{query.lang['help_menu']}"
    markup = buttons.help_markup(query.lang)
    try:
        await query.edit_message_text(text=text, reply_markup=markup)
    except Exception:
        await query.edit_message_caption(caption=text, reply_markup=markup)


@app.on_callback_query(filters.regex("^settings_back_helper$") & ~app.bl_users)
@lang.language()
async def _back_helper(_, query: types.CallbackQuery):
    await query.answer()
    private = query.message.chat.type == enums.ChatType.PRIVATE
    _text = (
        query.lang["start_pm"].format(query.from_user.first_name, BOT_NAME)
        if private
        else query.lang["start_gp"].format(BOT_NAME)
    )
    key = buttons.start_key(query.lang, private)
    try:
        await query.edit_message_text(_text, reply_markup=key)
    except:
        await query.edit_message_caption(caption=_text, reply_markup=key)


@app.on_callback_query(filters.regex("settings") & ~app.bl_users)
@lang.language()
@admin_check
async def _settings_cb(_, query: types.CallbackQuery):
    cmd = query.data.split()
    if len(cmd) == 1:
        return await query.answer()
    await query.answer(query.lang["processing"], show_alert=True)

    chat_id = query.message.chat.id
    _admin = await db.get_play_mode(chat_id)
    _delete = await db.get_cmd_delete(chat_id)
    _language = await db.get_lang(chat_id)

    if cmd[1] == "delete":
        _delete = not _delete
        await db.set_cmd_delete(chat_id, _delete)
    elif cmd[1] == "play":
        _admin = not _admin
        await db.set_play_mode(chat_id, _admin)
    await query.edit_message_reply_markup(
        reply_markup=buttons.settings_markup(
            query.lang,
            _admin,
            _delete,
            _language,
            chat_id,
        )
    )
