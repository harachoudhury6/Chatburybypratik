# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
# ALONE-CODER

import asyncio
import os
import time
from pyrogram import filters, enums
from pyrogram.types import Message
from pyrogram.errors import FloodWait

from music import app, db, lang, userbot, logger, tasks
from config import settings

IS_BROADCASTING = False

# Local constants and variables for background tasks
CACHE_DURATION = 3600
CACHE_SLEEP = 300
file_cache = {}
autoclean = []

def parse_flags(text: str):
    return {
        "pin": "-pin" in text,
        "pinloud": "-pinloud" in text,
        "nobot": "-nobot" in text,
        "user": "-user" in text,
        "assistant": "-assistant" in text
    }

async def broadcast_to_targets(client, targets, query, y=None, x=None, pin=False, pinloud=False):
    global IS_BROADCASTING
    sent = 0
    pinned = 0
    footer = f"\n\nBroadcasted by {app.name}"
    for target_id in targets:
        if not IS_BROADCASTING:
            break
        try:
            if x and y:
                m = await client.forward_messages(target_id, y, x)
            else:
                m = await client.send_message(target_id, text=query + footer)

            if pin:
                try:
                    await m.pin(disable_notification=True)
                    pinned += 1
                except:
                    pass
            elif pinloud:
                try:
                    await m.pin(disable_notification=False)
                    pinned += 1
                except:
                    pass
            sent += 1
            await asyncio.sleep(0.2)

        except FloodWait as fw:
            if fw.value > 200:
                continue
            await asyncio.sleep(fw.value)
        except:
            continue
    return sent, pinned

@app.on_message(
    filters.command(["broadcast", "gcast"]) & filters.user(settings.OWNER_ID)
)
@lang.language()
async def broadcast_message(client, message: Message):
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return await message.reply_text("Broadcast setup is available to the owner only.")
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text(
            "For safety, open a private chat with the bot and use /admin → Create broadcast."
        )

    from management.plugins.broadcast import begin_owner_broadcast

    await begin_owner_broadcast(
        client,
        user.id,
        mode="all",
        source_message=message.reply_to_message,
    )

@app.on_message(
    filters.command(["stop_gcast", "stop_broadcast"]) & filters.user(settings.OWNER_ID)
)
async def stop_broadcast_handler(_, message: Message):
    if not message.from_user or message.from_user.id != settings.OWNER_ID:
        return await message.reply_text("Only the owner can stop a broadcast.")
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text("Use this command in the bot's private chat.")
    from management.plugins.broadcast import request_stop_broadcast

    if not request_stop_broadcast(message.from_user.id):
        return await message.reply_text("No broadcast is currently running.")
    await message.reply_text("The broadcast will stop after the current delivery.")

async def auto_clean():
    while not await asyncio.sleep(10):
        try:
            served_chats = await db.get_chats()
            for chat_id in served_chats:
                if chat_id not in db.admin_list:
                    db.admin_list[chat_id] = []
                    async for user in app.get_chat_members(
                        chat_id, filter=enums.ChatMembersFilter.ADMINISTRATORS
                    ):
                        if user.privileges and user.privileges.can_manage_video_chats:
                            db.admin_list[chat_id].append(user.user.id)

                    auth_users = await db._get_auth(chat_id)
                    for user_id in auth_users:
                        db.admin_list[chat_id].append(user_id)
        except:
            continue

async def auto_clean_cache():
    while not await asyncio.sleep(CACHE_SLEEP):
        try:
            now = time.time()
            expired = [
                f for f, t in file_cache.items()
                if now - t > CACHE_DURATION and f not in autoclean
            ]
            for file in expired:
                try:
                    if os.path.exists(file):
                        os.remove(file)
                        file_cache.pop(file, None)
                except:
                    continue
        except:
            continue

tasks.append(asyncio.create_task(auto_clean()))
tasks.append(asyncio.create_task(auto_clean_cache()))
