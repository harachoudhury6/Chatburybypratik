# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic


import time

from pyrogram import enums, filters, types

from music import app, db, lang, logger
from music.helpers._admins import is_admin
from music.helpers import utils


@app.on_message(filters.command(["auth", "unauth"]) & filters.group & ~app.bl_users)
@lang.language()
async def _auth(_, m: types.Message):
    if not m.from_user:
        return
    try:
        member = await app.get_chat_member(m.chat.id, m.from_user.id)
        if member.status not in (
            enums.ChatMemberStatus.ADMINISTRATOR,
            enums.ChatMemberStatus.OWNER,
        ):
            return await m.reply_text("Only this group's owner and admins can manage music access.")
    except Exception as exc:
        logger.warning("Could not verify music-auth admin (%s).", type(exc).__name__)
        return await m.reply_text("I couldn't verify your current admin status. Please try again.")

    user = await utils.extract_user(m)
    if not user:
        return await m.reply_text(m.lang["user_not_found"])

    if m.command[0] == "auth":
        if await is_admin(m.chat.id, user.id):
            return await m.reply_text(m.lang["auth_is_admin"])

        await db.add_auth(m.chat.id, user.id)
        await m.reply_text(m.lang["auth_added"].format(user.mention))
    else:
        await db.rm_auth(m.chat.id, user.id)
        await m.reply_text(m.lang["auth_removed"].format(user.mention))


rel_hist = {}

@app.on_message(filters.command(["reload", "admincache", "musicreload"]) & filters.group & ~app.bl_users)
@lang.language()
async def _admincache(_, m: types.Message):
    if not m.from_user:
        return
    key = (m.chat.id, m.from_user.id)
    try:
        member = await app.get_chat_member(m.chat.id, m.from_user.id)
        if member.status not in (
            enums.ChatMemberStatus.ADMINISTRATOR,
            enums.ChatMemberStatus.OWNER,
        ):
            return await m.reply_text("Only this group's owner and admins can reload its admin list.")
    except Exception as exc:
        logger.warning("Could not verify reload admin (%s).", type(exc).__name__)
        return await m.reply_text("I couldn't verify your current admin status. Please try again.")

    if key in rel_hist:
        if time.time() < rel_hist[key]:
            return await m.reply_text(m.lang["admin_cache_wait"])

    rel_hist[key] = time.time() + 10
    sent = await m.reply_text(m.lang["admin_cache_reloading"])
    admins = await db.get_admins(m.chat.id, reload=True)
    await sent.edit_text(f"{m.lang['admin_cache_reloaded']}\nCurrent group admins: {len(admins)}.")
