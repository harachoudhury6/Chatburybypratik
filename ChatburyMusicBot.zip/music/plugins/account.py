"""Owner-only private login flow for the music assistant account."""

from __future__ import annotations

import asyncio
import logging
import re
import time
from pathlib import Path
from typing import Any

from pyrogram import Client, enums, errors, filters, types

from config import set_music_account_id, settings
from music import anon, app, config, db, userbot

logger = logging.getLogger("eiko.music.account")
_flows: dict[int, dict[str, Any]] = {}
_pending_music_id_inputs: dict[int, float] = {}
_pending_music_only_chat_inputs: dict[int, float] = {}
_pending_public_username_inputs: dict[int, tuple[str, float]] = {}
_pending_search_indicator_inputs: dict[int, float] = {}
_OWNER_PUBLIC_USERNAME_INPUT_GROUP = -10001
_OWNER_MUSIC_ACCOUNT_INPUT_GROUP = -10000
_OWNER_SEARCH_INDICATOR_INPUT_GROUP = -10002
_OWNER_MUSIC_ONLY_CHAT_INPUT_GROUP = -10003
_MUSIC_ID_PROMPT_TTL = 10 * 60
_login_lock = asyncio.Lock()
_SESSION_PATH = userbot.sessions_dir / "music_assistant_1.session"
_MUSIC_SESSION_NAME = re.compile(r"music_assistant_[a-zA-Z0-9_-]{1,24}\Z")


def _is_managed_session_name(session_name: str) -> bool:
    return bool(_MUSIC_SESSION_NAME.fullmatch(session_name))


def parse_music_account_id(value: str) -> int | None:
    """Parse a positive Telegram user ID, or None for the configured default."""
    normalized = value.strip()
    if normalized.casefold() == "reset":
        return None
    if not normalized.isascii() or not normalized.isdigit() or len(normalized) > 15:
        raise ValueError(
            "Enter a positive personal Telegram user ID (not a group chat ID), or `reset`."
        )
    user_id = int(normalized)
    if user_id <= 0:
        raise ValueError("Telegram user ID must be positive.")
    return user_id


def parse_music_only_chat_id(value: str) -> int:
    """Parse a negative Telegram group or supergroup chat ID."""
    normalized = value.strip()
    if (
        not normalized.startswith("-")
        or not normalized[1:].isascii()
        or not normalized[1:].isdigit()
        or len(normalized) > 16
    ):
        raise ValueError("Enter the group's negative numeric chat ID, such as -1001234567890.")
    user_id = int(normalized)
    if user_id >= 0:
        raise ValueError("Group chat ID must be negative.")
    return user_id


def _music_only_chat_markup(chat_ids: list[int], page: int = 0):
    page_size = 20
    last_page = max(0, (len(chat_ids) - 1) // page_size)
    page = max(0, min(page, last_page))
    current = chat_ids[page * page_size : (page + 1) * page_size]
    rows = [
        [
            types.InlineKeyboardButton(
                f"Remove {chat_id}",
                callback_data=f"owner_admin:music_only_chat_remove:{chat_id}",
            )
        ]
        for chat_id in current
    ]
    navigation = []
    if page:
        navigation.append(
            types.InlineKeyboardButton(
                "Previous",
                callback_data=f"owner_admin:music_only_chat_page:{page - 1}",
            )
        )
    if page < last_page:
        navigation.append(
            types.InlineKeyboardButton(
                "Next",
                callback_data=f"owner_admin:music_only_chat_page:{page + 1}",
            )
        )
    if navigation:
        rows.append(navigation)
    return types.InlineKeyboardMarkup(rows)


def _remove_session_files(session_name: str = "music_assistant_1") -> None:
    if not _is_managed_session_name(session_name):
        return
    session_path = userbot.sessions_dir / f"{session_name}.session"
    for suffix in ("", "-journal", "-wal", "-shm"):
        try:
            Path(f"{session_path}{suffix}").unlink(missing_ok=True)
        except OSError:
            pass


def _clear_local_music_sessions(
    *, include_primary: bool
) -> tuple[int, bool]:
    """Clear inactive local music sessions without claiming remote Telegram logout."""
    primary_names = {
        "music_assistant_1",
        "music_assistant_2",
        "music_assistant_3",
    }
    cleared = 0
    failed = False
    for session_path in tuple(userbot.sessions_dir.glob("music_assistant_*.session")):
        session_name = session_path.stem
        if not _is_managed_session_name(session_name):
            continue
        if not include_primary and session_name in primary_names:
            continue
        _remove_session_files(session_name)
        if session_path.exists():
            failed = True
        else:
            cleared += 1
    return cleared, failed


async def _logout_orphan_music_sessions() -> tuple[int, bool]:
    """Log out old managed music sessions not represented by current clients."""
    known_names = {
        "music_assistant_1",
        "music_assistant_2",
        "music_assistant_3",
    }
    logged_out = 0
    failed = False
    for session_path in tuple(userbot.sessions_dir.glob("music_assistant_*.session")):
        session_name = session_path.stem
        if session_name in known_names or not _is_managed_session_name(session_name):
            continue
        client = Client(
            name=session_name,
            workdir=str(userbot.sessions_dir),
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            no_updates=True,
        )
        try:
            authorized = await client.connect()
            if authorized:
                await client.log_out()
            else:
                await client.disconnect()
            _remove_session_files(session_name)
            logged_out += 1
        except Exception as exc:
            failed = True
            logger.warning(
                "Could not log out a legacy music session (%s); its files were kept.",
                type(exc).__name__,
            )
            try:
                await client.disconnect()
            except Exception:
                pass
    return logged_out, failed


def _secure_session_file() -> None:
    for suffix in ("", "-journal", "-wal", "-shm"):
        path = Path(f"{_SESSION_PATH}{suffix}")
        if path.exists():
            try:
                path.chmod(0o600)
            except OSError:
                pass


def _is(exc: Exception, *names: str) -> bool:
    return type(exc).__name__ in names


async def _delete(message: types.Message) -> None:
    try:
        await message.delete()
    except Exception:
        pass


async def _disconnect(client) -> None:
    try:
        if client.is_connected:
            await client.disconnect()
    except Exception:
        pass


async def _discard_flow(owner_id: int) -> None:
    flow = _flows.pop(owner_id, None)
    if flow:
        await _disconnect(flow["client"])
        _remove_session_files(flow.get("session_name", "music_assistant_1"))


async def _start_assistant(client) -> bool:
    if client.is_connected:
        await client.disconnect()
    try:
        if not await userbot.boot_client(1, client):
            return False
        try:
            await anon.add_assistant(client)
        except Exception as exc:
            if client in userbot.clients:
                userbot.clients.remove(client)
            await _disconnect(client)
            logger.warning("Voice-call assistant startup failed (%s).", type(exc).__name__)
            return False
        _secure_session_file()
        return True
    except Exception as exc:
        logger.warning("Could not activate the music assistant (%s).", type(exc).__name__)
        return False


@app.on_message(filters.command("setmusicaccount"))
async def set_music_account_command(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return await message.reply_text("Only the configured bot owner can change the music account ID.")
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text("For security, send /setmusicaccount to me in a private chat.")

    command = message.command or []
    if len(command) != 2:
        return await message.reply_text(
            "Usage: /setmusicaccount <personal_telegram_user_id|reset>\n"
            "Use a positive user ID, not a group chat ID. Then run /login privately."
        )

    try:
        requested_id = parse_music_account_id(command[1])
    except ValueError as exc:
        return await message.reply_text(str(exc))

    await _save_music_account_id(message, requested_id)


@app.on_message(filters.command("removemusicaccount"))
async def remove_music_account_command(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return await message.reply_text(
            "Only the configured bot owner can remove the custom music account ID."
        )
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text(
            "For security, send /removemusicaccount to me in a private chat."
        )
    _pending_music_id_inputs.pop(settings.OWNER_ID, None)
    await _save_music_account_id(message, None)


def _has_connected_music_assistant() -> bool:
    if userbot.clients or anon.clients:
        return True
    pending_client = (_flows.get(settings.OWNER_ID) or {}).get("client")
    for client in (userbot.one, userbot.two, userbot.three):
        if client is pending_client:
            continue
        try:
            if client.is_connected:
                return True
        except Exception:
            continue
    return False


async def _save_music_account_id(
    message: types.Message, requested_id: int | None
) -> None:
    async with _login_lock:
        if _has_connected_music_assistant():
            return await message.reply_text(
                "A music assistant is connected right now. Use /logout in this private "
                "chat first, then set or remove the ID."
            )
        if any((config.SESSION1, config.SESSION2, config.SESSION3)):
            return await message.reply_text(
                "A SESSION1, SESSION2, or SESSION3 Secret is configured. Remove those "
                "session-string Secrets and restart before changing the music account ID."
            )

        pending_login = settings.OWNER_ID in _flows
        if pending_login:
            await _discard_flow(settings.OWNER_ID)

        default_id = settings.DEFAULT_MUSIC_ACCOUNT_ID
        target_id = default_id if requested_id is None else requested_id
        identity_changed = target_id != settings.MUSIC_ACCOUNT_ID

        try:
            existing_override = await db.get_music_account_id_override()
            if requested_id is None:
                await db.clear_music_account_id_override()
                set_music_account_id(default_id)
                reply = (
                    f"Custom music account ID removed. The configured default "
                    f"({default_id}) is now active."
                    if existing_override is not None
                    else f"No custom ID was saved; the configured default "
                    f"({default_id}) remains active."
                )
            elif requested_id == settings.MUSIC_ACCOUNT_ID:
                reply = f"Music account user ID {requested_id} is already configured."
            else:
                await db.set_music_account_id_override(requested_id)
                set_music_account_id(requested_id)
                reply = (
                    f"Music account user ID {requested_id} saved. This only changes "
                    "the account ID; use /login privately to authorize that account."
                )
        except Exception as exc:
            logger.warning(
                "Could not save the owner-configured music account ID (%s).",
                type(exc).__name__,
            )
            return await message.reply_text(
                "I couldn't save that setting to MongoDB. No account ID was changed."
            )

        cleared, cleanup_failed = _clear_local_music_sessions(
            include_primary=identity_changed
        )
        if cleared:
            reply += (
                f" Cleared {cleared} inactive local session file(s) so the next /login "
                "starts clean. This does not log those accounts out of Telegram; revoke "
                "old sessions in Telegram Settings → Devices if needed."
            )
        if cleanup_failed:
            reply += (
                " One old local session file could not be removed; /login may still find "
                "it. Check the private sessions folder before retrying."
            )
        if pending_login:
            reply += " The unfinished login request was cancelled."
        return await message.reply_text(reply)


@app.on_callback_query(filters.regex(r"^owner_admin:"))
async def owner_admin_callback(client, query: types.CallbackQuery) -> None:
    if (
        not query.from_user
        or query.from_user.id != settings.OWNER_ID
        or not query.message
        or query.message.chat.type != enums.ChatType.PRIVATE
    ):
        return await query.answer("This owner panel is private and owner-only.", show_alert=True)

    parts = query.data.split(":")
    action = parts[1] if len(parts) > 1 else ""
    if action == "music_only_chat_add":
        _pending_music_id_inputs.pop(settings.OWNER_ID, None)
        _pending_public_username_inputs.pop(settings.OWNER_ID, None)
        _pending_search_indicator_inputs.pop(settings.OWNER_ID, None)
        _pending_music_only_chat_inputs[settings.OWNER_ID] = (
            time.monotonic() + _MUSIC_ID_PROMPT_TTL
        )
        await query.answer()
        return await query.message.reply_text(
            "Send the group's numeric chat ID (it starts with a minus sign). "
            "That group will show and allow music commands only. Send /cancel to abort."
        )
    if action == "music_only_chat_remove" and len(parts) == 2:
        try:
            chat_ids = sorted(await db.get_music_only_chat_ids())
        except Exception as exc:
            logger.warning("Could not list music-only groups (%s).", type(exc).__name__)
            return await query.answer("Could not load the configured groups.", show_alert=True)
        if not chat_ids:
            await query.answer("No music-only groups are configured.", show_alert=True)
            return await query.message.reply_text("There are no music-only group IDs to remove.")
        await query.answer()
        return await query.message.reply_text(
            "Select the music-only group ID to remove:",
            reply_markup=_music_only_chat_markup(chat_ids),
        )
    if action == "music_only_chat_page" and len(parts) == 3:
        try:
            page = int(parts[2])
            chat_ids = sorted(await db.get_music_only_chat_ids())
        except (ValueError, TypeError):
            return await query.answer("Invalid list page.", show_alert=True)
        if not chat_ids:
            return await query.answer("No music-only groups are configured.", show_alert=True)
        await query.answer()
        return await query.message.edit_text(
            "Select the music-only group ID to remove:",
            reply_markup=_music_only_chat_markup(chat_ids, page),
        )
    if action == "music_only_chat_remove" and len(parts) == 3:
        try:
            chat_id = int(parts[2])
            if not await db.is_music_only_chat(chat_id):
                return await query.answer("That group is not configured.", show_alert=True)
            await db.remove_music_only_chat(chat_id)
        except (ValueError, TypeError):
            return await query.answer("Invalid group ID.", show_alert=True)
        except Exception as exc:
            logger.warning("Could not remove music-only group (%s).", type(exc).__name__)
            return await query.answer("Could not remove that group.", show_alert=True)
        try:
            from management.command_menu import restore_chat_commands

            await restore_chat_commands(client, chat_id)
        except Exception as exc:
            logger.warning("Could not restore group command menu (%s).", type(exc).__name__)
            await query.answer(
                "Music-only mode is removed, but Telegram rejected the menu reset. "
                "Commands work; reopen /admin and retry if the slash menu stays limited.",
                show_alert=True,
            )
        else:
            await query.answer("Music-only mode removed.")
        return await query.message.reply_text(
            f"Music-only mode removed for group <code>{chat_id}</code>. "
            "Normal bot commands are enabled again.",
            parse_mode=enums.ParseMode.HTML,
        )
    if action in {"owner_username", "support_username"}:
        field = f"{action}"
        _pending_music_id_inputs.pop(settings.OWNER_ID, None)
        _pending_public_username_inputs[settings.OWNER_ID] = (
            field,
            time.monotonic() + _MUSIC_ID_PROMPT_TTL,
        )
        await query.answer()
        target = "owner" if field == "owner_username" else "support"
        return await query.message.reply_text(
            f"Send the {target} Telegram username, with or without @. "
            "A direct t.me/username link also works. Send /cancel to abort."
        )
    if action in {"clear_owner_username", "reset_support_username"}:
        from management.db.owner_profile import reset_public_username

        field = "owner_username" if action == "clear_owner_username" else "support_username"
        try:
            value = await reset_public_username(field)
        except Exception as exc:
            logger.warning("Could not reset a public username (%s).", type(exc).__name__)
            await query.answer("Could not save that setting. Try again.", show_alert=True)
            return
        await query.answer("Setting updated.")
        value_label = f"@{value}" if value else "not set"
        return await query.message.reply_text(
            f"{'Owner' if field == 'owner_username' else 'Support'} username reset to {value_label}."
        )
    if action == "search_indicator":
        _pending_music_id_inputs.pop(settings.OWNER_ID, None)
        _pending_public_username_inputs.pop(settings.OWNER_ID, None)
        _pending_search_indicator_inputs[settings.OWNER_ID] = (
            time.monotonic() + _MUSIC_ID_PROMPT_TTL
        )
        await query.answer()
        return await query.message.reply_text(
            "Send the exact text/emoji you want during /play search, or send a sticker "
            "to use that sticker. Send /cancel to keep the current setting."
        )
    if action == "reset_search_indicator":
        from management.db.search_indicator import reset_search_indicator

        try:
            await reset_search_indicator()
        except Exception as exc:
            logger.warning("Could not reset the search indicator (%s).", type(exc).__name__)
            return await query.answer("Could not reset the setting.", show_alert=True)
        _pending_search_indicator_inputs.pop(settings.OWNER_ID, None)
        await query.answer("Search indicator reset.")
        return await query.message.reply_text("The default localized search text is active again.")
    if action == "music_id":
        _pending_public_username_inputs.pop(settings.OWNER_ID, None)
        _pending_music_id_inputs[settings.OWNER_ID] = (
            time.monotonic() + _MUSIC_ID_PROMPT_TTL
        )
        await query.answer()
        return await query.message.reply_text(
            "Send the playback account's positive personal Telegram user ID—not a group "
            "chat ID. Setting this does not log in; use /login afterward to authorize "
            "that account. When changing accounts, inactive local session files are cleared "
            "so the next login starts fresh; this does not revoke old Telegram sessions. "
            "Tap Remove custom ID to restore the configured default."
        )
    if action == "remove_music_id":
        _pending_music_id_inputs.pop(settings.OWNER_ID, None)
        await query.answer()
        return await _save_music_account_id(query.message, None)
    if action == "login_help":
        await query.answer()
        return await query.message.reply_text(
            "Use /login here in this private chat. The account that completes login must "
            "match the configured music account user ID. Use /logout before switching only "
            "if a music assistant is currently connected."
        )
    if action == "commands":
        from management.command_menu import format_owner_commands

        await query.answer()
        return await query.message.reply_text(
            format_owner_commands(), parse_mode=enums.ParseMode.HTML
        )
    if action == "broadcast":
        from management.plugins.broadcast import begin_owner_broadcast

        await query.answer()
        return await begin_owner_broadcast(client, settings.OWNER_ID, mode="all")
    await query.answer("This panel action is unavailable. Run /admin again.", show_alert=True)


@app.on_message(
    filters.private & filters.text,
    group=_OWNER_PUBLIC_USERNAME_INPUT_GROUP,
)
async def capture_public_username_input(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return
    pending = _pending_public_username_inputs.get(user.id)
    if not pending:
        return
    field, expires_at = pending
    if expires_at < time.monotonic():
        _pending_public_username_inputs.pop(user.id, None)
        return await message.reply_text("That username prompt expired. Open /admin and try again.")

    raw_value = (message.text or "").strip()
    if raw_value.casefold() == "/cancel":
        _pending_public_username_inputs.pop(user.id, None)
        return await message.reply_text("Username update cancelled.")
    if raw_value.startswith("/"):
        _pending_public_username_inputs.pop(user.id, None)
        return

    from management.db.owner_profile import set_public_username

    try:
        username = await set_public_username(field, raw_value)
    except ValueError as exc:
        return await message.reply_text(str(exc))
    except Exception as exc:
        logger.warning("Could not save a public username (%s).", type(exc).__name__)
        _pending_public_username_inputs.pop(user.id, None)
        return await message.reply_text(
            "Could not save that username right now. Check the database connection and try again."
        )

    _pending_public_username_inputs.pop(user.id, None)
    target = "Owner" if field == "owner_username" else "Support"
    await message.reply_text(
        f"{target} username saved as @{username}. Public contact buttons now open that Telegram profile."
    )


@app.on_message(
    filters.private & filters.text,
    group=_OWNER_MUSIC_ACCOUNT_INPUT_GROUP,
)
async def capture_music_account_id_input(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return
    expires_at = _pending_music_id_inputs.get(user.id)
    if not expires_at:
        return
    if expires_at < time.monotonic():
        _pending_music_id_inputs.pop(user.id, None)
        return await message.reply_text("The ID prompt expired. Open /admin and try again.")

    raw_value = (message.text or "").strip()
    if raw_value.casefold() == "/cancel":
        _pending_music_id_inputs.pop(user.id, None)
        await _delete(message)
        return await message.reply_text("Music account ID update cancelled.")
    if raw_value.startswith("/"):
        _pending_music_id_inputs.pop(user.id, None)
        return

    try:
        requested_id = parse_music_account_id(raw_value)
    except ValueError as exc:
        await _delete(message)
        return await message.reply_text(str(exc))

    _pending_music_id_inputs.pop(user.id, None)
    await _save_music_account_id(message, requested_id)
    await _delete(message)


@app.on_message(
    filters.private & filters.text,
    group=_OWNER_MUSIC_ONLY_CHAT_INPUT_GROUP,
)
async def capture_music_only_chat_id_input(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return
    expires_at = _pending_music_only_chat_inputs.get(user.id)
    if not expires_at:
        return
    if expires_at < time.monotonic():
        _pending_music_only_chat_inputs.pop(user.id, None)
        return await message.reply_text("The group ID prompt expired. Open /admin and try again.")

    raw_value = (message.text or "").strip()
    if raw_value.casefold() == "/cancel":
        _pending_music_only_chat_inputs.pop(user.id, None)
        await _delete(message)
        return await message.reply_text("Music-only group setup cancelled.")
    if raw_value.startswith("/"):
        _pending_music_only_chat_inputs.pop(user.id, None)
        return

    try:
        target_chat_id = parse_music_only_chat_id(raw_value)
        target_chat = await app.get_chat(target_chat_id)
        if target_chat.type not in (enums.ChatType.GROUP, enums.ChatType.SUPERGROUP):
            raise ValueError("That chat ID is not a group or supergroup.")
        await db.add_music_only_chat(target_chat_id)
    except ValueError as exc:
        return await message.reply_text(str(exc))
    except Exception as exc:
        logger.warning("Could not enable music-only mode for group (%s).", type(exc).__name__)
        return await message.reply_text(
            "Could not verify or save that group. Check the chat ID and ensure the bot is in the group."
        )

    _pending_music_only_chat_inputs.pop(user.id, None)
    menu_updated = True
    try:
        from management.command_menu import set_music_only_chat_commands

        await set_music_only_chat_commands(app, target_chat_id)
    except Exception as exc:
        menu_updated = False
        logger.warning("Could not set music-only command menu (%s).", type(exc).__name__)
    await _delete(message)
    result = (
        f"Music-only mode enabled for <b>{target_chat.title or target_chat_id}</b> "
        f"(<code>{target_chat_id}</code>)."
    )
    if menu_updated:
        result += " Only music commands are shown; other group commands are blocked."
    else:
        result += (
            " Group commands are blocked, but Telegram did not update the slash menu. "
            "Check the bot's command-menu API permissions and try again."
        )
    await message.reply_text(result, parse_mode=enums.ParseMode.HTML)


@app.on_message(
    filters.private & (filters.text | filters.sticker),
    group=_OWNER_SEARCH_INDICATOR_INPUT_GROUP,
)
async def capture_search_indicator_input(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return
    expires_at = _pending_search_indicator_inputs.get(user.id)
    if not expires_at:
        return
    if expires_at < time.monotonic():
        _pending_search_indicator_inputs.pop(user.id, None)
        return await message.reply_text("That setup prompt expired. Open /admin and try again.")
    if (message.text or "").strip().casefold() == "/cancel":
        _pending_search_indicator_inputs.pop(user.id, None)
        return await message.reply_text("Search indicator unchanged.")

    from management.db.search_indicator import set_search_indicator

    if message.sticker:
        kind, value = "sticker", message.sticker.file_id
    else:
        kind, raw_value = "text", (message.text or "")
        from music.helpers._premium_emoji import (
            premium_emoji_markup,
            premium_emoji_markup_from_entities,
        )

        value = premium_emoji_markup(
            premium_emoji_markup_from_entities(raw_value, message.entities)
        ).strip()
        if value.startswith("/"):
            _pending_search_indicator_inputs.pop(user.id, None)
            return
        if not value:
            return await message.reply_text("Send text, an emoji, or a sticker.")
    try:
        await set_search_indicator(kind, value)
    except Exception as exc:
        logger.warning("Could not save the search indicator (%s).", type(exc).__name__)
        return await message.reply_text(
            "Could not save that indicator. Try text/emoji or another sticker."
        )
    _pending_search_indicator_inputs.pop(user.id, None)
    if kind == "sticker":
        await message.reply_text(
            "Play-search sticker saved. Preview:"
        )
        await message.reply_sticker(value)
    else:
        await message.reply_text(
            "Play-search indicator saved. Preview:\n" + value,
            parse_mode="html",
        )
    await message.reply_text(
        "Send another text/emoji or sticker to replace it, or use "
        "/admin → Reset play-search indicator to restore the default."
    )


@app.on_message(filters.command("login"))
async def login_command(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return await message.reply_text("Only the configured bot owner can use /login.")
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text("For security, send /login to me in a private chat.")

    async with _login_lock:
        active = next(
            (
                client
                for client in userbot.clients
                if client.me.id == settings.MUSIC_ACCOUNT_ID
            ),
            None,
        )
        if active:
            return await message.reply_text("Your music account is already connected.")

        await _discard_flow(settings.OWNER_ID)
        if config.SESSION1:
            old, fresh = userbot.replace_primary(session_string=None)
            await _disconnect(old)
            userbot.one = fresh

        client = userbot.one
        try:
            authorized = await client.connect()
            _secure_session_file()
            if authorized:
                account = await client.get_me()
                if account.id != settings.MUSIC_ACCOUNT_ID:
                    await _disconnect(client)
                    return await message.reply_text(
                        "This saved session is not the configured music playback account. "
                        "Check MUSIC_ACCOUNT_ID, remove SESSION1 if it is stale, "
                        "and start /login again."
                    )
                if await _start_assistant(client):
                    return await message.reply_text("Music playback account connected.")
                return await message.reply_text(
                    "The account is authorized, but the music assistant could not start. "
                    "Check the server log and voice-chat permissions."
                )
        except errors.FloodWait as exc:
            await _disconnect(client)
            return await message.reply_text(
                f"Telegram rate-limited login. Try again in about {max(1, int(exc.value))} seconds."
            )
        except Exception as exc:
            await _disconnect(client)
            if _is(exc, "AuthKeyUnregistered"):
                # A revoked/broken local session must not block a fresh owner login.
                _remove_session_files("music_assistant_1")
                _, client = userbot.replace_primary(session_string=None)
                try:
                    authorized = await client.connect()
                    _secure_session_file()
                except errors.FloodWait as retry_exc:
                    await _disconnect(client)
                    return await message.reply_text(
                        "Telegram rate-limited login. "
                        f"Try again in about {max(1, int(retry_exc.value))} seconds."
                    )
                except Exception as retry_exc:
                    await _disconnect(client)
                    logger.warning(
                        "Could not reset the invalid account session (%s).",
                        type(retry_exc).__name__,
                    )
                    return await message.reply_text(
                        "Could not reset the saved Telegram session. "
                        "Remove SESSION1 from Secrets if it is set, then run /login again."
                    )
            else:
                logger.warning(
                    "Could not check the saved account session (%s).", type(exc).__name__
                )
                return await message.reply_text(
                    "Could not check the saved Telegram session. Remove SESSION1 from Secrets "
                    "if it is stale, then run /login again."
                )

        _flows[settings.OWNER_ID] = {
            "client": client,
            "session_name": client.name,
            "stage": "phone",
            "started": time.monotonic(),
        }
        await message.reply_text(
            "Send the phone number for the configured music playback account, "
            "including country code."
        )


@app.on_message(filters.private & filters.text, group=-100)
async def consume_login_input(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return
    text = (message.text or "").strip()
    if text.lower() == "/cancel":
        await _delete(message)
        if settings.OWNER_ID in _flows:
            await _discard_flow(settings.OWNER_ID)
            await message.reply_text("The music account login was cancelled.")
        return
    if text.lower() in {"/login", "/logout"}:
        return
    flow = _flows.get(settings.OWNER_ID)
    if not flow:
        return
    await _delete(message)
    if time.monotonic() - flow["started"] > 600:
        await _discard_flow(settings.OWNER_ID)
        await message.reply_text("Login expired. Run /login to start a new request.")
        return

    client = flow["client"]
    if flow["stage"] == "phone":
        phone = text.replace(" ", "").replace("-", "")
        if not phone.startswith("+") or not phone[1:].isdigit() or len(phone) < 8:
            await message.reply_text("That phone number format looks invalid. Include the +country code and try again.")
            return
        try:
            sent_code = await client.send_code(phone)
            _secure_session_file()
            flow.update(
                {
                    "stage": "otp",
                    "phone": phone,
                    "phone_code_hash": sent_code.phone_code_hash,
                }
            )
            await message.reply_text(
                "Telegram accepted the login request. Check the official Telegram service chat "
                "(777000) on a device logged into the playback account; Telegram may instead "
                "choose SMS or another delivery route. Then enter the code here in this private "
                "chat. This bot cannot deliver Telegram's code itself, and your code message "
                "will be deleted after processing."
            )
        except errors.FloodWait as exc:
            await _discard_flow(settings.OWNER_ID)
            await message.reply_text(
                f"Telegram rate-limited login. Try again in about {max(1, int(exc.value))} seconds."
            )
        except Exception as exc:
            await _discard_flow(settings.OWNER_ID)
            logger.warning("Telegram could not send a login code (%s).", type(exc).__name__)
            await message.reply_text(
                "Telegram could not send a login code. Check the phone number and try again later."
            )
        return

    if flow["stage"] == "otp":
        code = "".join(text.split())
        try:
            account = await client.sign_in(
                flow["phone"], flow["phone_code_hash"], code
            )
        except errors.SessionPasswordNeeded:
            flow["stage"] = "password"
            await message.reply_text("Two-step verification is enabled. Send your 2FA password.")
            return
        except errors.FloodWait as exc:
            await _discard_flow(settings.OWNER_ID)
            await message.reply_text(
                f"Telegram rate-limited login. Try again in about {max(1, int(exc.value))} seconds."
            )
            return
        except Exception as exc:
            if _is(exc, "PhoneCodeInvalid", "PhoneCodeEmpty"):
                await message.reply_text("That login code is incorrect. Send the current code again.")
            elif _is(exc, "PhoneCodeExpired"):
                await _discard_flow(settings.OWNER_ID)
                await message.reply_text("That login code expired. Run /login to request a new code.")
            else:
                await _discard_flow(settings.OWNER_ID)
                logger.warning("Telegram login verification failed (%s).", type(exc).__name__)
                await message.reply_text("Telegram could not verify that code. Run /login to try again.")
            return
        finally:
            _secure_session_file()
        if account.id != settings.MUSIC_ACCOUNT_ID:
            try:
                await client.log_out()
            except Exception:
                await _disconnect(client)
            _remove_session_files(flow["session_name"])
            _flows.pop(settings.OWNER_ID, None)
            await message.reply_text(
                "That Telegram account does not match MUSIC_ACCOUNT_ID. "
                "The account was not activated."
            )
            return
        if await _start_assistant(client):
            _flows.pop(settings.OWNER_ID, None)
            await message.reply_text("Music playback account connected.")
        else:
            await _discard_flow(settings.OWNER_ID)
            await message.reply_text(
                "Telegram authorized the account, but the music assistant could not start."
            )
        return

    if flow["stage"] == "password":
        password = text
        try:
            account = await client.check_password(password)
        except errors.FloodWait as exc:
            await _discard_flow(settings.OWNER_ID)
            await message.reply_text(
                f"Telegram rate-limited login. Try again in about {max(1, int(exc.value))} seconds."
            )
            return
        except Exception as exc:
            if _is(exc, "PasswordHashInvalid"):
                await message.reply_text("That 2FA password is incorrect. Send it again.")
            else:
                await _discard_flow(settings.OWNER_ID)
                logger.warning("Telegram 2FA verification failed (%s).", type(exc).__name__)
                await message.reply_text("Telegram could not verify the 2FA password. Run /login again.")
            return
        finally:
            password = ""
            _secure_session_file()
        if account.id != settings.MUSIC_ACCOUNT_ID:
            try:
                await client.log_out()
            except Exception:
                await _disconnect(client)
            _remove_session_files(flow["session_name"])
            _flows.pop(settings.OWNER_ID, None)
            await message.reply_text(
                "That Telegram account does not match MUSIC_ACCOUNT_ID. "
                "The account was not activated."
            )
            return
        if await _start_assistant(client):
            _flows.pop(settings.OWNER_ID, None)
            await message.reply_text("Music playback account connected.")
        else:
            await _discard_flow(settings.OWNER_ID)
            await message.reply_text(
                "Telegram authorized the account, but the music assistant could not start."
            )


@app.on_message(filters.command("logout"))
async def logout_command(_, message: types.Message) -> None:
    user = message.from_user
    if not user or user.id != settings.OWNER_ID:
        return await message.reply_text("Only the configured bot owner can use /logout.")
    if message.chat.type != enums.ChatType.PRIVATE:
        return await message.reply_text("For security, send /logout to me in a private chat.")
    await _discard_flow(settings.OWNER_ID)

    active_clients = list(userbot.clients)
    remote_logout_failed = False
    for index in range(len(active_clients) - 1, -1, -1):
        client = active_clients[index]
        try:
            await anon.remove_assistant(index)
        except Exception as exc:
            logger.warning("Could not remove a voice-call assistant (%s).", type(exc).__name__)
        try:
            await client.log_out()
        except Exception as exc:
            remote_logout_failed = True
            logger.warning("Telegram assistant logout failed (%s).", type(exc).__name__)
            await _disconnect(client)
        if client in userbot.clients:
            userbot.clients.remove(client)
        _remove_session_files(client.name)

    for num, attribute in ((1, "one"), (2, "two"), (3, "three")):
        client = getattr(userbot, attribute)
        if client not in active_clients:
            await _disconnect(client)
        userbot.replace_client(num, session_string=None)
        _remove_session_files(f"music_assistant_{num}")

    orphan_sessions_logged_out, orphan_logout_failed = (
        await _logout_orphan_music_sessions()
    )

    try:
        await db.assistantdb.update_many({}, {"$set": {"num": 1}})
        db.assistant.clear()
    except Exception as exc:
        logger.warning("Could not refresh music assistant assignments (%s).", type(exc).__name__)

    if active_clients or orphan_sessions_logged_out:
        response = "All owner music assistants were disconnected and their local sessions removed."
    elif orphan_logout_failed:
        response = (
            "The regular music assistants were disconnected, but an older music session "
            "could not be safely logged out. Its session file was kept; check the logs and retry."
        )
    else:
        response = "No owner music assistant was connected; local session files were cleared."
    if remote_logout_failed:
        response += " Telegram could not confirm every remote logout; review Settings → Devices."
    if any((config.SESSION1, config.SESSION2, config.SESSION3)):
        response += " Remove any SESSION1, SESSION2, or SESSION3 Replit Secret before restarting."
    await message.reply_text(response)
