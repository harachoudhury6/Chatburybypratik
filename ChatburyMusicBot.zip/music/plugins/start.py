"""Music-specific entry points and group registration handlers."""

import asyncio

from pyrogram import enums, filters, types

from music import app, config, db, lang, logger
from music.helpers import buttons

def _music_board_text(language: dict) -> str:
    return f"<blockquote><b>{config.BOT_NAME} Board</b></blockquote>\n\n{language['help_menu']}"


_START_TEXT = (
    f"<b>{config.BOT_NAME} is ready.</b>\n\n"
    "<blockquote>Your group management and voice-chat music assistant is ready. "
    "Use /help for management commands or /music for player controls.</blockquote>"
)


@app.on_message(filters.command(["music"]) & filters.private & ~app.bl_users)
@lang.language()
async def music_help(_, message: types.Message) -> None:
    await message.reply_text(
        text=_music_board_text(message.lang),
        reply_markup=buttons.help_markup(message.lang),
        quote=True,
    )


@app.on_message(filters.command(["musicrepo"]) & ~app.bl_users)
@lang.language()
async def start(_, message: types.Message) -> None:
    if message.from_user and message.from_user.id in app.bl_users:
        if message.from_user.id not in db.notified:
            return await message.reply_text(message.lang["bl_user_notify"])

    if len(message.command) > 1 and message.command[1] == "help":
        return await music_help(_, message)

    private = message.chat.type == enums.ChatType.PRIVATE
    text = _START_TEXT
    if private and message.from_user:
        text = f"<b>Hello {message.from_user.mention}.</b>\n\n" + _START_TEXT
    keyboard = buttons.start_key(message.lang, private)

    try:
        await message.reply_photo(
            photo=config.START_IMG,
            caption=text,
            reply_markup=keyboard,
            quote=not private,
        )
    except Exception as exc:
        logger.warning("Could not send the music start image (%s).", type(exc).__name__)
        await message.reply_text(text, reply_markup=keyboard, quote=not private)

    if not message.from_user:
        return
    try:
        if private:
            if not await db.is_user(message.from_user.id):
                await db.add_user(message.from_user.id)
        elif not await db.is_chat(message.chat.id):
            await db.add_chat(message.chat.id)
    except Exception as exc:
        logger.warning("Could not register a music user or group (%s).", type(exc).__name__)


@app.on_message(
    filters.command(["playmode", "musicsettings"]) & filters.group & ~app.bl_users
)
@lang.language()
async def music_settings(_, message: types.Message) -> None:
    try:
        admin_only = await db.get_play_mode(message.chat.id)
        cmd_delete = await db.get_cmd_delete(message.chat.id)
        selected_language = await db.get_lang(message.chat.id)
        await message.reply_text(
            text=message.lang["start_settings"].format(message.chat.title),
            reply_markup=buttons.settings_markup(
                message.lang,
                admin_only,
                cmd_delete,
                selected_language,
                message.chat.id,
            ),
            quote=True,
        )
    except Exception as exc:
        logger.warning("Could not load music group settings (%s).", type(exc).__name__)
        await message.reply_text(
            "Music settings are temporarily unavailable. Please try again later."
        )


@app.on_callback_query(filters.regex(r"^adminpanel:music:-?\d+$"))
@lang.language()
async def admin_panel_music_settings(_, query: types.CallbackQuery) -> None:
    try:
        chat_id = int(query.data.rsplit(":", 1)[1])
        if (
            query.message.chat.type != enums.ChatType.PRIVATE
            and query.message.chat.id != chat_id
        ):
            return await query.answer("This panel belongs to a different group.", show_alert=True)
        if not query.from_user:
            return await query.answer("I could not verify your account.", show_alert=True)
        member = await app.get_chat_member(chat_id, query.from_user.id)
        if member.status not in (
            enums.ChatMemberStatus.ADMINISTRATOR,
            enums.ChatMemberStatus.OWNER,
        ):
            return await query.answer(
                "Only an administrator of this group can change music settings.",
                show_alert=True,
            )

        group = await app.get_chat(chat_id)
        admin_only = await db.get_play_mode(chat_id)
        cmd_delete = await db.get_cmd_delete(chat_id)
        selected_language = await db.get_lang(chat_id)
        await query.answer()
        await query.message.reply_text(
            text=query.lang["start_settings"].format(group.title or "this group"),
            reply_markup=buttons.settings_markup(
                query.lang,
                admin_only,
                cmd_delete,
                selected_language,
                chat_id,
            ),
            quote=True,
        )
    except Exception as exc:
        logger.warning("Could not open admin music settings (%s).", type(exc).__name__)
        try:
            await query.answer(
                "Music settings could not be loaded. Check that I am still an admin.",
                show_alert=True,
            )
        except Exception:
            pass


@app.on_message(filters.new_chat_members, group=7)
@lang.language()
async def register_music_group(_, message: types.Message) -> None:
    if message.chat.type != enums.ChatType.SUPERGROUP:
        return
    if not any(member.id == app.id for member in message.new_chat_members):
        return
    await asyncio.sleep(3)
    try:
        if not await db.is_chat(message.chat.id):
            await db.add_chat(message.chat.id)
    except Exception as exc:
        logger.warning("Could not register the new music group (%s).", type(exc).__name__)
