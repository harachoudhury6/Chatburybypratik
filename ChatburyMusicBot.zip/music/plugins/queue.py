# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic


from pyrogram import filters, types

from music import app, config, db, lang, logger, queue
from music.helpers import Track, buttons, thumb
from music.helpers._premium_emoji import premium_emoji_markup
from music.helpers._queue_cards import queue_cards


@app.on_message(filters.command(["queue", "playing"]) & filters.group & ~app.bl_users)
@lang.language()
async def _queue_func(_, m: types.Message):
    if not await db.get_call(m.chat.id):
        return await m.reply_text(m.lang["not_playing"])

    _reply = await m.reply_text(m.lang["queue_fetching"])
    _queue = queue.get_queue(m.chat.id)
    if not _queue:
        return await _reply.edit_text(m.lang["not_playing"])
    _media = _queue[0]
    try:
        _thumb = queue_cards.render_queue(_queue, m.chat.title or "")
    except Exception as exc:
        logger.warning("Could not render the queue card (%s).", type(exc).__name__)
        _thumb = (
            await thumb.generate(_media)
            if isinstance(_media, Track)
            else config.DEFAULT_THUMB
        )
    _text = m.lang["queue_curr"].format(
        _media.url,
        _media.title[:50],
        _media.duration,
        _media.user,
    )
    _queue.pop(0)

    if _queue:
        _text += "<blockquote expandable>"
        for i, media in enumerate(_queue, start=1):
            if i == 15:
                break
            _text += m.lang["queue_item"].format(
                i + 1, media.title, media.duration
            )
        _text += "</blockquote>"

    _text = premium_emoji_markup(_text)
    _playing = await db.playing(m.chat.id)
    await _reply.edit_media(
        media=types.InputMediaPhoto(
            media=_thumb,
            caption=_text,
        ),
        reply_markup=buttons.queue_markup(
            m.chat.id,
            m.lang["playing"] if _playing else m.lang["paused"],
            _playing,
        ),
    )
