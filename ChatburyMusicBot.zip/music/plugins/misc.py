# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
#ALONE-CODER

import asyncio

from pyrogram import enums, errors, filters, types

from music import anon, app, config, db, lang, queue, tasks, userbot, yt
from music.helpers import buttons

_last_card_progress: dict[int, tuple[str, int]] = {}
_last_keyboard_progress: dict[int, tuple[str, int]] = {}


@app.on_message(filters.video_chat_ended, group=20)
async def _watcher_vc(_, m: types.Message):
    # Starting a group call must not stop playback; only stop once it ends.
    await anon.stop(m.chat.id)


async def auto_leave():
    while True:
        await asyncio.sleep(1800)
        for ub in userbot.clients:
            left = 0
            try:
                for dialog in await ub.get_dialogs():
                    chat_id = dialog.chat.id
                    if left >= 20:
                        break
                    if chat_id in [app.logger, -1001686672798, -1001549206010]:
                        continue
                    if dialog.chat.type in [
                        enums.ChatType.GROUP,
                        enums.ChatType.SUPERGROUP,
                    ]:
                        if chat_id in db.active_calls:
                            continue
                        await ub.leave_chat(chat_id)
                        left += 1
                    await asyncio.sleep(5)
            except:
                continue


async def track_time():
    while True:
        await asyncio.sleep(1)
        for chat_id in list(db.active_calls):
            if not await db.playing(chat_id):
                continue
            media = queue.get_current(chat_id)
            if not media:
                continue
            media.time += 1


async def update_timer(length=10):
    del length
    while True:
        await asyncio.sleep(7)
        for chat_id in list(db.active_calls):
            if not await db.playing(chat_id):
                continue
            try:
                media = queue.get_current(chat_id)
                duration, message_id = media.duration_sec, media.message_id
                if not duration or not message_id or not media.time:
                    continue
                played = media.time
                remaining = duration - played

                progress_bucket = played // 30
                marker = (str(media.id), progress_bucket)
                if progress_bucket and _last_card_progress.get(chat_id) != marker:
                    _last_card_progress[chat_id] = marker
                    await anon.update_player(chat_id)

                if remaining <= 30:
                    next = queue.get_next(chat_id, check=True)
                    if next and not next.file_path:
                        next.file_path = await yt.download(
                            next.id, video=next.video, url=getattr(next, "url", None)
                        )

            except Exception:
                pass
        active = set(db.active_calls)
        for chat_id in tuple(_last_card_progress):
            if chat_id not in active:
                _last_card_progress.pop(chat_id, None)


async def update_progress_button():
    """Refresh the inline progress row without rerendering player artwork."""
    while True:
        await asyncio.sleep(4)
        active = set(db.active_calls)
        for chat_id in active:
            try:
                if not await db.playing(chat_id):
                    continue
                media = queue.get_current(chat_id)
                if not media or not media.duration_sec or not media.message_id:
                    continue
                marker = (str(media.id), int(media.time or 0) // 4)
                if _last_keyboard_progress.get(chat_id) == marker:
                    continue
                _last_keyboard_progress[chat_id] = marker
                await app.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=media.message_id,
                    reply_markup=buttons.controls(chat_id),
                )
            except Exception as exc:
                logger.debug(
                    "Progress button refresh skipped (%s).", type(exc).__name__
                )

        for chat_id in tuple(_last_keyboard_progress):
            if chat_id not in active:
                _last_keyboard_progress.pop(chat_id, None)


async def vc_watcher(sleep=15):
    while True:
        await asyncio.sleep(sleep)
        for chat_id in list(db.active_calls):
            client = await db.get_assistant(chat_id)
            media = queue.get_current(chat_id)
            participants = await client.get_participants(chat_id)
            if len(participants) < 2 and media.time > 30:
                _lang = await lang.get_lang(chat_id)
                try:
                    sent = await app.edit_message_reply_markup(
                        chat_id=chat_id,
                        message_id=media.message_id,
                        reply_markup=buttons.controls(
                            chat_id=chat_id, status=_lang["stopped"], remove=True
                        ),
                    )
                    await anon.stop(chat_id)
                    await sent.reply_text(_lang["auto_left"])
                except errors.MessageIdInvalid:
                    pass


if config.AUTO_END:
    tasks.append(asyncio.create_task(vc_watcher()))
if config.AUTO_LEAVE:
    tasks.append(asyncio.create_task(auto_leave()))
tasks.append(asyncio.create_task(track_time()))
tasks.append(asyncio.create_task(update_timer()))
tasks.append(asyncio.create_task(update_progress_button()))
