# Copyright (c) 2025 TheHamkerAlone
# Licensed under the MIT License.
# This file is part of AloneXMusic
# ALONE-CODER

import asyncio
from functools import wraps

from pyrogram import filters, types

from music import anon, app, config, db, lang, logger, queue, tg, yt
from music.helpers import buttons, utils
from music.helpers._inline import _support_url
from music.helpers._play import checkUB
from music.helpers._premium_emoji import premium_emoji_markup
from music.helpers._reactions import add_music_post_reaction
from music.helpers._queue_cards import queue_cards
from management.db.search_indicator import get_search_indicator


def playlist_to_queue(chat_id: int, tracks: list) -> str:
    text = "<blockquote expandable>"
    for track in tracks:
        pos = queue.add(chat_id, track)
        text += f"<b>{pos}.</b> {track.title}\n"
    text = text[:1948] + "</blockquote>"
    return text


def _play_search_error(
    code: str | None, support_chat: str, query: str
) -> str:
    if query.casefold().startswith("scsearch"):
        return (
            "No publicly playable audio was found for that search. "
            "Try another song title or a public audio link."
        )
    if code == "rate_limited":
        return (
            "The video source is temporarily limiting this server. Try again later "
            "or reply to a public audio message with <code>/play</code>."
        )
    if code in {
        "anonymous_access_required",
        "age_restricted",
        "region_blocked",
        "http_403",
        "no_public_audio",
    }:
        return (
            "I skipped results that need sign-in/age verification or do not expose "
            "public audio to this server. Try another publicly playable version. "
            f"If it keeps failing, contact <a href={support_chat}>support</a>."
        )
    return ""


def _safe_play_errors(handler):
    @wraps(handler)
    async def wrapped(client, message, *args, **kwargs):
        try:
            return await handler(client, message, *args, **kwargs)
        except Exception as exc:
            logger.warning("Play request failed (%s).", type(exc).__name__)
            try:
                await message.reply_text(
                    "I couldn't complete that play request. Try a public song title "
                    "or YouTube link, and make sure the voice chat is active."
                )
            except Exception:
                pass

    return wrapped


async def _delete_search_sticker_later(message: types.Message) -> None:
    await asyncio.sleep(180)
    try:
        await message.delete()
    except Exception:
        pass


async def _delete_play_request_later(message: types.Message) -> None:
    try:
        await message.delete()
    except Exception as exc:
        logger.debug(
            "Could not remove the /play request message (%s).",
            type(exc).__name__,
        )


@app.on_message(
    filters.command(["play", "playforce", "vplay", "vplayforce"])
    & filters.group
    & ~app.bl_users
)
@lang.language()
@checkUB
@_safe_play_errors
async def play_hndlr(
    _,
    m: types.Message,
    force: bool = False,
    m3u8: bool = False,
    video: bool = False,
    url: str = None,
) -> None:
    indicator = get_search_indicator()
    indicator_value = indicator.get("value")
    status_text = indicator_value or m.lang["play_searching"]
    try:
        if indicator.get("kind") == "sticker" and indicator_value:
            sent = await m.reply_text("\u2063")
            try:
                indicator_message = await m.reply_sticker(
                    indicator_value, reply_to_message_id=m.id
                )
                asyncio.create_task(_delete_search_sticker_later(indicator_message))
            except Exception:
                try:
                    sent = await sent.edit_text(
                        premium_emoji_markup(m.lang["play_searching"]),
                        parse_mode="html",
                    )
                except Exception:
                    sent = await m.reply_text("Searching for a playable song...")
        else:
            sent = await m.reply_text(
                premium_emoji_markup(status_text),
                parse_mode="html",
            )
        if len(m.command) >= 2 or m.reply_to_message:
            # Keep the query in this handler's parsed state, then remove the
            # public command while provider search runs.
            asyncio.create_task(_delete_play_request_later(m))
    except Exception as exc:
        logger.warning(
            "Configured play-search indicator failed (%s); using plain status.",
            type(exc).__name__,
        )
        sent = await m.reply_text("Searching for a playable song...")
    file = None
    mention = m.from_user.mention
    replaced_media = queue.get_current(m.chat.id) if force else None
    media = tg.get_media(m.reply_to_message) if m.reply_to_message else None
    tracks = []

    if url:
        if "playlist" in url:
            await sent.edit_text(premium_emoji_markup(m.lang["playlist_fetch"]))
            tracks = await yt.playlist(
                config.PLAYLIST_LIMIT, mention, url, video
            )

            if not tracks:
                return await sent.edit_text(premium_emoji_markup(m.lang["playlist_error"]))

            file = tracks[0]
            tracks.remove(file)
            file.message_id = sent.id
        else:
            file = await yt.search(url, sent.id, video=video)

        if not file:
            error_text = _play_search_error(
                yt.last_error, _support_url(), url
            )
            return await sent.edit_text(
                premium_emoji_markup(
                    error_text
                    or m.lang["play_not_found"].format(_support_url())
                )
            )

    elif len(m.command) >= 2:
        query = " ".join(m.command[1:])
        file = await yt.search(query, sent.id, video=video)
        original_search_error = yt.last_error
        if (
            not file
            and not query.casefold().startswith("scsearch")
            and not query.casefold().startswith(("http://", "https://"))
        ):
            file = await yt.search(f"scsearch1:{query}", sent.id, video=video)
        if not file:
            error_text = _play_search_error(
                original_search_error or yt.last_error,
                _support_url(),
                query,
            )
            return await sent.edit_text(
                premium_emoji_markup(
                    error_text or m.lang["play_not_found"].format(_support_url())
                )
            )

    elif media:
        setattr(sent, "lang", m.lang)
        file = await tg.download(m.reply_to_message, sent)

    if not file:
        return await sent.edit_text(premium_emoji_markup(m.lang["play_usage"]))

    file.message_id = sent.id

    if config.DURATION_LIMIT > 0 and file.duration_sec > config.DURATION_LIMIT:
        return await sent.edit_text(
            premium_emoji_markup(
                m.lang["play_duration_limit"].format(config.DURATION_LIMIT // 60)
            )
        )

    if await db.is_logger():
        await utils.play_log(m, file.title, file.duration)

    file.user = mention
    # After a restart the database may have restored a pending queue, but no
    # voice stream is active. Resume its first playable entry before appending
    # this new request so restored tracks keep their order.
    if not force and not await db.get_call(m.chat.id) and queue.get_current(m.chat.id):
        for _ in range(5):
            if await anon.start_current(m.chat.id, sent):
                break
            queue.remove_current(m.chat.id)
            await anon._persist_queue(m.chat.id)

    if force:
        queue.force_add(m.chat.id, file)
        await anon._persist_queue(m.chat.id)
    else:
        position = queue.add(m.chat.id, file)
        await anon._persist_queue(m.chat.id)

        if position != 0 or await db.get_call(m.chat.id):
            await anon.update_player(m.chat.id)
            queued_text = m.lang["play_queued"].format(
                position,
                file.url,
                file.title,
                file.duration,
                m.from_user.mention,
            )
            queued_text = premium_emoji_markup(queued_text)
            reply_markup = buttons.play_queued(
                m.chat.id, file.id, m.lang["play_now"]
            )
            try:
                card = await queue_cards.render_queued(
                    file, position, current_item=queue.get_current(m.chat.id)
                )
                queued_post = await app.send_photo(
                    chat_id=m.chat.id,
                    photo=card,
                    caption=queued_text,
                    reply_markup=reply_markup,
                    reply_to_message_id=m.id,
                )
                file.message_id = queued_post.id
                await add_music_post_reaction(
                    app, m.chat.id, queued_post.id
                )
                try:
                    await sent.delete()
                except Exception:
                    pass
            except Exception as exc:
                logger.warning(
                    "Could not send queued-track artwork (%s).",
                    type(exc).__name__,
                )
                queued_post = await sent.edit_text(
                    queued_text, reply_markup=reply_markup
                )
                file.message_id = queued_post.id
                await add_music_post_reaction(app, m.chat.id, queued_post.id)
            if tracks:
                added = playlist_to_queue(m.chat.id, tracks)
                await anon._persist_queue(m.chat.id)
                await anon.update_player(m.chat.id)
                await app.send_message(
                    chat_id=m.chat.id,
                    text=premium_emoji_markup(
                        m.lang["playlist_queued"].format(len(tracks)) + added
                    ),
                )
            return

    if not file.file_path and not getattr(file, "stream_url", None):
        await sent.edit_text(premium_emoji_markup(m.lang["play_downloading"]))
        file.file_path = await yt.download(
            file.id, video=video, url=getattr(file, "url", None)
        )
        if not file.file_path:
            if (
                not video
                and yt.is_youtube_url(getattr(file, "url", None))
            ):
                search_text = " ".join(
                    part
                    for part in (
                        str(getattr(file, "title", "") or "").strip(),
                        str(
                            getattr(file, "artist", None)
                            or getattr(file, "channel_name", "")
                            or ""
                        ).strip(),
                    )
                    if part
                )
                alternative = (
                    await yt.search(
                        f"scsearch5:{search_text}", sent.id, video=False
                    )
                    if search_text
                    else None
                )
                if alternative and alternative.stream_url:
                    yt.adopt_alternative_track(file, alternative)
                    file.user = mention
                    file.message_id = sent.id
                else:
                    return await sent.edit_text(
                        premium_emoji_markup(
                            "YouTube did not provide playable audio from this server, "
                            "and no alternate public audio match was available. Try "
                            "another public title or link."
                        )
                    )
        if not file.file_path and not getattr(file, "stream_url", None):
            if yt.last_download_error == "rate_limited":
                return await sent.edit_text(
                    premium_emoji_markup(
                        "The video source is temporarily limiting this server. "
                        "Try again later."
                    )
                )
            return await sent.edit_text(
                premium_emoji_markup(
                    "The selected public audio could not be loaded. Try another "
                    "public result or a direct audio link."
                )
            )

    await anon.play_media(chat_id=m.chat.id, message=sent, media=file)
    if replaced_media and replaced_media is not file:
        yt.cleanup_download(replaced_media.file_path, queue)
    if not tracks:
        return
    added = playlist_to_queue(m.chat.id, tracks)
    await anon._persist_queue(m.chat.id)
    await anon.update_player(m.chat.id)
    await app.send_message(
        chat_id=m.chat.id,
        text=premium_emoji_markup(m.lang["playlist_queued"].format(len(tracks)) + added),
    )
