"""Restrict configured groups to music commands while preserving normal chats."""

from __future__ import annotations

import logging

from pyrogram import StopPropagation, enums, filters

from config import settings
from music import app, config, db

logger = logging.getLogger("eiko.music.only_mode")


@app.on_message(filters.group & filters.text, group=-1_000_001)
async def enforce_music_only_commands(_, message) -> None:
    chat_id = message.chat.id
    text = (message.text or "").strip()
    if not text:
        return

    command_token = None
    for prefix in settings.prefix_cmds:
        if text.startswith(prefix) and len(text) > len(prefix):
            command_token = text[len(prefix):].split(maxsplit=1)[0]
            break
    if not command_token:
        return

    command_name, separator, target_bot = command_token.partition("@")
    if separator and config.BOT_USERNAME and target_bot.casefold() != config.BOT_USERNAME.casefold():
        return

    try:
        if not await db.is_music_only_chat(chat_id):
            return
    except Exception as exc:
        logger.warning("Could not verify music-only group mode (%s).", type(exc).__name__)
        await message.reply_text(
            "This group's command mode could not be checked. Please retry shortly."
        )
        raise StopPropagation

    from management.command_menu import MUSIC_ONLY_COMMANDS

    if command_name.casefold() in MUSIC_ONLY_COMMANDS:
        return

    raise StopPropagation


@app.on_callback_query(filters.all, group=-1_000_001)
async def enforce_music_only_callbacks(_, query) -> None:
    if not query.message or query.message.chat.type not in (
        enums.ChatType.GROUP,
        enums.ChatType.SUPERGROUP,
    ):
        return
    try:
        if not await db.is_music_only_chat(query.message.chat.id):
            return
    except Exception as exc:
        logger.warning("Could not verify music-only callback scope (%s).", type(exc).__name__)
        await query.answer("This group's mode could not be checked. Retry shortly.", show_alert=True)
        raise StopPropagation

    data = query.data or ""
    if data.startswith(
        (
            "controls",
            "mr:",
            "cancel_dl",
            "adminpanel:music:",
            "settings",
        )
    ):
        return
    await query.answer(
        "Only music controls are available in this group.",
        show_alert=True,
    )
    raise StopPropagation
