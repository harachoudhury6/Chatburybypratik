"""Radio, recommendations, favorites, and listening-history commands."""

from __future__ import annotations

import html
import time
import uuid
from collections import Counter
from typing import Any

from pyrogram import enums, errors, filters, types

from music import anon, app, db, logger, queue, yt
from music.helpers import Track
from music.helpers._premium_emoji import premium_emoji_markup
from music.plugins.play import play_hndlr

_recommendation_states: dict[str, dict[str, Any]] = {}
_STATE_TTL = 15 * 60


def _token() -> str:
    return uuid.uuid4().hex[:12]


def _expire_states() -> None:
    cutoff = time.monotonic() - _STATE_TTL
    for key, value in list(_recommendation_states.items()):
        if value.get("created", 0) < cutoff:
            _recommendation_states.pop(key, None)


async def _can_control(chat_id: int, user_id: int) -> bool:
    if user_id in app.sudoers:
        return True
    try:
        return (
            await db.is_auth(chat_id, user_id)
            or user_id in await db.get_admins(chat_id)
        )
    except Exception:
        return False


async def _send_recommendations(
    message: types.Message, actor_id: int, seed: Track
) -> None:
    _expire_states()
    try:
        recent = await db.get_history(message.chat.id, limit=30)
        excluded = {str(item.get("track_id")) for item in recent}
    except Exception:
        excluded = set()
    try:
        found = await anon.features.related_tracks(seed, limit=10, exclude_ids=excluded)
    except Exception as exc:
        logger.info("Recommendations unavailable (%s).", type(exc).__name__)
        return await message.reply_text("Song recommendations are unavailable right now.")
    if not found:
        return await message.reply_text("No related public songs were found.")
    token = _token()
    _recommendation_states[token] = {
        "created": time.monotonic(),
        "actor_id": int(actor_id),
        "chat_id": int(message.chat.id),
        "tracks": found,
    }
    rows = []
    for index, track in enumerate(found):
        title = html.escape((track.title or "Unknown title")[:44])
        artist = html.escape((track.artist or track.channel_name or "")[:24])
        rows.append(
            [
                types.InlineKeyboardButton(
                    f"▶ {title}" + (f" — {artist}" if artist else ""),
                    callback_data=f"mr:play:{token}:{index}",
                ),
                types.InlineKeyboardButton(
                    "＋ Queue", callback_data=f"mr:queue:{token}:{index}"
                ),
            ]
        )
    await message.reply_text(
        f"<b>Related to:</b> {html.escape(seed.title or 'Current track')}",
        reply_markup=types.InlineKeyboardMarkup(rows),
        disable_web_page_preview=True,
    )


async def send_current_recommendations(
    message: types.Message, actor_id: int, chat_id: int
) -> None:
    seed = queue.get_current(chat_id)
    if not seed:
        return await message.reply_text("There is no current track to recommend from.")
    await _send_recommendations(message, actor_id, seed)


@app.on_message(filters.command("similar") & ~app.bl_users)
async def similar_command(_, message: types.Message) -> None:
    if not queue.get_current(message.chat.id):
        return await message.reply_text(
            "Start a track in a group voice chat, then use /similar there."
        )
    await send_current_recommendations(message, message.from_user.id, message.chat.id)


@app.on_message(filters.command("recommend") & ~app.bl_users)
async def recommend_command(_, message: types.Message) -> None:
    query = " ".join(message.command[1:]).strip()
    if not query:
        return await message.reply_text("Usage: /recommend <song or artist>")
    seed = await yt.search(query, message.id)
    if not seed:
        return await message.reply_text("I couldn't find a public result for that song.")
    await _send_recommendations(message, message.from_user.id, seed)


class _CommandAlias:
    """Pass a /radio query through the existing /play handler and join logic."""

    def __init__(self, original: types.Message, command: list[str]):
        self._original = original
        self.command = command

    def __getattr__(self, name: str):
        return getattr(self._original, name)


@app.on_message(filters.command("radio") & filters.group & ~app.bl_users)
async def radio_command(client, message: types.Message) -> None:
    if not await _can_control(message.chat.id, message.from_user.id):
        return await message.reply_text("Only a group DJ or admin can control Radio.")
    args = message.command[1:]
    choice = args[0].casefold() if args else ""
    if choice == "off":
        await anon.set_radio(message.chat.id, False)
        items = queue.get_queue(message.chat.id)
        current = items[:1]
        pending = [item for item in items[1:] if getattr(item, "user", "") != "Radio"]
        queue.restore(message.chat.id, current + pending)
        await anon._persist_queue(message.chat.id)
        await anon.update_player(message.chat.id)
        return await message.reply_text("Radio recommendations are off; queued radio-only tracks were removed.")
    if choice == "on" or not args:
        seed = queue.get_current(message.chat.id)
        if not seed:
            return await message.reply_text("Start a track with /play first, or use /radio <song name>.")
        await anon.set_radio(message.chat.id, True)
        added = await anon._fill_radio(message.chat.id, seed)
        await anon.update_player(message.chat.id)
        return await message.reply_text(
            f"Radio is on. Added {added} verified public track(s) to the queue."
        )

    # Reuse /play's real search, voice-chat join, and queue path. Only the parsed
    # command name is adapted; all other message data and permissions are intact.
    alias = _CommandAlias(message, ["play", *args])
    await play_hndlr(client, alias)
    if await db.get_call(message.chat.id):
        await anon.set_radio(message.chat.id, True)
        seed = queue.get_current(message.chat.id)
        if seed:
            added = await anon._fill_radio(message.chat.id, seed)
            await anon.update_player(message.chat.id)
            await message.reply_text(
                f"Radio is on. Added {added} verified public track(s) to the queue."
            )


@app.on_message(filters.command("autoplay") & filters.group & ~app.bl_users)
async def autoplay_command(_, message: types.Message) -> None:
    if not await _can_control(message.chat.id, message.from_user.id):
        return await message.reply_text("Only a group DJ or admin can control autoplay.")
    arg = message.command[1].casefold() if len(message.command) > 1 else "toggle"
    if arg not in {"toggle", "on", "off"}:
        return await message.reply_text("Usage: /autoplay [on|off]")
    enabled = (
        anon.toggle_autoplay(message.chat.id)
        if arg == "toggle"
        else (True if arg == "on" else False)
    )
    if arg in {"on", "off"}:
        if enabled:
            anon._autoplay_chats.add(message.chat.id)
        else:
            anon._autoplay_chats.discard(message.chat.id)
    label = (
        "✅ Same-artist autoplay is on."
        if enabled
        else "⚠️ Same-artist autoplay is off."
    )
    await message.reply_text(premium_emoji_markup(label))
    try:
        await anon.update_player(message.chat.id)
    except Exception as exc:
        logger.debug("Could not refresh autoplay player controls (%s).", type(exc).__name__)


@app.on_message(filters.command("rec") & filters.group & ~app.bl_users)
async def rec_command(_, message: types.Message) -> None:
    media = queue.get_current(message.chat.id)
    if not media:
        return await message.reply_text("There is no current song to send.")
    if not isinstance(media, Track):
        return await message.reply_text("MP3 delivery is available for audio tracks only.")
    try:
        status = await app.send_message(
            message.from_user.id, "Preparing the current track as an MP3…"
        )
    except errors.PeerIdInvalid:
        return await message.reply_text(
            "Open the bot's private chat, press Start, then run /rec again."
        )
    except Exception as exc:
        logger.warning("Could not open MP3 delivery DM (%s).", type(exc).__name__)
        return await message.reply_text("Start the bot's private chat, then try /rec again.")
    try:
        path = media.file_path
        if not path or not path.endswith(".mp3"):
            path = await yt.download(media.id, video=False, url=media.url)
        if not path:
            return await status.edit_text("I couldn't prepare an MP3 for this song.")
        await app.send_audio(
            chat_id=message.from_user.id,
            audio=path,
            title=(media.title or "Music")[:64],
            performer=(media.artist or media.channel_name or app.name)[:64],
            duration=max(1, int(media.duration_sec or 1)),
        )
        await status.edit_text(
            premium_emoji_markup("✅ The MP3 was sent to your private chat.")
        )
    except Exception as exc:
        logger.warning("MP3 delivery failed (%s).", type(exc).__name__)
        try:
            await status.edit_text("I couldn't send the MP3. Start the bot DM and try again.")
        except Exception:
            pass


@app.on_message(filters.command("unsave") & ~app.bl_users)
async def unsave_command(_, message: types.Message) -> None:
    media = queue.get_current(message.chat.id)
    track_id = message.command[1] if len(message.command) > 1 else (
        media.id if media else None
    )
    if not track_id:
        return await message.reply_text("Use /unsave while a track is playing, or pass its track ID.")
    try:
        removed = await db.remove_favorite(message.from_user.id, str(track_id))
    except Exception as exc:
        logger.warning("Could not remove favorite (%s).", type(exc).__name__)
        return await message.reply_text("Favorites are temporarily unavailable.")
    await message.reply_text("Removed from your favorites." if removed else "That track was not in your favorites.")


@app.on_message(filters.command("favorites") & ~app.bl_users)
async def favorites_command(_, message: types.Message) -> None:
    try:
        records = await db.get_favorites(message.from_user.id)
    except Exception as exc:
        logger.warning("Could not load favorites (%s).", type(exc).__name__)
        return await message.reply_text("Favorites are temporarily unavailable.")
    if not records:
        return await message.reply_text("You have no saved tracks yet. Tap ♡ Save on a player.")
    lines = ["<b>Your saved tracks</b>"]
    for index, record in enumerate(records[:30], 1):
        title = html.escape(record.get("title") or "Unknown title")
        artist = html.escape(record.get("artist") or "")
        url = html.escape(record.get("url") or "", quote=True)
        label = f"{index}. <a href=\"{url}\">{title}</a>" if url else f"{index}. {title}"
        if artist:
            label += f" — {artist}"
        lines.append(label)
    await message.reply_text("\n".join(lines), disable_web_page_preview=True)


@app.on_message(filters.command("history") & filters.group & ~app.bl_users)
async def history_command(_, message: types.Message) -> None:
    try:
        records = await db.get_history(message.chat.id, limit=15)
    except Exception as exc:
        logger.warning("Could not load music history (%s).", type(exc).__name__)
        return await message.reply_text("Listening history is temporarily unavailable.")
    if not records:
        return await message.reply_text("This group has no listening history yet.")
    lines = ["<b>Recently played in this group</b>"]
    for index, record in enumerate(records, 1):
        title = html.escape(record.get("title") or "Unknown title")
        artist = html.escape(record.get("artist") or "")
        lines.append(f"{index}. {title}" + (f" — {artist}" if artist else ""))
    await message.reply_text("\n".join(lines))


@app.on_message(filters.command("top") & filters.group & ~app.bl_users)
async def top_command(_, message: types.Message) -> None:
    try:
        records = await db.get_history(message.chat.id, limit=100)
    except Exception as exc:
        logger.warning("Could not load group top tracks (%s).", type(exc).__name__)
        return await message.reply_text("Top tracks are temporarily unavailable.")
    counts = Counter(item.get("track_id") for item in records if item.get("track_id"))
    if len(counts) < 2:
        return await message.reply_text("There isn't enough listening data for a group top list yet.")
    metadata = {
        item["track_id"]: item
        for item in reversed(records)
        if item.get("track_id")
    }
    lines = ["<b>Most played in this group</b>"]
    for index, (track_id, plays) in enumerate(counts.most_common(10), 1):
        record = metadata.get(track_id, {})
        title = html.escape(record.get("title") or "Unknown title")
        artist = html.escape(record.get("artist") or "")
        lines.append(
            f"{index}. {title}" + (f" — {artist}" if artist else "") + f" · {plays}"
        )
    await message.reply_text("\n".join(lines))


@app.on_callback_query(filters.regex(r"^mr:") & ~app.bl_users)
async def recommendation_callback(_, query: types.CallbackQuery) -> None:
    parts = query.data.split(":")
    if len(parts) != 4:
        return await query.answer("This recommendation button is invalid.", show_alert=True)
    _, action, token, raw_index = parts
    state = _recommendation_states.get(token)
    if not state:
        return await query.answer("These recommendations expired. Run /similar again.", show_alert=True)
    if query.message.chat.id != int(state["chat_id"]):
        return await query.answer("This recommendation belongs to a different chat.", show_alert=True)
    try:
        index = int(raw_index)
        track = state["tracks"][index]
    except (ValueError, IndexError, KeyError, TypeError):
        return await query.answer("This recommendation is no longer available.", show_alert=True)
    if not await _can_control(int(state["chat_id"]), query.from_user.id):
        return await query.answer("Only a group DJ or admin can change playback.", show_alert=True)
    try:
        checked = await yt.search(track.url or track.id, 0)
        if not checked or checked.video:
            return await query.answer("That public audio is not playable right now.", show_alert=True)
        path = await yt.download(
            checked.id, video=False, url=getattr(checked, "url", None)
        )
        if not path:
            return await query.answer("That song could not be downloaded from the public source.", show_alert=True)
        checked.file_path = path
        checked.user = query.from_user.mention
        if action == "queue":
            if not await db.get_call(int(state["chat_id"])):
                return await query.answer("Start playback with /play first.", show_alert=True)
            position, existing = queue.check_item(int(state["chat_id"]), str(checked.id))
            if existing:
                return await query.answer(f"Already in the queue at position {position}.", show_alert=True)
            pos = queue.add(int(state["chat_id"]), checked)
            await anon._persist_queue(int(state["chat_id"]))
            await anon.update_player(int(state["chat_id"]))
            return await query.answer(f"Added to the queue (position {pos + 1}).")
        if action == "play":
            status = await app.send_message(
                int(state["chat_id"]), "Starting the selected related track…"
            )
            started = await anon.play_now(int(state["chat_id"]), status, checked)
            if not started:
                try:
                    await status.edit_text("Start playback in the voice chat with /play first.")
                except Exception:
                    pass
                return await query.answer("Playback is not active in this group.", show_alert=True)
            return await query.answer("Playing the selected related track.")
    except Exception as exc:
        logger.info("Recommendation selection failed (%s).", type(exc).__name__)
        return await query.answer("That track could not be added. Try another result.", show_alert=True)
    await query.answer("Unknown recommendation action.", show_alert=True)
