"""Answer inline queries with no results while the bot's inline mode is retired."""

from pyrogram import types

from music import app


@app.on_inline_query()
async def inline_mode_disabled(_, query: types.InlineQuery) -> None:
    try:
        await app.answer_inline_query(
            query.id,
            results=[],
            cache_time=0,
            is_personal=True,
        )
    except Exception:
        # BotFather can also disable inline mode completely; do not log query text.
        return
