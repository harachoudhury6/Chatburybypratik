# Button emoji IDs

Pyrogram's Telegram inline buttons support one `icon_custom_emoji_id` per
button. The bot now uses the IDs already provided in `music/helpers/_premium_emoji.py`
for button labels across both management and music keyboards. Send one custom
emoji ID for each blank entry below and it can be added to that mapping.

Already configured:

```text
✅ = 5823396554345549784
🎵 = 5891249688933305846
🎤 = 5897554554894946515
➡️ = 5877468380125990242
🎶 = 5915480455603295660
⏱️ = 5936170807716745162
🔥 = 5859539275372040586
🎙️ = 5909015791088439934
🌙 = 6005928962163742139
✨ = 5765071340847501478
🎥 = 6005986106703613755
⏳ = 6010111371251815589
⚠️ = 5881702736843511327
❌ = 5260342697075416641
🔴 = 5411225014148014586
🗑️ = 5258130763148172425
✔️ = 6255593645848660539
```

Still needed for emoji glyphs currently found in inline-button labels:

```text
⚙️ =
📋 =
🔐 =
📢 =
👀 =
🔄 =
📺 =
🧮 =
🗺️ =
⚜️ =
📈 =
⚡ =
⬅️ =
🛒 =
💚 =
🏡 =
🔙 =
🎨 =
🎭 =
🔗 =
🔢 =
🔤 =
🎲 =
📘 =
📗 =
📙 =
📕 =
💸 =
💬 =
🚫 =
🔇 =
🔊 =
◀️ =
⏭️ =
📩 =
🐢 =
⏮️ =
🧹 =
🔁 =
✉️ =
🎬 =
📝 =
⚔️ =
🔂 =
🔠 =
🔎 =
🧏 =
⬇️ =
📨 =
🎧 =
⚙ =
➕ =
🔧 =
📱 =
📁 =
🆘 =
🛍️ =
⏹ =
✏️ =
▶ =
```

`⚙️` and `⚙` are separate Unicode spellings of the gear glyph. If Telegram
provides the same custom emoji for both, the same ID can be used for both.
Buttons containing multiple emoji glyphs can display one as Telegram's custom
emoji icon; the rest remain ordinary text because Telegram's inline-button API
does not accept rich-text emoji entities inside a button label.
