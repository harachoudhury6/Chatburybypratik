#!/usr/bin/env python3
"""Create a deployment ZIP, optionally carrying the private music login session."""

from __future__ import annotations

import argparse
import os
import stat
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BOT_IMAGE_ASSETS = {
    "attached_assets/generated_images/priksha-music-bot-logo.png",
    "attached_assets/f647b5882d63cbc6bfe6d6f8e9888822_1791523463060.jpg",
}
EXCLUDED_DIRS = {
    ".agents",
    ".cache",
    ".git",
    ".local",
    ".pythonlibs",
    ".venv",
    "__pycache__",
    "artifacts",
    "cache",
    "cookies",
    "dist",
    "downloads",
    "logs",
    "node_modules",
    "sessions",
    "temp",
    "temp_repos",
    "venv",
}
EXCLUDED_FILES = {
    "backup.zip",
    "log.txt",
    "logs.txt",
    "restart_data.txt",
}


def project_files():
    for base, directories, filenames in os.walk(ROOT, followlinks=False):
        base_path = Path(base)
        directories[:] = sorted(
            name
            for name in directories
            if name not in EXCLUDED_DIRS and not (base_path / name).is_symlink()
        )
        for filename in sorted(filenames):
            path = base_path / filename
            if path.is_symlink() or filename in EXCLUDED_FILES:
                continue
            relative = path.relative_to(ROOT)
            relative_path = relative.as_posix()
            if "cookies" in relative.parts:
                continue
            if "attached_assets" in relative.parts and relative_path not in BOT_IMAGE_ASSETS:
                continue
            if filename == ".env" or (
                filename.startswith(".env.") and filename != ".env.example"
            ):
                continue
            if filename.endswith(
                (
                    ".log",
                    ".pyc",
                    ".session",
                    ".session-journal",
                    ".session-shm",
                    ".session-wal",
                    ".sqlite3",
                    ".tsbuildinfo",
                    ".zip",
                )
            ):
                continue
            yield path


def music_session_path() -> Path:
    configured = Path(os.getenv("MUSIC_SESSION_DIR", "sessions")).expanduser()
    if not configured.is_absolute():
        configured = ROOT / configured
    return configured.resolve() / "music_assistant_1.session"


def add_private_session(archive: zipfile.ZipFile, source: Path) -> None:
    info = zipfile.ZipInfo.from_file(source, "sessions/music_assistant_1.session")
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (stat.S_IFREG | 0o600) << 16
    with source.open("rb") as session_file, archive.open(info, "w") as target:
        while chunk := session_file.read(1024 * 1024):
            target.write(chunk)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--include-music-session",
        action="store_true",
        help="include the private music-account session in the ZIP",
    )
    parser.add_argument(
        "--output",
        default="dist/priksha-music-bot-portable.zip",
        help="ZIP destination (default: dist/priksha-music-bot-portable.zip)",
    )
    args = parser.parse_args()

    session_path = music_session_path()
    if args.include_music_session:
        if not session_path.is_file() or session_path.stat().st_size == 0:
            print(
                "No saved music session found. Run /login successfully first.",
                file=sys.stderr,
            )
            return 2
        sidecars = [
            Path(f"{session_path}{suffix}")
            for suffix in ("-journal", "-wal", "-shm")
        ]
        if any(path.exists() for path in sidecars):
            print(
                "A SQLite session sidecar is still present. Stop the bot cleanly, "
                "then export again.",
                file=sys.stderr,
            )
            return 2

    output = Path(args.output).expanduser()
    if not output.is_absolute():
        output = ROOT / output
    output = output.resolve()
    if output.exists():
        print(
            f"Output already exists; move it or choose another --output: {output}",
            file=sys.stderr,
        )
        return 2
    parent_exists = output.parent.exists()
    output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if not parent_exists:
        try:
            output.parent.chmod(0o700)
        except OSError:
            pass

    try:
        with zipfile.ZipFile(
            output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
        ) as archive:
            for path in project_files():
                archive.write(path, path.relative_to(ROOT).as_posix())
            if args.include_music_session:
                add_private_session(archive, session_path)
    except OSError as exc:
        print(f"Could not create the deployment ZIP ({type(exc).__name__}).", file=sys.stderr)
        output.unlink(missing_ok=True)
        return 1

    try:
        output.chmod(0o600)
    except OSError:
        pass
    print(f"Created: {output}")
    if args.include_music_session:
        print(
            "WARNING: This ZIP contains a Telegram account session. "
            "Keep it private and run only one copy at a time."
        )
    else:
        print("This ZIP excludes Telegram session files and .env secrets.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
