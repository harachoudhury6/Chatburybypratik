# Illusion Music Bot

Illusion Music Bot runs the existing EikoRobot management features and EikoMusic playback features in one Python process. Kurigram owns Bot API polling; the existing management handlers are bridged into that client. Both projects use one shared MongoDB connection.

## Setup

### 1. Create Telegram credentials

- Create an app at [my.telegram.org/apps](https://my.telegram.org/apps) and copy its `API_ID` and `API_HASH`.
- Create a bot with [@BotFather](https://t.me/BotFather) and copy its token as `BOT_TOKEN`.
- Set `OWNER_ID` to the numeric Telegram user ID allowed to administer the bot and start the owner-only `/login` flow.
- Optionally set `MUSIC_ACCOUNT_ID` to the numeric Telegram user ID of a separate account used only for voice-chat music. If omitted, it defaults to `OWNER_ID`.

### 2. Set up MongoDB

Create a database user and cluster in [MongoDB Atlas](https://www.mongodb.com/atlas), allow the Replit deployment to connect in the Atlas network-access settings, and copy the connection URI as `MONGO_DB_URI`. Keep the database username/password inside Replit Secrets.

### 3. Add Replit Secrets

Add these required secrets in Replit's Secrets tool:

| Secret | Purpose |
| --- | --- |
| `BOT_TOKEN` | BotFather token used by the shared bot |
| `API_ID` | Telegram application ID |
| `API_HASH` | Telegram application hash |
| `MONGO_DB_URI` | MongoDB Atlas connection URI |
| `OWNER_ID` | Numeric Telegram ID of the bot owner |
| `MUSIC_ACCOUNT_ID` | Optional numeric ID of the separate voice-chat music account; defaults to `OWNER_ID` |

Optional secrets are listed in [CONFIG.md](CONFIG.md). Add only the ones for features you plan to use. `.env.example` lists the supported names and defaults; do not commit a populated `.env` file.

### 4. Start

Run the Replit workflow **Eiko Telegram Bot**, or run:

```bash
python main.py
```

The process validates required settings before connecting. It needs network access to Telegram and MongoDB. Replit supplies FFmpeg through the project Nix configuration; local deployments need FFmpeg installed on the system `PATH`.

## Owner account login

The music assistant is optional until a playback account is authorized. In a private chat with the bot, only the configured `OWNER_ID` can start `/login`:

1. `/login`
2. Send the phone number with country code.
3. Send the Telegram login code.
4. If requested, send the 2FA password.

The phone number must belong to `MUSIC_ACCOUNT_ID` (which defaults to `OWNER_ID` if unset). The OTP/2FA messages are deleted when Telegram permits it. Other users cannot start this flow. On successful login, the session is stored in `sessions/music_assistant_1.session` and loaded automatically on later starts. It is used only by music/voice services. Set optional `MUSIC_SESSION_DIR` to choose another directory, such as a host's persistent storage path.

`/logout` disconnects all active owner music assistants and removes their local sessions. If any legacy `SESSION1`, `SESSION2`, or `SESSION3` Replit Secret was set, remove it after logging out so it is not reloaded on restart. Those session strings remain supported, but `/login` is the preferred setup.

The owner can change the expected playback account with `/setmusicaccount <telegram_user_id>` in a private chat. Use `/logout` first only when a music assistant is actually connected; inactive managed session files are cleared locally when changing the identity. This does not revoke the old Telegram login remotely. The command does not authorize an account or change `OWNER_ID`. Use `/setmusicaccount reset` or the `/admin` Remove custom ID button to return to the environment-configured ID, then `/login` to authorize the matching account. The saved override is stored in MongoDB and is visible only in the owner's private `/admin` menu.

### Move the logged-in session to another server

The normal source/repository ZIP deliberately excludes session files. After `/login` succeeds, stop the bot cleanly and create a private portable ZIP:

```bash
python scripts/export_portable_bot.py --include-music-session
```

This writes `dist/nocturnal-music-bot-portable.zip`. It contains `sessions/music_assistant_1.session` but does **not** contain `.env` or any Telegram/MongoDB bot secrets. Keep the ZIP private: anyone who gets the session can access the music Telegram account. Do not upload it to a public repository, chat, or file-sharing link. Run only one copy of this music session at a time; stop the old server before starting the new one.

On the destination server, extract the ZIP, set `BOT_TOKEN`, `API_ID`, `API_HASH`, `MONGO_DB_URI`, `OWNER_ID`, and `MUSIC_ACCOUNT_ID` in that server's environment, then run `python main.py`. Keep the same `API_ID` and `API_HASH` used for login. The session auto-loads from `sessions/`; if `MUSIC_SESSION_DIR` points elsewhere, move the included `music_assistant_1.session` file into that directory first. The export tool refuses to package an active SQLite session journal, so stop the bot before exporting.

## Music commands

- `/play <search or YouTube URL>` — search and play audio; `/playforce` bypasses the queue.
- `/vplay <search or YouTube URL>` and `/vplayforce` — video playback where enabled.
- `/queue` or `/playing` — show the current queue.
- `/pause`, `/resume`, `/skip` or `/next`, `/stop` or `/end` — playback controls.
- `/seek <seconds>` and `/seekback <seconds>` — seek within the current track.
- `/similar` and `/recommend <song>` — show related public tracks with functional Play and Queue buttons.
- `/radio [song|on|off]` — start related-track radio, seed it with a song, or disable it. Radio state is stored per group.
- `/autoplay [on|off]` — keep the existing same-artist autoplay behavior.
- `/save` or the player’s `♡ Save` button — save the current track to your personal favorites. `/save <tag>` still saves a management note for group admins.
- `/unsave`, `/favorites`, `/history`, and `/top` — manage personal favorites and view group listening activity.
- `/rec` — send the currently playing MP3 to your private chat after starting the bot DM.
- `/auth` and `/unauth` — allow or remove a group member's music controls.
- `/playmode` or `/musicsettings` — music-specific group settings.
- `/musicstats`, `/musicrepo`, and `/music` — music status, music start card, and music help.
- `/admin` — group admins see management commands; only the owner sees private account controls in DM.
- `/login`, `/logout`, and `/setmusicaccount` — owner-only private account setup, logout, and playback account ID management.

For playback, add the bot to the group with the required permissions, start a group voice chat, and make sure the authorized owner account can join that chat. Music uses `yt-dlp`; a YouTube Data API key, Google Cloud project, or separate YouTube search service is not required.

The player keyboard restores the compact controls: Play, Pause, Loop, Next, Stop, 10/30-second forward and backward seek, Autoplay, Rec MP3, and Close. Loop cycles through current-track repeat, queue repeat, and off. Similar-track recommendations and the queue remain available through their commands. Saved queue metadata is restored after a restart and resumes when a new play request starts the voice-call flow; a running Telegram call itself is not guaranteed to survive a host restart.

### Inline mode

Inline search and inline MP3 delivery have been removed. The bot now answers any stale inline query with an empty result. If inline mode was enabled before, disable it in [@BotFather](https://t.me/BotFather): run `/setinline`, select `@PrikshaMusicBot`, and turn it off. `/rec` remains available for sending the current track to the requester in a private chat.

On startup, the bot attempts to synchronize Telegram's display name from `BOT_NAME`. If Telegram does not accept that change, use BotFather's `/setname`. The profile photo and username still need BotFather: use `/setuserpic` with the uploaded portrait and `/setusername` if `PrikshaMusicBot` is available.
Public video search and playback use `yt-dlp`; no Google/YouTube API key, cookies, or account sign-in are used. Some cloud-host IPs are rate-limited or challenged by YouTube. For song-name searches, the bot tries a public SoundCloud result if YouTube has no accessible result and labels that source in the player. You can also search it directly with `/play scsearch1:<song name>`. Age-restricted, private, removed, and region-blocked videos are not bypassed.

## Management commands

Regular members see only user-facing commands in Telegram's group command menu. Group administrators get the expanded menu and can use `/admin` to see the complete administrator command list. `/admin` with a replied-to member retains the existing permission-management panel. Use `/help` for module-specific instructions. Existing management modules remain enabled, including:

- Moderation: `/ban`, `/unban`, `/mute`, `/unmute`, `/kick`, `/warn`, `/unwarn`, `/warns`.
- Filters and notes: `/filter`, `/filters`, `/stopfilter`, `/save`, `/get`, `/notes`, `/clear`.
- Locks and anti-spam: `/lock`, `/unlock`, `/locks`, `/setflood`, `/floodmode`, anti-raid and related settings.
- Greetings and group administration: `/setwelcome`, `/setgoodbye`, `/adminlist`, `/purge`, `/pin`, `/promote`, `/demote`.
- Admin utilities such as `/repo`, reports, rules, AFK, blacklist words, backups, and the other imported management modules.

Many commands require the bot to be an administrator. Grant only the permissions needed for the modules you enable. `/restore` is owner-only and runs MongoDB restore with `--drop`; it can replace existing collections. Keep a verified backup before using it.

## Group moderation setup

The shared moderation handler keeps the existing `/abuse`, `/antiporn`, `/antipornadmin`, and `/setflood` controls while avoiding duplicate automatic actions:

- `/abuse on|off` controls text and OCR abuse checks. Each non-admin gets a persistent counter per group: warning 1/3, warning 2/3, then a ban attempt on warning 3/3. Admins can inspect/change this counter with `/modwarns`, `/modsetwarns`, and `/modresetwarns`.
- Abuse matching normalizes Unicode, common leetspeak, repeated letters, spacing/punctuation tricks, transliterates supported Indic scripts and Russian Cyrillic, and matches native-script terms. The expandable `management/helpers/profanity_lexicons.json` includes curated English, Hindi, Odia, Bengali, Russian, Spanish, Portuguese, French, German, and Arabic terms. It is not a complete classifier; uncertain matches are not auto-banned. Admins can add group-specific terms with `/abuseword add`, `/abuseword remove`, and `/abuseword list`.
- `/antiporn on` enables local explicit-media checks for regular members; `/antipornadmin on` includes admins. NudeNet classifies supported media locally. High-confidence exposed genitalia/anus results trigger removal and a ban attempt; medical/educational caption or OCR context is excluded from automatic bans.
- OCR checks image text and sampled frames from GIFs, video, and animated Telegram stickers where the renderer can decode them. `MODERATION_OCR_LANGUAGES` defaults to `eng+hin+ori+ben+rus`; add other installed Tesseract codes (for example `ara`, `spa`, `por`, `fra`, or `deu`) as needed. Missing OCR data is reported; visual classification can still run when image frames were decoded. If Telegram download or frame decoding fails, the bot reports the media as uninspected.
- Selling moderation is off until an admin configures it. Optionally set `SELLING_GC_URL` for a global default, or set a per-group URL with `/setsellinggc <official HTTPS invite URL>`, then use `/sellingmod on`. Confirmed posts are deleted, the notice has a **Join Selling GC** button, and it is deleted after 60 seconds. A missing/invalid URL produces an admin configuration notice; the bot does not invent a link.
- Spam checks remove high-confidence link floods, suspicious link promotions, excessive mentions, and repeated identical messages. Repeating the same normalized message five times in 30 seconds triggers a ban attempt by default. Existing `/setflood` settings continue to handle message-volume flooding.
- `/modthresholds` shows or changes repeat, mention, selling, and explicit-media thresholds. `/moderationstatus` shows filter state and bot permissions; `/moderationlogs` shows recent actions. Settings, strikes, deduplication, and audit records are stored in MongoDB.

Make the bot a group administrator with **Delete messages** and **Ban users** (or **Restrict members**) permissions. Without those permissions it will report failed actions; Telegram will not let it delete or ban. The Replit configuration provides FFmpeg, ImageMagick, and Tesseract; local installs need those system tools and the Tesseract language data configured above in addition to `requirements.txt`. Run the moderation checks with:

```bash
python -m unittest discover -s tests -p 'test_moderation*.py'
python -m unittest tests.test_music_premium_features -v
```

## APIs and optional integrations

The core bot needs Telegram credentials and MongoDB only. Moderation uses local Tesseract and NudeNet models; it does not require a moderation API, Google API, or third-party image service. Google Gemini, Groq, Monster API, Replicate, GitHub/Gist, Telegraph, and the optional social-download provider are separate features and are not startup requirements. In particular, **YouTube Data API and Google Cloud API credentials are not used for YouTube search or playback**. See [CONFIG.md](CONFIG.md) for each variable and setup link.

## Common issues

- **Missing setting:** Add the named Replit Secret, then restart the workflow. Never paste credentials into Telegram or source files.
- **Invalid bot token:** Check `BOT_TOKEN` in BotFather and ensure only one process is polling with that token.
- **MongoDB connection failure:** Check `MONGO_DB_URI`, Atlas database-user credentials, IP/network access, and cluster status.
- **Management action denied:** Promote the bot and grant the specific ban/restrict/delete/pin permissions required by that command.
- **OCR/media moderation did not run:** Check Tesseract and its trained language files, FFmpeg, and ImageMagick. `/moderationstatus` reports model state and bot permissions; `/nsfwstatus` initializes/checks NudeNet. Unsupported or oversized media is not claimed as inspected.
- **Selling notice has no button:** Set an official `https://t.me/...` invite with `/setsellinggc`, then enable `/sellingmod on`; alternatively set the optional global `SELLING_GC_URL`.
- **Voice chat unavailable:** Start a group voice chat, confirm the group permits voice chats, and ensure the logged-in owner account can join.
- **No assistant logged in:** Run `/login` in a private chat as `OWNER_ID`; make sure the account you authorize matches `MUSIC_ACCOUNT_ID` (or `OWNER_ID` when unset).
- **YouTube search/playback fails:** YouTube may be rate-limiting or challenging the host. Retry later or run the bot on a host YouTube allows. Private, removed, region-blocked, and age-restricted videos may be unavailable. No Google/YouTube API key is required. The bot auto-enables Node as yt-dlp's JavaScript runtime when Node is installed.
- **Telegram FloodWait:** Wait for the time stated in the bot's reply before retrying.
- **Old session is loading:** Remove stale `SESSION1`/`SESSION2`/`SESSION3` values from Replit Secrets and restart; then use `/login`.
- **Session not valid on another server:** Re-run `/login` on the source bot, export a fresh private ZIP after stopping it, and make sure only one server is using the session.

## Security

Secrets belong in Replit Secrets, not `.env`, GitHub, chat, or logs. The original ZIPs contained credential-like values; treat any still-valid credentials from those archives as exposed and rotate them. Details are in [CONFIG.md](CONFIG.md).
