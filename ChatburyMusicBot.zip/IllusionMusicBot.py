"""Convenience .py launcher for the Illusion Music Bot project.

Run this from the extracted project directory:
    python IllusionMusicBot.py

The bot is a multi-module project, so the other project files and configured
environment variables are required alongside this launcher.
"""

from main import main


if __name__ == "__main__":
    raise SystemExit(main())
