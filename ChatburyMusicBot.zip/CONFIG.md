# Configuration and API audit

Set private values as Replit Secrets. The table lists only values read by the final source. Optional credentials enable only their listed feature; they are not needed to start the bot.

| Secret/API | Required | Used By | Official Setup |
| --- | --- | --- | --- |
| `BOT_TOKEN` | Yes | Shared Kurigram bot, management bridge, and Telegram bot identity | [@BotFather](https://t.me/BotFather) |
| `API_ID` | Yes | Kurigram/Pyrogram and Telethon MTProto clients, including owner account login | [my.telegram.org/apps](https://my.telegram.org/apps) |
| `API_HASH` | Yes | Same Telegram MTProto clients | [my.telegram.org/apps](https://my.telegram.org/apps) |
| `MONGO_DB_URI` | Yes | Shared asynchronous PyMongo connection for management and music collections | [MongoDB Atlas](https://www.mongodb.com/atlas) |
| `OWNER_ID` | Yes | Owner-only administration and permission to start `/login` | Numeric Telegram user ID; no API key |
| `MUSIC_ACCOUNT_ID` | No | Identity check for the Telegram account used by voice-chat music; defaults to `OWNER_ID` | Numeric Telegram user ID; add as a Replit Secret only when the playback account is separate |
| `MUSIC_SESSION_DIR` | No | Directory for the local music-account session file; defaults to `sessions` under the project | Optional path setting, not a secret; use persistent storage when the host provides it |
| `LOG_GROUP_ID` | No | Optional management and music status messages | Numeric group/channel ID; add the bot to that destination |
| `SELLING_GC_URL` | No; required only when selling moderation is enabled and no per-group link is saved | Default button destination for the official Selling GC; group admins may override it with `/setsellinggc` | An official HTTPS invite link supplied by the group owner; no API key |
| `MODERATION_OCR_LANGUAGES` | No; defaults to `eng+hin+ori+ben+rus` | Local Tesseract OCR for moderation text; the requested trained data must be installed on the host | Non-secret setting; add installed Tesseract codes such as `ara`, `spa`, `por`, `fra`, or `deu` |
| `SESSION1`, `SESSION2`, `SESSION3` | No | Optional pre-existing music assistant sessions; `/login` is preferred | Not required; authorize through the owner's private `/login` flow |
| `GROQ_API_KEY` | No | Optional Groq chatbot, voice, and text features | [Groq API keys](https://console.groq.com/keys) |
| `GEMINI_API_KEY` | No | Optional Google Gemini text/image features; separate from YouTube | [Google AI Studio API keys](https://aistudio.google.com/apikey) |
| `MONSTER_API_KEY` | No | Optional Monster API image generation | [Monster API](https://monsterapi.ai/) |
| `REPLICATE_API_TOKEN` | No | Optional Replicate-backed image utility | [Replicate API tokens](https://replicate.com/account/api-tokens) |
| `GIST_TOKEN` | No | Optional GitHub Gist creation | [GitHub personal access tokens](https://github.com/settings/tokens); grant only Gist access |
| `GITHUB_TOKEN` | No | Optional private-chat GitHub repository creation/upload | [GitHub personal access tokens](https://github.com/settings/tokens); grant only the required repository access |
| `TELEGRAPH_TOKEN` | No | Optional Telegraph page publishing | [Telegraph API](https://telegra.ph/api) |
| `FALLEN_API_KEY` | No | Optional Instagram and inline social-media download providers; not used for YouTube | [Instagram endpoint](https://beta.fallenapi.fun/instagram) and [social downloader](https://tgmusic.fallenapi.fun); no official key-setup guide was verified |
| Tesseract trained language data | No secret; required only for OCR moderation | Local OCR for message images, stickers, GIFs, and sampled video frames | [Tesseract](https://github.com/tesseract-ocr/tesseract) and [trained data](https://github.com/tesseract-ocr/tessdata) |
| NudeNet ONNX model | No secret; required only for explicit-media moderation | Local NudeNet classifier in `management/helpers/media_moderation.py` | [NudeNet project](https://github.com/notAI-tech/NudeNet); installed by the existing `nudenet` requirement |

## YouTube and Google API decision

- **YouTube Data API v3 is not used.**
- **A Google Cloud project or YouTube API key is not required.**
- `yt-dlp` performs YouTube search and media extraction for `/play` and related commands.
- Some cloud-host IPs receive YouTube rate limits or sign-in challenges. The bot does not use cookies or sign-in to bypass them; for song-name searches it transparently tries a public SoundCloud result and labels that source. You can also use `/play scsearch1:<song name>` directly.
- The optional `GEMINI_API_KEY` enables separate AI features only; it does not affect YouTube playback.
- No third-party YouTube search/download API is required. Social-media downloads are a separate optional feature that uses `FALLEN_API_KEY`.

## Non-secret settings

`.env.example` documents the supported optional settings and the database names. The required startup configuration is only `BOT_TOKEN`, `API_ID`, `API_HASH`, `MONGO_DB_URI`, and `OWNER_ID`. `MUSIC_ACCOUNT_ID` defaults to `OWNER_ID`; set it separately when another Telegram account should join voice chats and play music. The owner can also change this expected identity using `/setmusicaccount <telegram_user_id|reset>` in a private chat. The override is stored in MongoDB, does not authorize an account, and takes effect only after disconnecting the current session; use `/login` afterward. `MUSIC_SESSION_DIR` optionally selects the directory for the persistent music session file. `MONGO_DB_NAME`, `MONGO_MUSIC_DB_NAME`, and `MONGO_DB2_NAME` have defaults. `LOGGER_ID` and `USER_STRING` are accepted only as legacy aliases for `LOG_GROUP_ID` and `SESSION1`.

`SELLING_GC_URL` is an optional group invite link, not a credential. It supplies the default selling-notice button destination. No Google/YouTube key or cookie, translation API, OCR API, or external image-classification API is required for moderation or public YouTube playback. Abuse detection uses an expandable local multilingual lexicon plus Indic and Russian transliteration; it is not a universal language-understanding model, and admins can add group-specific terms with `/abuseword`.

## Credential rotation

The original uploaded archives included credential-like values, including a bot token, Telegram API hash, MongoDB connection credentials, a hard-coded FallenAPI Instagram key, other third-party keys, and cookies. Treat any value that is still valid as exposed:

- Revoke/regenerate the BotFather token.
- Rotate the MongoDB database user's password and update the Atlas URI.
- Replace exposed third-party keys and invalidate exposed cookies/sessions.
- Review the Telegram app credentials at [my.telegram.org/apps](https://my.telegram.org/apps); retire the exposed app credentials and create fresh credentials if the portal permits.

The merged source does not contain those archive values. Do not paste them into chat or commit them to the repository.
