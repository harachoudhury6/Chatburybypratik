"""Single process entrypoint for the Illusion management and music bot."""

from __future__ import annotations

import asyncio
import importlib
import logging
import re
import signal
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import settings
from database import close_database, connect_database

logger = logging.getLogger("eiko")


class SecretRedactionFilter(logging.Filter):
    _patterns = (
        re.compile(
            r"(?i)\b(([A-Z][A-Z0-9_]*_(?:TOKEN|API_KEY|API_HASH|API_ID|PASSWORD|"
            r"PASSWD)|API_(?:KEY|HASH|ID)|SESSION\d*|SESSION_STRING\d*|"
            r"USER_STRING|AUTHORIZATION|MONGO(?:_?DB)?_(?:URI|URL))\s*[:=]\s*)"
            r"((?:Bearer\s+)?[^,\s;&]+)"
        ),
        re.compile(r"(?i)(mongodb(?:\+srv)?://)([^:/@\s]+):([^@\s/]+)@"),
        re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+"),
        re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{25,}\b"),
    )

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
            message = self._patterns[0].sub(r"\1[REDACTED]", message)
            message = self._patterns[1].sub(r"\1[REDACTED]@", message)
            message = self._patterns[2].sub("Bearer [REDACTED]", message)
            message = self._patterns[3].sub("[TELEGRAM_BOT_TOKEN_REDACTED]", message)
            record.msg = message
            record.args = ()
            if record.exc_info:
                error_type = record.exc_info[0].__name__
                traceback = record.exc_info[2]
                while traceback and traceback.tb_next:
                    traceback = traceback.tb_next
                location = ""
                if traceback:
                    code = traceback.tb_frame.f_code
                    location = (
                        f" at {Path(code.co_filename).name}:"
                        f"{traceback.tb_lineno} ({code.co_name})"
                    )
                record.msg = f"{message} [exception {error_type}{location}]"
                record.exc_info = None
                record.exc_text = None
        except Exception:
            record.msg = "Log message suppressed by the secret-safety filter."
            record.args = ()
            record.exc_info = None
            record.exc_text = None
        return True


def configure_logging() -> None:
    root = logging.getLogger()
    root.setLevel(getattr(logging, settings.LOG_LEVEL, logging.INFO))
    redactor = SecretRedactionFilter()
    for handler in root.handlers:
        if not any(isinstance(existing, SecretRedactionFilter) for existing in handler.filters):
            handler.addFilter(redactor)
    if root.handlers:
        return
    formatter = logging.Formatter(
        "[%(asctime)s] %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    stream.addFilter(SecretRedactionFilter())
    file_handler = RotatingFileHandler(
        "log.txt", maxBytes=10_485_760, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(SecretRedactionFilter())
    root.addHandler(stream)
    root.addHandler(file_handler)
    for name in ("httpx", "ntgcalls", "pymongo", "pyrogram", "pytgcalls", "telethon"):
        logging.getLogger(name).setLevel(logging.ERROR)


def _plugin_modules(directory: Path, package: str) -> list[str]:
    return [
        f"{package}.{path.stem}"
        for path in sorted(directory.glob("*.py"))
        if path.name != "__init__.py"
    ]


def load_plugins(management: object, music: object) -> None:
    failures: list[str] = []
    from management.helpers.plain_text import activate_plain_text_output

    activate_plain_text_output()
    disabled_inline_modules = {
        "music.plugins.iquery",
        "management.plugins.inline",
    }
    for module_name in _plugin_modules(Path("music/plugins"), "music.plugins"):
        if module_name in disabled_inline_modules:
            logger.info("Inline mode is disabled; skipped %s.", module_name)
            continue
        try:
            importlib.import_module(module_name)
        except Exception as exc:
            failures.append(f"{module_name} ({type(exc).__name__})")
    for module_name in _plugin_modules(Path("management/plugins"), "management.plugins"):
        if module_name in disabled_inline_modules:
            logger.info("Inline mode is disabled; skipped %s.", module_name)
            continue
        try:
            module = importlib.import_module(module_name)
            help_text = getattr(module, "__help__", None)
            if isinstance(help_text, str) and help_text.strip():
                module_key = module.__name__.rsplit(".", 1)[-1].lower()
                management.MODULE.setdefault(module_key, help_text)
        except Exception as exc:
            failures.append(f"{module_name} ({type(exc).__name__})")
    if failures:
        raise RuntimeError("Plugin imports failed: " + ", ".join(failures))


async def run() -> None:
    settings.validate()
    configure_logging()
    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signum, stop_event.set)
        except NotImplementedError:
            pass

    management = music = None
    ptb_application = None
    ptb_initialized = False
    ptb_started = False
    try:
        await connect_database()
        import music as music_package
        import management as management_package

        music = music_package
        management = management_package
        ptb_application = management.ptb_application
        if ptb_application is None:
            raise RuntimeError("The management handler bridge could not be initialized.")

        await music.db.connect()
        stored_music_account_id = await music.db.get_music_account_id_override()
        if stored_music_account_id is not None:
            from config import set_music_account_id

            set_music_account_id(stored_music_account_id)
            logger.info("Loaded the owner-configured music account ID.")
        await management.init_aiohttp_session()
        await management.initialize_database()
        load_plugins(management, music)

        from management.bridge import install_bridge

        await install_bridge(music.app, ptb_application)
        ptb_application.add_error_handler(_ptb_error_handler)
        await ptb_application.initialize()
        ptb_initialized = True
        await ptb_application.start()
        ptb_started = True

        await music.userbot.boot()
        await music.anon.boot()
        await management.start_all_clients()
        await music.app.boot()
        from management.command_menu import install_command_menus

        await install_command_menus(music.app)
        management.BOT_USERNAME = music.config.BOT_USERNAME
        logger.info(
            f"{settings.BOT_NAME} is online: one Kurigram Bot API poller, shared MongoDB, "
            "%d music assistant(s), and bridged management handlers.",
            len(music.userbot.clients),
        )
        await stop_event.wait()
    finally:
        logger.info("Shutting down %s.", settings.BOT_NAME)
        if management is not None:
            try:
                await management.stop_all_clients()
            except Exception as exc:
                logger.warning("Management shutdown issue (%s).", type(exc).__name__)
        if music is not None:
            try:
                await music.stop()
            except Exception as exc:
                logger.warning("Music shutdown issue (%s).", type(exc).__name__)
        if ptb_application is not None and ptb_started:
            try:
                await ptb_application.stop()
            except Exception as exc:
                logger.warning("PTB shutdown issue (%s).", type(exc).__name__)
        if ptb_application is not None and ptb_initialized:
            try:
                await ptb_application.shutdown()
            except Exception as exc:
                logger.warning("PTB cleanup issue (%s).", type(exc).__name__)
        await close_database()


async def _ptb_error_handler(update: object, context: object) -> None:
    error = getattr(context, "error", None)
    logger.error(
        "Management handler failed (%s).",
        type(error).__name__ if error is not None else "UnknownError",
    )


def main() -> int:
    configure_logging()
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        logger.info("Stopped.")
    except ValueError as exc:
        logger.error("%s", exc)
        return 2
    except ConnectionError as exc:
        logger.error("%s", exc)
        return 2
    except Exception as exc:
        logger.error("Startup/runtime failure (%s). Review the configured credentials and dependencies.", type(exc).__name__)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
