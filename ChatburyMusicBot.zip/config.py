"""Single source of truth for Illusion Music Bot configuration."""

from __future__ import annotations

import os
import re
from typing import Any

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int = 0) -> int:
    value = os.getenv(name)
    if not value:
        return default
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer.") from exc


def _id_list(name: str, default: list[int] | None = None) -> list[int]:
    raw = os.getenv(name, "")
    if not raw.strip():
        return list(default or [])
    values: list[int] = []
    for part in re.split(r"[\s,]+", raw.strip()):
        if part:
            try:
                values.append(int(part))
            except ValueError as exc:
                raise ValueError(f"{name} must contain only numeric Telegram IDs.") from exc
    return values


class Config:
    """Environment-backed settings shared by both original bot projects."""

    def __init__(self) -> None:
        self.BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
        self.TOKEN = self.BOT_TOKEN
        self.API_ID = _int("API_ID")
        self.API_HASH = os.getenv("API_HASH", "").strip()
        self.MONGO_DB_URI = os.getenv("MONGO_DB_URI", "").strip()
        self.MONGO_URL = self.MONGO_DB_URI
        self.DB_URL = self.MONGO_DB_URI
        self.DB_URL2 = self.MONGO_DB_URI
        self.MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "AloneX").strip() or "AloneX"
        self.MONGO_MUSIC_DB_NAME = (
            os.getenv("MONGO_MUSIC_DB_NAME", "Anon").strip() or "Anon"
        )
        self.MONGO_DB2_NAME = os.getenv("MONGO_DB2_NAME", "AloneX2").strip() or "AloneX2"
        self.OWNER_ID = _int("OWNER_ID")
        self.DEFAULT_MUSIC_ACCOUNT_ID = _int("MUSIC_ACCOUNT_ID", self.OWNER_ID)
        self.MUSIC_ACCOUNT_ID = self.DEFAULT_MUSIC_ACCOUNT_ID
        self.MUSIC_SESSION_DIR = (
            os.getenv("MUSIC_SESSION_DIR", "sessions").strip() or "sessions"
        )
        self.ALONE_OWNER_ID = self.OWNER_ID
        self.LOG_GROUP_ID = _int("LOG_GROUP_ID", _int("LOGGER_ID"))
        self.LOGGER_ID = self.LOG_GROUP_ID
        self.LOGS_CHANNEL: int | None = self.LOG_GROUP_ID or None
        self.CATALOG_CHANNEL_ID = _int("CATALOG_CHANNEL_ID", -1003705704898)
        # Optional default Selling GC. An admin may override it per group.
        self.SELLING_GC_URL = os.getenv("SELLING_GC_URL", "").strip()

        self.SESSION1 = os.getenv("SESSION1", os.getenv("USER_STRING", "")).strip() or None
        self.SESSION2 = os.getenv("SESSION2", "").strip() or None
        self.SESSION3 = os.getenv("SESSION3", "").strip() or None
        self.USER_STRING = self.SESSION1

        # Optional service credentials only enable the feature that uses them.
        self.GROQ_API_KEY = os.getenv("GROQ_API_KEY")
        self.GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
        self.MONSTER_API_KEY = os.getenv("MONSTER_API_KEY")
        self.REPLICATE_API_TOKEN = os.getenv("REPLICATE_API_TOKEN")
        self.GIST_TOKEN = os.getenv("GIST_TOKEN")
        self.GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
        self.TELEGRAPH_TOKEN = os.getenv("TELEGRAPH_TOKEN")
        self.FALLEN_API_KEY = os.getenv("FALLEN_API_KEY")

        self.BOT_ID = int(self.BOT_TOKEN.split(":", 1)[0]) if ":" in self.BOT_TOKEN else 0
        self.BOT_USERNAME = os.getenv("BOT_USERNAME", "IllusionMusicBot").strip()
        if self.BOT_USERNAME and not self.BOT_USERNAME.startswith("@"):
            self.BOT_USERNAME = f"@{self.BOT_USERNAME}"
        self.BOT_NAME = os.getenv(
            "BOT_NAME", "𝖢𝗁𝖺𝗍𝖻𝗎𝗋𝗒 𝖬𝗎𝗌𝗂𝖼 𝖡𝗈𝗍"
        ).strip()
        self.PREFIX = _bool("PREFIX", True)
        self.prefix_cmds = ["!", "?", "$", "/", "\\", ".", "*", "-", "&", "#", ","]

        self.SUDO_USERS = _id_list("SUDO_USERS")
        self.SUPPORT_USERS = _id_list("SUPPORT_USERS")
        self.WHITELIST_USERS = _id_list("WHITELIST_USERS")
        self.DEV_LIST = _id_list("DEV_LIST", [self.OWNER_ID] if self.OWNER_ID else [])
        self.PREMIUM_USERS = _id_list("PREMIUM_USERS")
        self.SPAM_USERS: dict[int, bool] = {}

        self.SUPPORT_CHAT = os.getenv("SUPPORT_CHAT", "https://t.me/NocturnalGC")
        self.SUPPORT_GROUP = os.getenv("SUPPORT_GROUP", "https://t.me/NocturnalGC")
        self.OWNER_USERNAME = os.getenv("OWNER_USERNAME", "").strip().lstrip("@")
        self.SUPPORT_USERNAME = (
            os.getenv("SUPPORT_USERNAME", "tgnxt").strip().lstrip("@") or "tgnxt"
        )
        self.UPDATE_CHANNEL = os.getenv("UPDATE_CHANNEL", "@NocturnalUpdates")
        # Keep music-card fallback artwork separate from the uploaded welcome
        # image so changing the bot's start image does not brand player cards.
        self.START_IMG = os.getenv(
            "START_IMG", "attached_assets/f647b5882d63cbc6bfe6d6f8e9888822_1791523463060.jpg"
        )
        self.START_IMG_URL = os.getenv("START_IMG_URL", self.START_IMG)
        self.BOT_START_IMG = os.getenv("BOT_START_IMG", self.START_IMG)
        self.PM_START_IMG = os.getenv("PM_START_IMG", self.START_IMG)
        self.HELP_CMD_IMG = os.getenv("HELP_CMD_IMG", self.BOT_START_IMG)
        self.HELP_MODULE_IMG = os.getenv("HELP_MODULE_IMG", self.BOT_START_IMG)
        self.FORCE_JOIN_IMG = os.getenv("FORCE_JOIN_IMG", self.BOT_START_IMG)
        self.DEFAULT_THUMB = os.getenv("DEFAULT_THUMB", self.BOT_START_IMG)
        self.PING_IMG = os.getenv("PING_IMG", self.BOT_START_IMG)
        self.WEB_URL = os.getenv("WEB_URL", "")

        self.QUEUE_LIMIT = _int("QUEUE_LIMIT", 50)
        # Zero means no duration cap. Hosts with limited resources can opt into
        # a cap by setting DURATION_LIMIT to a positive number of seconds.
        self.DURATION_LIMIT = _int("DURATION_LIMIT", 0)
        self.PLAYLIST_LIMIT = _int("PLAYLIST_LIMIT", 20)
        self.AUTO_END = _bool("AUTO_END")
        self.AUTO_LEAVE = _bool("AUTO_LEAVE")
        self.VIDEO_PLAY = _bool("VIDEO_PLAY", True)
        self.STREAM_MOD = _bool("STREAM_MOD")
        self.COOKIE_URLS: list[str] = []
        self.COOKIES_URL = self.COOKIE_URLS

        self.AF_FILE_DEL_TIME = _int("AF_FILE_DEL_TIME", 1800)
        self.AF_SUB_CHAT = os.getenv("AF_SUB_CHAT", "@AloneUpdates")
        self.AF_SUB_TEXT = os.getenv("AF_SUB_TEXT", "")
        self.AF_QS_TEXT = os.getenv("AF_QS_TEXT", "")
        self.FILE_DB_CHANNEL = _int("FILE_DB_CHANNEL")
        self.MULTI_CLIENT = _bool("MULTI_CLIENT")
        self.MULTI_CLIENTS: dict[int, Any] = {}
        self.work_loads: dict[int, int] = {}
        self.IS_WEB_SUP = False
        self.KEEP_ALIVE = False
        self.PORT = _int("PORT", 8080)
        self.BIND_ADDRESS = os.getenv("WEB_SERVER_BIND_ADDRESS", "0.0.0.0")
        self.AUTO_DEL = _int("AUTO_DEL", 10)
        self.BTN_COLUMNS = _int("BTN_COLUMNS", 2)
        self.BTN_ROWS = _int("BTN_ROWS", 6)
        self.LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

    def validate(self) -> None:
        required = {
            "BOT_TOKEN": self.BOT_TOKEN,
            "API_ID": self.API_ID,
            "API_HASH": self.API_HASH,
            "MONGO_DB_URI": self.MONGO_DB_URI,
            "OWNER_ID": self.OWNER_ID,
        }
        missing = [name for name, value in required.items() if not value]
        if missing:
            raise ValueError("Missing required environment variables: " + ", ".join(missing))
        if not re.fullmatch(r"\d{6,12}:[A-Za-z0-9_-]{25,}", self.BOT_TOKEN):
            raise ValueError("BOT_TOKEN does not have the expected Telegram bot-token format.")
        if self.API_ID <= 0:
            raise ValueError("API_ID must be a positive integer.")
        if self.OWNER_ID <= 0:
            raise ValueError("OWNER_ID must be a positive Telegram user ID.")
        if self.MUSIC_ACCOUNT_ID <= 0:
            raise ValueError("MUSIC_ACCOUNT_ID must be a positive Telegram user ID.")
        if min(self.QUEUE_LIMIT, self.PLAYLIST_LIMIT) < 1 or self.DURATION_LIMIT < 0:
            raise ValueError(
                "Music queue and playlist limits must be positive; duration limit cannot be negative."
            )

    def check(self) -> None:
        """Compatibility alias retained for the original music configuration API."""
        self.validate()


settings = Config()
config = settings


def set_music_account_id(user_id: int) -> None:
    """Update the active playback-account ID in this process."""
    global MUSIC_ACCOUNT_ID
    parsed_id = int(user_id)
    if parsed_id <= 0:
        raise ValueError("MUSIC_ACCOUNT_ID must be a positive Telegram user ID.")
    settings.MUSIC_ACCOUNT_ID = parsed_id
    MUSIC_ACCOUNT_ID = parsed_id


# Legacy constant names referenced by the imported modules.
BOT_TOKEN = settings.BOT_TOKEN
TOKEN = settings.TOKEN
API_ID = settings.API_ID
API_HASH = settings.API_HASH
BOT_ID = settings.BOT_ID
OWNER_ID = settings.OWNER_ID
MUSIC_ACCOUNT_ID = settings.MUSIC_ACCOUNT_ID
ALONE_OWNER_ID = settings.ALONE_OWNER_ID
LOG_GROUP_ID = settings.LOG_GROUP_ID
LOGGER_ID = settings.LOGGER_ID
LOGS_CHANNEL = settings.LOGS_CHANNEL
CATALOG_CHANNEL_ID = settings.CATALOG_CHANNEL_ID
DB_URL = settings.DB_URL
DB_URL2 = settings.DB_URL2
MONGO_DB_URI = settings.MONGO_DB_URI
MONGO_DB_NAME = settings.MONGO_DB_NAME
MONGO_MUSIC_DB_NAME = settings.MONGO_MUSIC_DB_NAME
MONGO_DB2_NAME = settings.MONGO_DB2_NAME
BOT_USERNAME = settings.BOT_USERNAME
BOT_NAME = settings.BOT_NAME
PREFIX = settings.PREFIX
prefix_cmds = settings.prefix_cmds
SUDO_USERS = settings.SUDO_USERS
SUPPORT_USERS = settings.SUPPORT_USERS
WHITELIST_USERS = settings.WHITELIST_USERS
DEV_LIST = settings.DEV_LIST
PREMIUM_USERS = settings.PREMIUM_USERS
SPAM_USERS = settings.SPAM_USERS
SUPPORT_CHAT = settings.SUPPORT_CHAT
SUPPORT_GROUP = settings.SUPPORT_GROUP
OWNER_USERNAME = settings.OWNER_USERNAME
SUPPORT_USERNAME = settings.SUPPORT_USERNAME
UPDATE_CHANNEL = settings.UPDATE_CHANNEL
START_IMG_URL = settings.START_IMG_URL
START_IMG = settings.START_IMG
PM_START_IMG = settings.PM_START_IMG
HELP_CMD_IMG = settings.HELP_CMD_IMG
HELP_MODULE_IMG = settings.HELP_MODULE_IMG
FORCE_JOIN_IMG = settings.FORCE_JOIN_IMG
DEFAULT_THUMB = settings.DEFAULT_THUMB
PING_IMG = settings.PING_IMG
WEB_URL = settings.WEB_URL
QUEUE_LIMIT = settings.QUEUE_LIMIT
DURATION_LIMIT = settings.DURATION_LIMIT
PLAYLIST_LIMIT = settings.PLAYLIST_LIMIT
AUTO_END = settings.AUTO_END
AUTO_LEAVE = settings.AUTO_LEAVE
VIDEO_PLAY = settings.VIDEO_PLAY
STREAM_MOD = settings.STREAM_MOD
COOKIES_URL = settings.COOKIES_URL
SESSION1 = settings.SESSION1
SESSION2 = settings.SESSION2
SESSION3 = settings.SESSION3
USER_STRING = settings.USER_STRING
GROQ_API_KEY = settings.GROQ_API_KEY
GEMINI_API_KEY = settings.GEMINI_API_KEY
MONSTER_API_KEY = settings.MONSTER_API_KEY
REPLICATE_API_TOKEN = settings.REPLICATE_API_TOKEN
GIST_TOKEN = settings.GIST_TOKEN
GITHUB_TOKEN = settings.GITHUB_TOKEN
TELEGRAPH_TOKEN = settings.TELEGRAPH_TOKEN
FALLEN_API_KEY = settings.FALLEN_API_KEY
AF_FILE_DEL_TIME = settings.AF_FILE_DEL_TIME
AF_SUB_CHAT = settings.AF_SUB_CHAT
AF_SUB_TEXT = settings.AF_SUB_TEXT
AF_QS_TEXT = settings.AF_QS_TEXT
FILE_DB_CHANNEL = settings.FILE_DB_CHANNEL
MULTI_CLIENT = settings.MULTI_CLIENT
multi_clients = settings.MULTI_CLIENTS
work_loads = settings.work_loads
IS_WEB_SUP = settings.IS_WEB_SUP
KEEP_ALIVE = settings.KEEP_ALIVE
PORT = settings.PORT
BIND_ADDRESS = settings.BIND_ADDRESS
AUTO_DEL = settings.AUTO_DEL
BTN_COLUMNS = settings.BTN_COLUMNS
BTN_ROWS = settings.BTN_ROWS
