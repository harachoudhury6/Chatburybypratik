"""Shared database connection for the management and music modules."""

from database.connection import close_database, connect_database, get_client, get_database

__all__ = [
    "close_database",
    "connect_database",
    "get_client",
    "get_database",
]
