"""One asynchronous MongoDB client shared across both original projects."""

from __future__ import annotations

import logging
from typing import Any

from pymongo import AsyncMongoClient

from config import settings

logger = logging.getLogger(__name__)
_client: AsyncMongoClient | None = None


async def connect_database() -> AsyncMongoClient:
    global _client
    client = get_client()
    try:
        await client.admin.command("ping")
    except Exception as exc:
        await close_database()
        raise ConnectionError(
            f"MongoDB connection failed ({type(exc).__name__}). Check MONGO_DB_URI and Atlas network access."
        ) from exc
    logger.info("Connected to MongoDB.")
    return client


def get_client() -> AsyncMongoClient:
    global _client
    if _client is None:
        if not settings.MONGO_DB_URI:
            raise RuntimeError("MONGO_DB_URI is required before creating the MongoDB client.")
        _client = AsyncMongoClient(
            settings.MONGO_DB_URI,
            serverSelectionTimeoutMS=12_500,
            connectTimeoutMS=12_500,
        )
    return _client


def get_database(name: str | None = None) -> Any:
    client = get_client()
    return client[name or settings.MONGO_DB_NAME]


async def close_database() -> None:
    global _client
    if _client is not None:
        await _client.close()
        _client = None
